CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;
BEGIN TRANSACTION;
CREATE TABLE metadata
(
  var_name varchar(63) not null,
  var_value varchar(255) not null,
  PRIMARY KEY(var_name)
) ;
CREATE TABLE config
(
  var_name varchar(63) not null,
  var_value varchar(2000) null,
  default_value varchar(2000) null,
  is_visible integer not null default 1,
  need_server_restart integer not null default 0,
  data_type char(1) not null default 'S',
  is_public char(1) not null default 'N',
  description varchar(450) null,
  possible_values text null,
  units varchar(36),
  PRIMARY KEY(var_name)
) ;
CREATE TABLE config_clob
(
  var_name varchar(63) not null,
  var_value text null,
  PRIMARY KEY(var_name)
) ;
CREATE TABLE config_values
(
 var_name varchar(63) not null,
 var_value varchar(15) not null,
 var_description varchar(255) null,
 PRIMARY KEY(var_name,var_value)
) ;
CREATE TABLE users
(
  id integer not null,
  guid varchar(36) not null,
  name varchar(63) not null,
  password varchar(127) not null,
  system_access bigint not null,
  flags integer not null,
  ui_access_rules varchar(2000) null,
  full_name varchar(127) null,
  description varchar(255) null,
  grace_logins integer not null,
  auth_method integer not null,
  cert_mapping_method integer not null,
  cert_mapping_data text null,
  auth_failures integer not null,
  last_passwd_change integer not null,
  min_passwd_length integer not null,
  disabled_until integer not null,
  last_login integer not null,
  password_history text null,
  email varchar(127) null,
  phone_number varchar(63) null,
  ldap_dn text null,
  ldap_unique_id varchar(64) null,
  created integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE auth_tokens
(
  id integer not null,
  user_id integer not null,
  issuing_time integer not null,
  expiration_time integer not null,
  description varchar(127) null,
  token_data char(64) not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE user_groups
(
  id integer not null,
  guid varchar(36) not null,
  name varchar(63) not null,
  system_access bigint not null,
  flags integer not null,
  ui_access_rules varchar(2000) null,
  description varchar(255),
  ldap_dn text null,
  ldap_unique_id varchar(64) null,
  created integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE user_group_members
(
  group_id integer not null,
  user_id integer not null,
  PRIMARY KEY(group_id,user_id)
) ;
CREATE TABLE user_profiles
(
  user_id integer not null,
  var_name varchar(63) not null,
  var_value text not null,
  PRIMARY KEY(user_id,var_name)
) ;
CREATE TABLE userdb_custom_attributes
(
  object_id integer not null,
  attr_name varchar(127) not null,
  attr_value text not null,
  PRIMARY KEY(object_id,attr_name)
) ;
CREATE TABLE object_properties
(
  object_id integer not null,
  guid varchar(36) not null,
  name varchar(63) not null,
  alias varchar(255) null,
  flags integer not null,
  state integer not null,
  status integer not null,
  is_deleted integer not null,
  is_system integer not null,
  last_modified integer not null,
  inherit_access_rights integer not null,
  status_calc_alg integer not null,
  status_prop_alg integer not null,
  status_fixed_val integer not null,
  status_shift integer not null,
  status_translation varchar(8) not null,
  status_single_threshold integer not null,
  status_thresholds varchar(8) not null,
  comments text null,
  comments_source text null,
  location_type integer not null,
  latitude varchar(20),
  longitude varchar(20),
  location_accuracy integer not null,
  location_timestamp integer not null,
  map_image varchar(36) not null,
  drilldown_object_id integer not null,
  name_on_map varchar(63) null,
  country varchar(63) null,
  region varchar(63) null,
  city varchar(63) null,
  district varchar(63) null,
  street_address varchar(255) null,
  postcode varchar(31) null,
  state_before_maint integer not null,
  maint_event_id bigint not null,
  maint_initiator integer not null,
  creation_time integer not null,
  category integer not null,
  asset_id integer not null,
  PRIMARY KEY(object_id)
) ;
CREATE TABLE object_categories
(
  id integer not null,
  name varchar(63) not null,
  icon varchar(36) null,
  map_image varchar(36) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE object_urls
(
  object_id integer not null,
  url_id integer not null,
  url varchar(2000) null,
  description varchar(2000) null,
  PRIMARY KEY(object_id,url_id)
) ;
CREATE TABLE object_custom_attributes
(
  object_id integer not null,
  attr_name varchar(127) not null,
  attr_value text null,
  flags integer not null,
  PRIMARY KEY(object_id,attr_name)
) ;
CREATE INDEX idx_ocattr_oid ON object_custom_attributes(object_id);
CREATE TABLE zones
(
  id integer not null,
  zone_guid integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE zone_proxies
(
  object_id integer not null,
  proxy_node integer not null,
  PRIMARY KEY(object_id,proxy_node)
) ;
CREATE TABLE mobile_devices
(
  id integer not null,
  device_id varchar(64) not null,
  vendor varchar(64) null,
  model varchar(128) null,
  serial_number varchar(64) null,
  os_name varchar(32) null,
  os_version varchar(64) null,
  user_id varchar(64) null,
  battery_level integer not null,
  comm_protocol varchar(31) null,
  speed varchar(20) not null,
  direction integer not null,
  altitude integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE access_points
(
  id integer not null,
  domain_id integer not null,
  controller_id integer not null,
  mac_address varchar(16) null,
  vendor varchar(64) null,
  model varchar(128) null,
  serial_number varchar(64) null,
  ap_state integer not null,
  ap_index integer not null,
  grace_period_start integer not null,
  peer_node_id integer not null,
  peer_if_id integer not null,
  peer_proto integer not null,
  down_since integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE radios
(
  owner_id integer not null,
  radio_index integer not null,
  if_index integer not null,
  name varchar(63) null,
  bssid char(12) not null,
  ssid varchar(32) null,
  frequency integer not null,
  band integer not null,
  channel integer not null,
  power_dbm integer not null,
  power_mw integer not null,
  PRIMARY KEY(owner_id,radio_index,bssid)
) ;
CREATE TABLE racks
(
  id integer not null,
  height integer not null,
  top_bottom_num char(1) not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE rack_passive_elements
(
  id integer not null,
  rack_id integer not null,
  name varchar(255) null,
  type integer not null,
  position integer not null,
  height integer not null,
  orientation integer not null,
  port_count integer not null,
  image_front varchar(36) null,
  image_rear varchar(36) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE physical_links
(
  id integer not null,
  description varchar(255) null,
  left_object_id integer not null,
  left_patch_pannel_id integer not null,
  left_port_number integer not null,
  left_front char(1) not null,
  right_object_id integer not null,
  right_patch_pannel_id integer not null,
  right_port_number integer not null,
  right_front char(1) not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE chassis
(
  id integer not null,
  controller_id integer not null,
  rack_id integer not null,
  rack_image_front varchar(36) null,
  rack_image_rear varchar(36) null,
  rack_position integer not null,
  rack_height integer not null,
  rack_orientation integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE nodes
(
  id integer not null,
  primary_name varchar(255) null,
  primary_ip varchar(48) not null,
  tunnel_id varchar(36) null,
  agent_cert_subject varchar(500) null,
  agent_cert_mapping_method char(1) null,
  agent_cert_mapping_data varchar(500) null,
  snmp_version integer not null,
  snmp_port integer not null,
  community varchar(127) null,
  usm_auth_password varchar(127) null,
  usm_priv_password varchar(127) null,
  usm_methods integer not null,
  snmp_oid varchar(255) null,
  snmp_engine_id varchar(255) null,
  snmp_context_engine_id varchar(255) null,
  secret varchar(88) null,
  agent_port integer not null,
  agent_version varchar(63) null,
  agent_id varchar(36) null,
  hardware_id varchar(40) null,
  platform_name varchar(63) null,
  poller_node_id integer not null,
  zone_guid integer not null,
  proxy_node integer not null,
  snmp_proxy integer not null,
  eip_proxy integer not null,
  icmp_proxy integer not null,
  required_polls integer not null,
  uname varchar(255) null,
  use_ifxtable integer not null,
  snmp_sys_name varchar(127) null,
  snmp_sys_contact varchar(127) null,
  snmp_sys_location varchar(255) null,
  bridge_base_addr varchar(15) null,
  lldp_id varchar(255) null,
  down_since integer not null,
  boot_time integer not null,
  driver_name varchar(32) null,
  physical_container_id integer not null,
  rack_image_front varchar(36) null,
  rack_image_rear varchar(36) null,
  rack_position integer not null,
  rack_height integer not null,
  rack_orientation integer not null,
  agent_cache_mode char(1) not null,
  last_agent_comm_time integer not null,
  path_check_reason integer not null,
  path_check_node_id integer not null,
  path_check_iface_id integer not null,
  syslog_msg_count bigint not null,
  snmp_trap_count bigint not null,
  node_type integer not null,
  node_subtype varchar(127) null,
  hypervisor_type varchar(31) null,
  hypervisor_info varchar(255) null,
  ssh_login varchar(63) null,
  ssh_password varchar(63) null,
  ssh_port integer not null,
  ssh_key_id integer not null,
  ssh_proxy integer not null,
  vnc_password varchar(63) null,
  vnc_port integer not null,
  vnc_proxy integer not null,
  port_rows integer not null,
  port_numbering_scheme integer not null,
  agent_comp_mode char(1) not null,
  capabilities bigint not null,
  fail_time_snmp integer not null,
  fail_time_agent integer not null,
  fail_time_ssh integer not null,
  icmp_poll_mode char(1) not null,
  chassis_placement_config varchar(2000) null,
  vendor varchar(127) null,
  product_name varchar(127) null,
  product_version varchar(15) null,
  product_code varchar(31) null,
  serial_number varchar(31) null,
  eip_port integer not null,
  cip_device_type integer not null,
  cip_status integer not null,
  cip_state integer not null,
  cip_vendor_code integer not null,
  syslog_codepage varchar(15) null,
  snmp_codepage varchar(15) null,
  ospf_router_id varchar(15) null,
  mqtt_proxy integer not null,
  modbus_proxy integer not null,
  modbus_tcp_port integer not null,
  modbus_unit_id integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE icmp_target_address_list
(
  node_id integer not null,
  ip_addr varchar(48) not null,
  PRIMARY KEY(node_id,ip_addr)
) ;
CREATE TABLE software_inventory
(
  node_id integer not null,
  name varchar(127) not null,
  version varchar(63) not null,
  vendor varchar(63) null,
  install_date integer not null,
  url varchar(255) null,
  description varchar(255) null,
  uninstall_key varchar(255) null,
  PRIMARY KEY(node_id,name,version)
) ;
CREATE TABLE hardware_inventory
(
  node_id integer not null,
  category integer not null,
  component_index integer not null,
  hw_type varchar(47) null,
  vendor varchar(127) null,
  model varchar(127) null,
  location varchar(63) null,
  capacity bigint null,
  part_number varchar(63) null,
  serial_number varchar(63) null,
  description varchar(255) null,
  PRIMARY KEY(node_id,category,component_index)
) ;
CREATE TABLE node_components
(
  node_id integer not null,
  component_index integer not null,
  parent_index integer not null,
  position integer not null,
  component_class integer not null,
  if_index integer not null,
  name varchar(255) null,
  description varchar(255) null,
  model varchar(255) null,
  serial_number varchar(63) null,
  vendor varchar(63) null,
  firmware varchar(127) null,
  PRIMARY KEY(node_id,component_index)
) ;
CREATE TABLE ospf_areas
(
  node_id integer not null,
  area_id varchar(15) not null,
  PRIMARY KEY(node_id,area_id)
) ;
CREATE TABLE ospf_neighbors
(
  node_id integer not null,
  router_id varchar(15) not null,
  area_id varchar(15) null,
  ip_address varchar(48) not null,
  remote_node_id integer not null,
  if_index integer not null,
  is_virtual char(1) not null,
  neighbor_state integer not null,
  PRIMARY KEY(node_id,router_id,if_index,ip_address)
) ;
CREATE TABLE clusters
(
  id integer not null,
  cluster_type integer not null,
  zone_guid integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE cluster_members
(
  cluster_id integer not null,
  node_id integer not null,
  PRIMARY KEY(cluster_id,node_id)
) ;
CREATE TABLE cluster_sync_subnets
(
  cluster_id integer not null,
  subnet_addr varchar(48) not null,
  subnet_mask integer not null,
  PRIMARY KEY(cluster_id,subnet_addr)
) ;
CREATE TABLE cluster_resources
(
  cluster_id integer not null,
  resource_id integer not null,
  resource_name varchar(255),
  ip_addr varchar(48) not null,
  current_owner integer not null,
  PRIMARY KEY(cluster_id,resource_id)
) ;
CREATE TABLE subnets
(
  id integer not null,
  ip_addr varchar(48) not null,
  ip_netmask integer not null,
  zone_guid integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE interfaces
(
  id integer not null,
  node_id integer not null,
  parent_iface integer not null,
  if_type integer not null,
  if_index integer not null,
  mtu integer not null,
  speed bigint not null,
  bridge_port integer not null,
  phy_chassis integer not null,
  phy_module integer not null,
  phy_pic integer not null,
  phy_port integer not null,
  peer_node_id integer not null,
  peer_if_id integer not null,
  peer_proto integer not null,
  mac_addr varchar(16) null,
  required_polls integer not null,
  admin_state integer not null,
  oper_state integer not null,
  dot1x_pae_state integer not null,
  dot1x_backend_state integer not null,
  description varchar(255) null,
  if_name varchar(255) null,
  if_alias varchar(255) null,
  iftable_suffix varchar(127) null,
  last_known_oper_state integer not null,
  last_known_admin_state integer not null,
  ospf_area varchar(15) null,
  ospf_if_type integer not null,
  ospf_if_state integer not null,
  stp_port_state integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE interface_vlan_list
(
  iface_id integer not null,
  vlan_id integer not null,
  PRIMARY KEY(iface_id,vlan_id)
) ;
CREATE TABLE interface_address_list
(
  iface_id integer not null,
  ip_addr varchar(48) not null,
  ip_netmask integer not null,
  PRIMARY KEY(iface_id,ip_addr)
) ;
CREATE TABLE network_services
(
  id integer not null,
  node_id integer not null,
  service_type integer not null,
  ip_bind_addr varchar(48) not null,
  ip_proto integer not null,
  ip_port integer not null,
  check_request text null,
  check_response text null,
  poller_node_id integer not null,
  required_polls integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE vpn_connectors
(
  id integer not null,
  node_id integer not null,
  peer_gateway integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE vpn_connector_networks
(
  vpn_id integer not null,
  network_type integer not null,
  ip_addr varchar(48) not null,
  ip_netmask integer not null,
  PRIMARY KEY(vpn_id,ip_addr)
) ;
CREATE TABLE object_containers
(
  id integer not null,
  object_class integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE conditions
(
  id integer not null,
  activation_event integer not null,
  deactivation_event integer not null,
  source_object integer not null,
  active_status integer not null,
  inactive_status integer not null,
  script text not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE cond_dci_map
(
  condition_id integer not null,
  sequence_number integer not null,
  dci_id integer not null,
  node_id integer not null,
  dci_func integer not null,
  num_polls integer not null,
  PRIMARY KEY(condition_id,sequence_number)
) ;
CREATE TABLE templates
(
  id integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE dct_node_map
(
  template_id integer not null,
  node_id integer not null,
  PRIMARY KEY(template_id,node_id)
) ;
CREATE TABLE nsmap
(
  subnet_id integer not null,
  node_id integer not null,
  PRIMARY KEY(subnet_id,node_id)
) ;
CREATE TABLE container_members
(
  container_id integer not null,
  object_id integer not null,
  PRIMARY KEY(container_id,object_id)
) ;
CREATE TABLE icmp_statistics
(
   object_id integer not null,
   poll_target varchar(63) not null,
   min_response_time integer not null,
   max_response_time integer not null,
   avg_response_time integer not null,
   last_response_time integer not null,
   packet_loss integer not null,
   sample_count integer not null,
   raw_response_times text null,
   PRIMARY KEY(object_id,poll_target)
) ;
CREATE TABLE acl
(
  object_id integer not null,
  user_id integer not null,
  access_rights integer not null,
  PRIMARY KEY(object_id,user_id)
) ;
CREATE TABLE trusted_objects
(
  object_id integer not null,
  trusted_object_id integer not null,
  PRIMARY KEY(object_id,trusted_object_id)
) ;
CREATE TABLE items
(
  item_id integer not null,
  node_id integer not null,
  template_id integer not null,
  template_item_id integer not null,
  guid varchar(36) not null,
  name varchar(1023) null,
  description varchar(255) null,
  flags integer not null,
  state_flags integer not null,
  source integer not null,
  snmp_port integer not null,
  snmp_version integer not null,
  datatype integer not null,
  transformed_datatype integer not null,
  polling_schedule_type char(1) not null,
  polling_interval integer not null,
  polling_interval_src varchar(255) null,
  retention_type char(1) not null,
  retention_time integer not null,
  retention_time_src varchar(255) null,
  status integer not null,
  snmp_raw_value_type integer not null,
  delta_calculation integer not null,
  transformation text,
  instance varchar(1023) null,
  system_tag varchar(255) null,
  resource_id integer not null,
  proxy_node integer not null,
  multiplier integer not null,
  units_name varchar(63) null,
  perftab_settings text null,
  instd_method integer not null,
  instd_data varchar(1023) null,
  instd_filter text null,
  samples integer not null,
  npe_name varchar(15) null,
  comments text null,
  instance_retention_time integer not null,
  grace_period_start integer not null,
  related_object integer not null,
  all_rearmed_event integer not null,
  PRIMARY KEY(item_id)
) ;
CREATE INDEX idx_items_node_id ON items(node_id);
CREATE TABLE thresholds
(
  threshold_id integer not null,
  item_id integer not null,
  sequence_number integer not null,
  fire_value varchar(255) null,
  rearm_value varchar(255) null,
  last_checked_value varchar(255) null,
  check_function integer not null,
  check_operation integer not null,
  sample_count integer not null,
  script text null,
  event_code integer not null,
  rearm_event_code integer not null,
  repeat_interval integer not null,
  current_state integer not null,
  current_severity integer not null,
  match_count integer not null,
  last_event_timestamp integer not null,
  last_event_message varchar(2000) null,
  state_before_maint char(1) not null,
  is_disabled char(1) not null,
  PRIMARY KEY(threshold_id)
) ;
CREATE INDEX idx_thresholds_item_id ON thresholds(item_id);
CREATE INDEX idx_thresholds_sequence ON thresholds(sequence_number);
CREATE TABLE dc_tables
(
  item_id integer not null,
  node_id integer not null,
  template_id integer not null,
  template_item_id integer not null,
  guid varchar(36) not null,
  name varchar(1023) null,
  description varchar(255) null,
  flags integer not null,
  state_flags integer not null,
  source integer not null,
  snmp_port integer not null,
  snmp_version integer not null,
  polling_schedule_type char(1) not null,
  polling_interval integer not null,
  polling_interval_src varchar(255) null,
  retention_type char(1) not null,
  retention_time integer not null,
  retention_time_src varchar(255) null,
  status integer not null,
  system_tag varchar(255) null,
  resource_id integer not null,
  proxy_node integer not null,
  perftab_settings text null,
  transformation_script text null,
  comments text null,
  instance varchar(1023) null,
  instd_method integer not null,
  instd_data varchar(1023) null,
  instd_filter text null,
  instance_retention_time integer not null,
  grace_period_start integer not null,
  related_object integer not null,
  PRIMARY KEY(item_id)
) ;
CREATE INDEX idx_dc_tables_node_id ON dc_tables(node_id);
CREATE TABLE dc_table_columns
(
  table_id integer not null,
  sequence_number integer not null,
  column_name varchar(63) not null,
  snmp_oid varchar(1023) null,
  flags integer not null,
  display_name varchar(255) null,
  PRIMARY KEY(table_id,column_name)
) ;
CREATE TABLE dct_thresholds
(
  id integer not null,
  table_id integer not null,
  sequence_number integer not null,
  activation_event integer not null,
  deactivation_event integer not null,
  sample_count integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE dct_threshold_conditions
(
  threshold_id integer not null,
  group_id integer not null,
  sequence_number integer not null,
  column_name varchar(63) null,
  check_operation integer not null,
  check_value varchar(255) null,
  PRIMARY KEY(threshold_id,group_id,sequence_number)
) ;
CREATE TABLE dct_threshold_instances
(
  threshold_id integer not null,
  instance_id integer not null,
  instance varchar(255) not null,
  match_count integer not null,
  is_active char(1) not null,
  tt_row_number integer not null,
  maint_copy char(1) not null,
  PRIMARY KEY(threshold_id,instance_id)
) ;
CREATE TABLE dci_schedules
(
  item_id integer not null,
  schedule_id integer not null,
  schedule varchar(255) null,
  PRIMARY KEY(item_id,schedule_id)
) ;
CREATE TABLE raw_dci_values
(
  item_id integer not null,
  raw_value varchar(255) null,
  transformed_value varchar(255) null,
  last_poll_time integer not null,
  cache_timestamp integer not null,
  anomaly_detected char(1) not null,
  PRIMARY KEY(item_id)
) ;
CREATE TABLE dci_access
(
   dci_id integer not null,
   user_id integer not null,
   PRIMARY KEY(dci_id,user_id)
) ;
CREATE TABLE idata_sc_default
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_7
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_30
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_90
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_180
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_other
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
SELECT create_hypertable('idata_sc_default', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_7', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_30', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_90', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_180', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_other', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE VIEW idata AS
   SELECT * FROM idata_sc_default
   UNION ALL
   SELECT * FROM idata_sc_7
   UNION ALL
   SELECT * FROM idata_sc_30
   UNION ALL
   SELECT * FROM idata_sc_90
   UNION ALL
   SELECT * FROM idata_sc_180
   UNION ALL
   SELECT * FROM idata_sc_other;
CREATE TABLE tdata_sc_default
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_7
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_30
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_90
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_180
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_other
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
SELECT create_hypertable('tdata_sc_default', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_7', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_30', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_90', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_180', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_other', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE VIEW tdata AS
   SELECT * FROM tdata_sc_default
   UNION ALL
   SELECT * FROM tdata_sc_7
   UNION ALL
   SELECT * FROM tdata_sc_30
   UNION ALL
   SELECT * FROM tdata_sc_90
   UNION ALL
   SELECT * FROM tdata_sc_180
   UNION ALL
   SELECT * FROM tdata_sc_other;
CREATE TABLE event_cfg
(
  event_code integer not null,
  event_name varchar(63) not null,
  guid varchar(36) not null,
  severity integer not null,
  flags integer not null,
  message varchar(2000) null,
  description text null,
  tags varchar(2000) null,
  PRIMARY KEY(event_code)
) ;
CREATE TABLE event_log
(
  event_id bigint not null,
  event_code integer not null,
  event_timestamp timestamptz not null,
  origin integer not null,
  origin_timestamp integer not null,
  event_source integer not null,
  zone_uin integer not null,
  dci_id integer not null,
  event_severity integer not null,
  event_message varchar(2000) null,
  event_tags varchar(2000) null,
  root_event_id bigint not null,
  raw_data text null,
  PRIMARY KEY(event_id,event_timestamp)
) ;
CREATE INDEX idx_event_log_event_timestamp ON event_log(event_timestamp);
CREATE INDEX idx_event_log_source ON event_log(event_source);
CREATE INDEX idx_event_log_root_id ON event_log(root_event_id) WHERE root_event_id > 0;
SELECT create_hypertable('event_log', 'event_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE notification_log
(
  id bigint not null,
  notification_timestamp timestamptz not null,
  notification_channel varchar(63) not null,
  recipient varchar(2000) null,
  subject varchar(2000) null,
  message varchar(2000) null,
  success char(1) not null,
  PRIMARY KEY(id,notification_timestamp)
) ;
CREATE INDEX idx_notification_log_timestamp ON notification_log(notification_timestamp);
SELECT create_hypertable('notification_log', 'notification_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE server_action_execution_log
(
  id bigint not null,
  action_timestamp timestamptz not null,
  action_id integer not null,
  action_name varchar(63) null,
  channel_name varchar(63) null,
  recipient varchar(2000) null,
  subject varchar(2000) null,
  action_data varchar(2000) null,
  event_id bigint not null,
  event_code integer not null,
  success char(1) not null,
  PRIMARY KEY(id,action_timestamp)
) ;
CREATE INDEX idx_srv_action_log_timestamp ON server_action_execution_log(action_timestamp);
SELECT create_hypertable('server_action_execution_log', 'action_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE actions
(
  action_id integer not null,
  guid varchar(36) not null,
  action_name varchar(63) not null,
  action_type integer not null,
  is_disabled integer not null,
  rcpt_addr varchar(255) null,
  email_subject varchar(255) null,
  action_data text null,
  channel_name varchar(63) null,
  PRIMARY KEY(action_id)
) ;
CREATE TABLE event_policy
(
  rule_id integer not null,
  rule_guid varchar(36) not null,
  flags integer not null,
  comments text null,
  filter_script text null,
  alarm_message varchar(2000) null,
  alarm_impact varchar(1000) null,
  alarm_severity integer not null,
  alarm_key varchar(255) null,
  alarm_timeout integer not null,
  alarm_timeout_event integer not null,
  downtime_tag varchar(15) null,
  rca_script_name varchar(255) null,
  action_script text null,
  PRIMARY KEY(rule_id)
) ;
CREATE TABLE policy_source_list
(
  rule_id integer not null,
  object_id integer not null,
  exclusion char(1) not null,
  PRIMARY KEY(rule_id,object_id,exclusion)
) ;
CREATE TABLE policy_event_list
(
  rule_id integer not null,
  event_code integer not null,
  PRIMARY KEY(rule_id,event_code)
) ;
CREATE TABLE policy_time_frame_list
(
  rule_id integer not null,
  time_frame_id integer not null,
  date_filter bigint not null,
  time_filter integer not null,
  PRIMARY KEY(rule_id,time_frame_id)
) ;
CREATE TABLE policy_action_list
(
  rule_id integer not null,
  action_id integer not null,
  timer_delay varchar(127) null,
  timer_key varchar(127) null,
  blocking_timer_key varchar(127) null,
  snooze_time varchar(127) null,
  active char(1) not null
) ;
CREATE TABLE policy_timer_cancellation_list
(
  rule_id integer not null,
  timer_key varchar(127) not null,
  PRIMARY KEY(rule_id,timer_key)
) ;
CREATE TABLE policy_pstorage_actions
(
  rule_id integer not null,
  ps_key varchar(127) not null,
  action char(1) not null,
  value varchar(2000) null,
  PRIMARY KEY(rule_id,ps_key,action)
) ;
CREATE TABLE policy_cattr_actions
(
  rule_id integer not null,
  attribute_name varchar(127) not null,
  action char(1) not null,
  value varchar(2000) null,
  PRIMARY KEY(rule_id,attribute_name,action)
) ;
CREATE TABLE alarms
(
  alarm_id integer not null,
  parent_alarm_id integer not null,
  alarm_state integer not null,
  hd_state integer not null,
  hd_ref varchar(63) null,
  creation_time integer not null,
  last_change_time integer not null,
  last_state_change_time integer not null,
  rule_guid varchar(36) null,
  rule_description varchar(255) null,
  source_object_id integer not null,
  zone_uin integer not null,
  source_event_code integer not null,
  source_event_id bigint not null,
  dci_id integer not null,
  message varchar(2000) null,
  original_severity integer not null,
  current_severity integer not null,
  repeat_count integer not null,
  alarm_key varchar(255) null,
  ack_by integer not null,
  resolved_by integer not null,
  term_by integer not null,
  timeout integer not null,
  timeout_event integer not null,
  ack_timeout integer not null,
  alarm_category_ids varchar(255) null,
  event_tags varchar(2000) null,
  rca_script_name varchar(255) null,
  impact varchar(1000) null,
  PRIMARY KEY(alarm_id)
) ;
CREATE INDEX idx_alarms_source_object_id ON alarms(source_object_id);
CREATE INDEX idx_alarms_last_change_time ON alarms(last_change_time);
CREATE INDEX idx_alarms_alarm_state ON alarms(alarm_state);
CREATE TABLE alarm_notes
(
  note_id integer not null,
  alarm_id integer not null,
  change_time integer not null,
  user_id integer not null,
  note_text text null,
  PRIMARY KEY(note_id)
) ;
CREATE INDEX idx_alarm_notes_alarm_id ON alarm_notes(alarm_id);
CREATE TABLE alarm_events
(
  alarm_id integer not null,
  event_id bigint not null,
  event_code integer not null,
  event_name varchar(63) null,
  severity integer not null,
  source_object_id integer not null,
  event_timestamp integer not null,
  message varchar(2000) null,
  PRIMARY KEY(alarm_id,event_id)
) ;
CREATE INDEX idx_alarm_events_alarm_id ON alarm_events(alarm_id);
CREATE TABLE alarm_categories
(
  id integer not null,
  name varchar(63) null,
  descr varchar(255) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE alarm_category_acl
(
  category_id integer not null,
  user_id integer not null,
  PRIMARY KEY(category_id,user_id)
) ;
CREATE TABLE alarm_category_map
(
  alarm_id integer not null,
  category_id integer not null,
  PRIMARY KEY(alarm_id,category_id)
) ;
CREATE TABLE alarm_state_changes
(
   record_id bigint not null,
   alarm_id integer not null,
   prev_state integer not null,
   new_state integer not null,
   change_time integer not null,
   prev_state_duration integer not null,
   change_by integer not null,
   PRIMARY KEY(record_id)
) ;
CREATE INDEX idx_alarm_state_changes_by_id ON alarm_state_changes(alarm_id);
CREATE TABLE snmp_trap_cfg
(
  guid varchar(36) not null,
  trap_id integer not null,
  snmp_oid varchar(255),
  event_code integer not null,
  user_tag varchar(63),
  description varchar(255),
  transformation_script text null,
  PRIMARY KEY(trap_id)
) ;
CREATE TABLE snmp_trap_pmap
(
  trap_id integer not null,
  parameter integer not null,
  flags integer not null,
  snmp_oid varchar(255) null,
  description varchar(255) null,
  PRIMARY KEY(trap_id,parameter)
) ;
CREATE TABLE agent_pkg
(
  pkg_id integer not null,
  pkg_type varchar(15) null,
  pkg_name varchar(63) not null,
  version varchar(31) null,
  platform varchar(63) null,
  pkg_file varchar(255) null,
  description varchar(255) null,
  command varchar(255) null,
  PRIMARY KEY(pkg_id)
) ;
CREATE TABLE object_tools
(
  tool_id integer not null,
  guid varchar(36) not null,
  tool_name varchar(255) null,
  tool_type integer not null,
  tool_data text null,
  description varchar(255) null,
  flags integer not null,
  tool_filter text null,
  confirmation_text varchar(255) null,
  command_name varchar(255) null,
  command_short_name varchar(31) null,
  icon text null,
  remote_port integer not null,
  PRIMARY KEY(tool_id)
) ;
CREATE TABLE object_tools_acl
(
  tool_id integer not null,
  user_id integer not null,
  PRIMARY KEY(tool_id,user_id)
) ;
CREATE TABLE object_tools_table_columns
(
  tool_id integer not null,
  col_number integer not null,
  col_name varchar(255) null,
  col_oid varchar(255) null,
  col_format integer,
  col_substr integer,
  PRIMARY KEY(tool_id,col_number)
) ;
CREATE TABLE input_fields
(
  category char(1) not null,
  owner_id integer not null,
  name varchar(31) not null,
  input_type char(1) not null,
  display_name varchar(127) null,
  sequence_num integer not null,
  flags integer not null,
  PRIMARY KEY(category,owner_id,name)
) ;
CREATE TABLE syslog
(
  msg_id bigint not null,
  msg_timestamp timestamptz not null,
  facility integer not null,
  severity integer not null,
  source_object_id integer not null,
  zone_uin integer not null,
  hostname varchar(127) null,
  msg_tag varchar(32) null,
  msg_text text null,
  PRIMARY KEY(msg_id,msg_timestamp)
) ;
CREATE INDEX idx_syslog_msg_timestamp ON syslog(msg_timestamp);
CREATE INDEX idx_syslog_source ON syslog(source_object_id);
SELECT create_hypertable('syslog', 'msg_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE script_library
(
  guid varchar(36) not null,
  script_id integer not null,
  script_name varchar(255) not null,
  script_code text null,
  PRIMARY KEY(script_id)
) ;
CREATE TABLE snmp_trap_log
(
  trap_id bigint not null,
  trap_timestamp timestamptz not null,
  ip_addr varchar(48) not null,
  object_id integer not null,
  zone_uin integer not null,
  trap_oid varchar(255) not null,
  trap_varlist text null,
  PRIMARY KEY(trap_id,trap_timestamp)
) ;
CREATE INDEX idx_snmp_trap_log_tt ON snmp_trap_log(trap_timestamp);
CREATE INDEX idx_snmp_trap_log_oid ON snmp_trap_log(object_id);
SELECT create_hypertable('snmp_trap_log', 'trap_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE agent_configs
(
  config_id integer not null,
  config_name varchar(255) not null,
  config_file text not null,
  config_filter text not null,
  sequence_number integer not null,
  PRIMARY KEY(config_id)
) ;
CREATE TABLE address_lists
(
  list_type integer not null,
  community_id integer not null,
  zone_uin integer not null,
  proxy_id integer not null,
  addr_type integer not null,
  addr1 varchar(48) not null,
  addr2 varchar(48) not null,
  comments varchar(255) null,
  PRIMARY KEY(list_type,community_id,zone_uin,addr_type,addr1,addr2)
) ;
CREATE INDEX idx_address_lists_list_type ON address_lists(list_type);
CREATE TABLE graphs
(
  graph_id integer not null,
  owner_id integer not null,
  flags integer not null,
  name varchar(255) not null,
  config text null,
  filters text null,
  PRIMARY KEY(graph_id)
) ;
CREATE TABLE graph_acl
(
  graph_id integer not null,
  user_id integer not null,
  user_rights integer not null,
  PRIMARY KEY(graph_id,user_id)
) ;
CREATE TABLE certificate_action_log
(
  record_id integer not null,
  operation_timestamp timestamptz not null,
  operation integer not null,
  user_id integer not null,
  node_id integer not null,
  node_guid varchar(36) null,
  cert_type integer not null,
  subject varchar(255) null,
  serial integer null,
  PRIMARY KEY(record_id,operation_timestamp)
) ;
CREATE INDEX idx_cert_action_log_timestamp ON certificate_action_log(operation_timestamp);
SELECT create_hypertable('certificate_action_log', 'operation_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE audit_log
(
  record_id integer not null,
  timestamp integer not null,
  subsystem varchar(32) not null,
  success integer not null,
  user_id integer not null,
  workstation varchar(63) not null,
  session_id integer not null,
  object_id integer not null,
  message text null,
  old_value text null,
  new_value text null,
  value_type char(1) null,
  hmac varchar(64) null,
  PRIMARY KEY(record_id)
) ;
CREATE TABLE persistent_storage
(
  entry_key varchar(127) not null,
  value varchar(2000) null,
  PRIMARY KEY(entry_key)
) ;
CREATE TABLE snmp_communities
(
  id integer not null,
  community varchar(255) null,
  zone integer not null,
  PRIMARY KEY(id,zone)
) ;
CREATE TABLE ap_common
(
  guid varchar(36) not null,
  owner_id integer not null,
  policy_name varchar(63) not null,
  policy_type varchar(31) not null,
  version integer not null,
  flags integer not null,
  file_content text null,
  PRIMARY KEY(guid)
) ;
CREATE TABLE usm_credentials
(
  id integer not null,
  user_name varchar(255) not null,
  auth_method integer not null,
  priv_method integer not null,
  auth_password varchar(255) null,
  priv_password varchar(255) null,
  zone integer not null,
  comments varchar(255) null,
  PRIMARY KEY(id,zone)
) ;
CREATE TABLE well_known_ports
(
   tag varchar(15) not null,
   zone integer not null,
   id integer not null,
   port integer not null,
   PRIMARY KEY(tag,zone,id)
) ;
CREATE TABLE network_maps
(
  id integer not null,
  map_type integer not null,
  layout integer not null,
  radius integer not null,
  background varchar(36) null,
  bg_latitude varchar(20) null,
  bg_longitude varchar(20) null,
  bg_zoom integer null,
  bg_color integer not null,
  link_color integer not null,
  link_routing integer not null,
  link_width integer not null,
  link_style integer not null,
  object_display_mode integer not null,
  filter text null,
  link_styling_script text null,
  width integer not null,
  height integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE network_map_elements
(
  map_id integer not null,
  element_id integer not null,
  element_type integer not null,
  element_data text not null,
  flags integer not null,
  PRIMARY KEY(map_id,element_id)
) ;
CREATE TABLE network_map_links
(
  map_id integer not null,
  link_id integer not null,
  element1 integer not null,
  interface1 integer not null,
  element2 integer not null,
  interface2 integer not null,
  link_type integer not null,
  link_name varchar(255) null,
  connector_name1 varchar(255) null,
  connector_name2 varchar(255) null,
  element_data text null,
  flags integer not null,
  color_source integer not null,
  color integer not null,
  color_provider varchar(255) null,
  PRIMARY KEY(map_id,link_id)
) ;
CREATE INDEX idx_network_map_links_map_id ON network_map_links(map_id);
CREATE TABLE network_map_seed_nodes
(
  map_id integer not null,
  seed_node_id integer not null,
  PRIMARY KEY(map_id,seed_node_id)
) ;
CREATE TABLE network_map_deleted_nodes
(
  map_id integer not null,
  object_id integer not null,
  element_index integer not null,
  position_x integer not null,
  position_y integer not null,
  PRIMARY KEY(map_id, object_id)
) ;
CREATE TABLE images
(
  guid varchar(36) not null,
  name varchar(63) not null,
  category varchar(63) not null,
  mimetype varchar(32) not null,
  protected integer default 0,
  PRIMARY KEY(guid),
  UNIQUE(name, category)
) ;
CREATE TABLE dashboards
(
  id integer not null,
  num_columns integer not null,
  display_priority integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE dashboard_elements
(
  dashboard_id integer not null,
  element_id integer not null,
  element_type integer not null,
  element_data text null,
  layout_data text null,
  PRIMARY KEY(dashboard_id,element_id)
) ;
CREATE TABLE dashboard_associations
(
  object_id integer not null,
  dashboard_id integer not null,
  PRIMARY KEY(object_id,dashboard_id)
) ;
CREATE TABLE business_services
(
  id integer not null,
  prototype_id integer not null,
  instance varchar(1023),
  object_status_threshold integer not null,
  dci_status_threshold integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE business_service_prototypes
(
  id integer not null,
  instance_method integer not null,
  instance_source integer not null,
  instance_data varchar(1023),
  instance_filter text,
  object_status_threshold integer not null,
  dci_status_threshold integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE business_service_checks
(
  id integer not null,
  service_id integer not null,
  prototype_service_id integer not null,
  prototype_check_id integer not null,
  type integer not null,
  description varchar(1023),
  related_object integer not null,
  related_dci integer not null,
  status_threshold integer not null,
  content text null,
  status integer not null,
  current_ticket integer not null,
  failure_reason varchar(255) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE slm_agreements
(
  agreement_id integer not null,
  service_id integer not null,
  org_id integer not null,
  uptime varchar(63) not null,
  period integer not null,
  start_date integer not null,
  notes varchar(255),
  PRIMARY KEY(agreement_id)
) ;
CREATE TABLE business_service_tickets
(
  ticket_id integer not null,
  service_id integer not null,
  original_ticket_id integer not null,
  original_service_id integer not null,
  check_id integer not null,
  check_description varchar(1023),
  create_timestamp integer not null,
  close_timestamp integer not null,
  reason varchar(255) null,
  PRIMARY KEY(ticket_id)
) ;
CREATE TABLE business_service_downtime
(
  record_id integer not null,
  service_id integer not null,
  from_timestamp integer not null,
  to_timestamp integer not null,
  PRIMARY KEY(record_id)
) ;
CREATE TABLE organizations
(
  id integer not null,
  parent_id integer not null,
  org_type integer not null,
  name varchar(63) not null,
  description varchar(255),
  manager integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE persons
(
  id integer not null,
  org_id integer not null,
  first_name varchar(63),
  last_name varchar(63),
  title varchar(255),
  status integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE licenses
(
  id integer not null,
  content varchar(2000) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE mapping_tables
(
  id integer not null,
  name varchar(63) not null,
  flags integer not null,
  description varchar(4000) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE mapping_data
(
  table_id integer not null,
  md_key varchar(63) not null,
  md_value varchar(4000) null,
  description varchar(4000) null,
  PRIMARY KEY(table_id,md_key)
) ;
CREATE TABLE dci_summary_tables
(
  id integer not null,
  guid varchar(36) not null,
  menu_path varchar(255) null,
  title varchar(127) null,
  node_filter text null,
  flags integer not null,
  columns text null,
  table_dci_name varchar(255) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE scheduled_tasks
(
  id integer not null,
  taskId varchar(255) null,
  schedule varchar(127) null,
  params varchar(1023) null,
  execution_time integer not null,
  last_execution_time integer not null,
  flags integer not null,
  owner integer not null,
  object_id integer not null,
  comments varchar(255) null,
  task_key varchar(255) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE currency_codes
(
 numeric_code char(3) not null,
 alpha_code char(3) not null,
 description varchar(127) not null,
 exponent integer not null,
 PRIMARY KEY(numeric_code)
) ;
CREATE TABLE country_codes
(
 numeric_code char(3) not null,
 alpha_code char(2) not null,
 alpha3_code char(3) not null,
 name varchar(127) not null,
 PRIMARY KEY(numeric_code)
) ;
CREATE TABLE config_repositories
(
 id integer not null,
 url varchar(1023) not null,
 auth_token varchar(63) null,
 description varchar(1023) null,
 PRIMARY KEY(id)
) ;
CREATE TABLE port_layouts
(
   device_oid varchar(127) not null,
   numbering_scheme char(1) not null,
   row_count char(1) not null,
   layout_data varchar(4000) null,
   PRIMARY KEY(device_oid)
) ;
CREATE TABLE object_access_snapshot
(
   user_id integer not null,
   object_id integer not null,
   access_rights integer not null,
   PRIMARY KEY(user_id,object_id)
) ;
CREATE TABLE sensors
(
   id integer not null,
   gateway_node integer not null,
   device_class integer not null,
   modbus_unit_id integer not null,
   capabilities integer not null,
   mac_address varchar(16) null,
   vendor varchar(127) null,
   model varchar(127) null,
   serial_number varchar(63) null,
   device_address varchar(127) null,
   PRIMARY KEY(id)
) ;
CREATE TABLE responsible_users
(
   object_id integer not null,
   user_id integer not null,
   tag varchar(31) null,
   PRIMARY KEY(object_id,user_id)
) ;
CREATE TABLE auto_bind_target
(
   object_id integer not null,
   bind_filter_1 text null,
   bind_filter_2 text null,
   flags integer not null,
   PRIMARY KEY(object_id)
) ;
CREATE TABLE versionable_object
(
   object_id integer not null,
   version integer not null,
   PRIMARY KEY(object_id)
) ;
CREATE TABLE user_agent_notifications
(
   id integer not null,
   message varchar(1023) null,
   objects varchar(1023) not null,
   start_time integer not null,
   end_time integer not null,
   recall char(1) not null,
   on_startup char(1) not null,
   creation_time integer not null,
   created_by integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE notification_channels
(
   name varchar(63) not null,
   driver_name varchar(63) not null,
   description varchar(255) null,
   configuration text null,
   PRIMARY KEY(name)
) ;
CREATE TABLE nc_persistent_storage
(
   channel_name varchar(63) not null,
   entry_name varchar(127) not null,
   entry_value varchar(2000) null,
   PRIMARY KEY(channel_name, entry_name)
) ;
CREATE TABLE two_factor_auth_methods
(
   name varchar(63) not null,
   driver varchar(63) null,
   description varchar(255) null,
   configuration text null,
   PRIMARY KEY(name)
) ;
CREATE TABLE two_factor_auth_bindings
(
   user_id integer not null,
   name varchar(63) not null,
   configuration text null,
   PRIMARY KEY(user_id,name)
) ;
CREATE TABLE websvc_definitions
(
   id integer not null,
   guid varchar(36) not null,
   name varchar(63) not null,
   description varchar(2000) null,
   url varchar(4000) null,
   http_request_method integer not null,
   request_data varchar(4000) null,
   flags integer not null,
   auth_type integer not null,
   login varchar(255) null,
   password varchar(255) null,
   cache_retention_time integer not null,
   request_timeout integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE websvc_headers
(
   websvc_id integer not null,
   name varchar(63) not null,
   value varchar(2000) null,
   PRIMARY KEY(websvc_id,name)
) ;
CREATE TABLE shared_secrets
(
   id integer not null,
   secret varchar(88) null,
   zone integer not null,
   PRIMARY KEY(id,zone)
) ;
CREATE TABLE dci_delete_list
(
   node_id integer not null,
   dci_id integer not null,
   type char(1) not null,
   PRIMARY KEY (node_id,dci_id)
) ;
CREATE TABLE win_event_log
(
   id bigint not null,
   event_timestamp timestamptz not null,
   node_id integer not null,
   zone_uin integer not null,
   origin_timestamp integer not null,
   log_name varchar(63) null,
   event_source varchar(127) null,
   event_severity integer not null,
   event_code integer not null,
   message varchar(2000) null,
   raw_data text null,
   PRIMARY KEY(id,event_timestamp)
) ;
CREATE INDEX idx_win_event_log_timestamp ON win_event_log(event_timestamp);
CREATE INDEX idx_win_event_log_node ON win_event_log(node_id);
SELECT create_hypertable('win_event_log', 'event_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE geo_areas
(
   id integer not null,
   name varchar(127) not null,
   comments text null,
   configuration text null,
   PRIMARY KEY(id)
) ;
CREATE TABLE dc_targets
(
   id integer not null,
   geolocation_ctrl_mode integer not null,
   geo_areas varchar(2000) null,
   web_service_proxy integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE pollable_objects
(
   id integer not null,
   config_poll_timestamp integer not null,
   instance_poll_timestamp integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE ssh_keys
(
   id integer not null,
   name varchar(255) not null,
   public_key text null,
   private_key text null,
   PRIMARY KEY(id)
) ;
CREATE TABLE ssh_credentials
(
   zone_uin integer not null,
   id integer not null,
   login varchar(63) null,
   password varchar(63) null,
   key_id integer not null,
   PRIMARY KEY(zone_uin,id)
) ;
CREATE TABLE vnc_credentials
(
   zone_uin integer not null,
   id integer not null,
   password varchar(63) null,
   PRIMARY KEY(zone_uin,id)
) ;
CREATE TABLE object_queries
(
   id integer not null,
   guid varchar(36) not null,
   name varchar(63) not null,
   description varchar(255) null,
   script text null,
   PRIMARY KEY(id)
) ;
CREATE TABLE maintenance_journal
(
   record_id integer not null,
   object_id integer not null,
   author integer not null,
   last_edited_by integer not null,
   description text null,
   creation_time timestamptz not null,
   modification_time timestamptz not null,
   PRIMARY KEY(record_id,creation_time)
) ;
CREATE INDEX idx_maintjrn_creation_time ON maintenance_journal(creation_time);
CREATE INDEX idx_maintjrn_object_id ON maintenance_journal(object_id);
SELECT create_hypertable('maintenance_journal', 'creation_time', chunk_time_interval => interval '86400 seconds');
CREATE TABLE am_attributes
(
   attr_name varchar(63) not null,
   display_name varchar(255) null,
   data_type integer not null,
   is_mandatory char(1) not null,
   is_unique char(1) not null,
   is_hidden char(1) not null,
   autofill_script text null,
   range_min integer not null,
   range_max integer not null,
   sys_type integer not null,
   PRIMARY KEY(attr_name)
) ;
CREATE TABLE am_enum_values
(
   attr_name varchar(63) not null,
   value varchar(63) not null,
   display_name varchar(255) not null,
   PRIMARY KEY(attr_name,value)
) ;
CREATE TABLE assets
(
   id integer not null,
   linked_object_id integer not null,
   last_update_timestamp integer not null,
   last_update_uid integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE asset_properties
(
   asset_id integer not null,
   attr_name varchar(63) not null,
   value varchar(2000) null,
   PRIMARY KEY(asset_id,attr_name)
) ;
CREATE TABLE asset_change_log
(
   record_id bigint not null,
   operation_timestamp timestamptz not null,
   asset_id integer not null,
   attribute_name varchar(63) null,
   operation integer not null,
   old_value varchar(2000) null,
   new_value varchar(2000) null,
   user_id integer not null,
   linked_object_id integer not null,
  PRIMARY KEY(record_id,operation_timestamp)
) ;
CREATE INDEX idx_srv_asset_log_timestamp ON asset_change_log(operation_timestamp);
CREATE INDEX idx_srv_asset_log_asset_id ON asset_change_log(asset_id);
SELECT create_hypertable('asset_change_log', 'operation_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE active_downtimes
(
   object_id integer not null,
   downtime_tag varchar(15) not null,
   start_time integer not null,
   PRIMARY KEY(object_id,downtime_tag)
) ;
CREATE TABLE downtime_log
(
   object_id integer not null,
   start_time integer not null,
   end_time integer not null,
   downtime_tag varchar(15) not null,
   PRIMARY KEY(object_id,start_time,downtime_tag)
) ;
INSERT INTO metadata (var_name,var_value) VALUES ('SchemaVersion',700);
INSERT INTO metadata (var_name,var_value) VALUES ('SchemaVersionMajor',51);
INSERT INTO metadata (var_name,var_value) VALUES ('SchemaVersionMinor',22);
INSERT INTO metadata (var_name,var_value) VALUES ('Syntax','TSDB');
INSERT INTO metadata (var_name,var_value) VALUES ('SingeTablePerfData','1');
INSERT INTO metadata (var_name,var_value)
 VALUES ('IDataTableCreationCommand','CREATE TABLE idata_%d (item_id integer not null,idata_timestamp integer not null,idata_value varchar(255) null,raw_value varchar(255) null)');
INSERT INTO metadata (var_name,var_value)
 VALUES ('IDataIndexCreationCommand_0','CREATE INDEX idx_idata_%d_id_timestamp ON idata_%d(item_id,idata_timestamp DESC)');
INSERT INTO metadata (var_name,var_value)
 VALUES ('TDataTableCreationCommand_0','CREATE TABLE tdata_%d (item_id integer not null,tdata_timestamp integer not null,tdata_value ' || 'text' || ' null)');
INSERT INTO metadata (var_name,var_value)
 VALUES ('TDataIndexCreationCommand_0','CREATE INDEX idx_tdata_%d ON tdata_%d(item_id,tdata_timestamp)');
INSERT INTO metadata (var_name,var_value)
 VALUES ('LocationHistory','CREATE TABLE gps_history_%d (latitude varchar(20), longitude varchar(20), accuracy integer not null, start_timestamp integer not null, end_timestamp integer not null, PRIMARY KEY(start_timestamp))');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ActionExecutionLog.RetentionTime','90','90',1,0,'I','Retention time in days for the records in server action execution log. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Agent.CommandTimeout','4000','4000',1,1,'I','Timeout in milliseconds for commands sent to agent. If agent did not respond to command within given number of seconds, command considered as failed.','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Agent.DefaultCacheMode','2','2',1,1,'C','Default agent cache mode','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Agent.DefaultEncryptionPolicy','1','1',1,1,'C','Set the default encryption policy for communications with agents.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Agent.DefaultProtocolCompressionMode','1','1',1,0,'C','Default agent protocol compression mode','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Agent.EnableRegistration','1','1',1,0,'B','Enable/disable agent self-registration','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Agent.RestartWaitTime','0','0',1,0,'I','Period of time after agent restart for which agent will not be considered unreachable.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Agent.Upgrade.NumberOfThreads','10','10',1,0,'I','The number of threads used to perform agent upgrades (i.e. maximum number of parallel upgrades).','threads');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Agent.Upgrade.WaitTime','600','600',1,0,'I','Maximum wait time in seconds for agent restart after upgrade. If agent cannot be contacted after this time period, upgrade process is considered as failed.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentPolicy.MaxFileSize','134217728','134217728',1,0,'I','Maximum file size for exported files in agent policies','bytes');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentTunnels.BindByIPAddress','0','0',1,0,'B','Enable/disable agent tunnel binding by IP address. If enabled and agent certificate is not provided, tunnel will be bound to node with IP address matching tunnel source IP address.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentTunnels.Certificates.ReissueInterval','30','30',1,1,'I','Interval in days between reissuing agent certificates.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentTunnels.Certificates.ValidityPeriod','90','90',1,1,'I','Validity period in days for newly issued agent certificates.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentTunnels.ListenPort','4703','4703',1,1,'I','TCP port number to listen on for incoming agent tunnel connections.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentTunnels.NewNodesContainer','','',1,0,'S','Name of the container where nodes created automatically for unbound tunnels will be placed. If empty or missing, such nodes will be created in infrastructure services root.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentTunnels.TLS.MinVersion','2','2',1,0,'C','Minimal version of TLS protocol used on agent tunnel connection.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentTunnels.UnboundTunnelTimeout','3600','3600',1,0,'I','Unbound agent tunnels inactivity timeout. If tunnel is not bound or closed after timeout, action defined by AgentTunnels.UnboundTunnelTimeoutAction parameter will be taken.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AgentTunnels.UnboundTunnelTimeoutAction','0','0',1,0,'C','Action to be taken when unbound agent tunnel idle timeout expires.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.DeleteAlarmsOfDeletedObject','1','1',1,0,'B','Enable/disable automatic alarm removal of an object when it is deleted.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.EnableTimedAck','1','1',1,1,'B','Enable/disable ability to acknowledge an alarm for a specific time.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.HistoryRetentionTime','180','180',1,0,'I','A number of days the server keeps an alarm history in the database.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.IgnoreHelpdeskState','0','0',1,0,'B','If set alarm helpdesk state will be ignored when resolving or terminating.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.ResolveExpirationTime','0','0',1,0,'I','Expiration time (in seconds) for resolved alarms. If set to non-zero, resolved and untouched alarms will be terminated automatically after given timeout.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.StrictStatusFlow','0','0',1,0,'B','Enable/disable strict alarm status flow (alarm can be terminated only after it has been resolved).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.SummaryEmail.Enable','0','0',1,0,'B','Enable/disable alarm summary e-mails.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.SummaryEmail.Recipients','','',1,0,'S','A semicolon separated list of alarm summary e-mail recipient addresses.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Alarms.SummaryEmail.Schedule','0 0 * * *','0 0 * * *',1,0,'S','Schedule for sending alarm summary e-mails in cron format.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AssetChangeLog.RetentionTime','90','90',1,0,'I','Retention time in days for the records in asset change log. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AuditLog.External.Facility','13','13',1,1,'I','Syslog facility to be used in audit log records sent to external server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AuditLog.External.Port','514','514',1,1,'I','UDP port of external syslog server to send audit records to.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AuditLog.External.Server','none','none',1,1,'S','External syslog server to send audit records to. If set to "none", external audit logging is disabled.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AuditLog.External.Severity','5','5',1,1,'I','Syslog severity to be used in audit log records sent to external server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AuditLog.External.Tag','netxmsd-audit','netxmsd-audit',1,1,'S','Syslog tag to be used in audit log records sent to external server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AuditLog.External.UseUTF8','0','0',1,0,'B','Changes audit log encoding to UTF-8','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('AuditLog.RetentionTime','90','90',1,0,'I','Retention time in days for the records in audit log. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Beacon.Hosts','','',1,1,'S','Comma-separated list of hosts to be used as beacons for checking NetXMS server network connectivity. Either DNS names or IP addresses can be used. This list is pinged by NetXMS server and if none of the hosts have responded, server considers that connection with network is lost and generates specific event.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Beacon.PollingInterval','1000','1000',1,1,'I','Interval in milliseconds between beacon hosts polls.','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Beacon.Timeout','1000','1000',1,1,'I','Timeout in milliseconds to consider beacon host unreachable.','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('BlockInactiveUserAccounts','0','0',1,0,'I','Inactivity time after which user account will be blocked (0 to disable blocking).','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('BusinessServices.Check.AutobindClassFilter','AccessPoint,Cluster,Interface,NetworkService,Node','AccessPoint,Cluster,Interface,NetworkService,Node',1,0,'S','Class filter for automatic creation of business service checks.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('BusinessServices.Check.Threshold.DataCollection','1','1',1,0,'C','Default threshold for business DCI service checks','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('BusinessServices.Check.Threshold.Objects','1','1',1,0,'C','Default threshold for business service objects checks','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('BusinessServices.History.RetentionTime','90','90',1,0,'I','Retention time for business service historical data','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('CAS.AllowedProxies','','',1,0,'S','Comma-separated list of allowed CAS proxies.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('CAS.Host','localhost','localhost',1,0,'S','CAS server DNS name or IP address.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('CAS.Port','8443','8443',1,0,'I','CAS server TCP port number.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('CAS.Service','https://127.0.0.1/nxmc','https://127.0.0.1/nxmc',1,0,'S','Service to validate (usually NetXMS web UI URL).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('CAS.TrustedCACert','','',1,0,'S','File system path to CAS server trusted CA certificate.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('CAS.ValidateURL','/cas/serviceValidate','/cas/serviceValidate',1,0,'S','URL for service validation on CAS server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('CertificateActionLog.RetentionTime','370','370',1,0,'I','Retention time in days for certificate action log. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.AlarmList.DisplayLimit','4096','4096',1,0,'I','Maximum alarm count that will be displayed on Alarm Browser page. Alarms that exceed this count will not be shown.','alarms');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,is_public,description,units) VALUES ('Client.DashboardDataExport.EnableInterpolation','1','1',1,1,'B','Y','Enable/disable data interpolation in dashboard data export.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.BaseURL','https://{server-name}','https://{server-name}',1,0,'S','Base URL for forming direct access URLs. Macro {server-name} can be used to insert name of the server where user is currently logged in.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.DefaultConsoleDateFormat','dd.MM.yyyy','dd.MM.yyyy',1,0,'S','Default date display format for GUI.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.DefaultConsoleShortTimeFormat','HH:mm','HH:mm',1,0,'S','Default short time display format for GUI.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.DefaultConsoleTimeFormat','HH:mm:ss','HH:mm:ss',1,0,'S','Default long time display format for GUI.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.DefaultLineChartPeriod','60','60',1,0,'I','Default period (in minutes) to display collected data for when opening ad-hoc line chart.','minutes');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.FirstPacketTimeout','2000','2000',1,0,'I','Timeout for receiving first packet from client after establishing TCP connection.','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.InactivityTimeout','0','0',1,0,'I','User inactivity timeout in seconds. Client will disconnect if no user activity detected within given time interval. Value of 0 disables inactivity timeout.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.KeepAliveInterval','60','60',1,1,'I','Interval in seconds between sending keep alive packets to connected clients.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.ListenerPort','4701','4701',1,1,'I','The server port for incoming client connections (such as management console).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.MinViewRefreshInterval','300','300',1,0,'I','Minimal interval between view refresh in milliseconds (hint for client).','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.ObjectBrowser.AutoApplyFilter','1','1',1,0,'B','Enable or disable object browser''s filter applying as user types (if disabled, user has to press ENTER to apply filter).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.ObjectBrowser.FilterDelay','300','300',1,0,'I','Delay between typing in object browser''s filter and applying it to object tree.','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.ObjectBrowser.MinFilterStringLength','1','1',1,0,'I','Minimal length of filter string in object browser required for automatic apply.','characters');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.ObjectBrowser.ShowTargetsUnderTemplates','0','0',1,0,'B','If enabled, template target objects (nodes, access points, etc.) will be shown under templates applied to those objects.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.ObjectOverview.ShowCommentsOnlyIfPresent','1','1',1,0,'B','If enabled, comments section in object overview will only be shown when object comments are not empty.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Client.TileServerURL','https://tile.netxms.org/osm/','http://tile.netxms.org/osm/',1,0,'S','The base URL for the tile server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBConnectionPool.BaseSize','10','10',1,1,'I','A number of connections to the database created on the server startup.','connections');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBConnectionPool.CooldownTime','300','300',1,1,'I','Inactivity time (in seconds) after which database connection will be closed.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBConnectionPool.MaxLifetime','14400','14400',1,1,'I','Maximum lifetime (in seconds) for a database connection.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBConnectionPool.MaxSize','30','30',1,1,'I','A maximum number of connections in the connection pool.','connections');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBLockInfo','','',0,0,'S','','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBLockPID','0','0',0,0,'I','','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBLockStatus','UNLOCKED','UNLOCKED',0,1,'S','','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.BackgroundWorkers','1','1',1,1,'I','Number of background workers for DCI data writer.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.DataQueues','1','1',1,1,'I','Number of queues for DCI data writer.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.InsertParallelismDegree','1','1',1,1,'I','Degree of parallelism for INSERT statements executed by DCI data writer (only valid for TimescaleDB).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.HouseKeeperInterlock','0','0',1,0,'C','Controls if server should block background write of collected performance data while housekeeper deletes expired records.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.MaxQueueSize','0','0',1,0,'I','Maximum size for DCI data writer queue (0 to disable size limit). If writer queue size grows above that threshold any new data will be dropped until queue size drops below threshold again.','elements');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.MaxRecordsPerStatement','100','100',1,1,'I','Maximum number of records per one SQL statement for delayed database writes','records/statement');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.MaxRecordsPerTransaction','1000','1000',1,1,'I','Maximum number of records per one transaction for delayed database writes','records/transaction');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.RawDataFlushInterval','30','30',1,1,'I','Interval between writes of accumulated raw DCI data to database.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DBWriter.UpdateParallelismDegree','1','1',1,1,'I','Degree of parallelism for UPDATE statements executed by raw DCI data writer.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.ApplyDCIFromTemplateToDisabledDCI','1','1',1,1,'B','Enable applying all DCIs from a template to the node, including disabled ones.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.DefaultDCIPollingInterval','60','60',1,0,'I','Default polling interval for newly created DCI (in seconds).','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.DefaultDCIRetentionTime','30','30',1,0,'I','Default retention time for newly created DCI (in days).','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.InstancePollingInterval','600','600',1,1,'I','Instance polling interval (in seconds).','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.InstanceRetentionTime','7','7',1,0,'I','Default retention time (in days) for missing DCI instances','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.OfflineDataRelevanceTime','86400','86400',1,1,'I','Time period in seconds within which received offline data still relevant for threshold validation.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.OnDCIDelete.TerminateRelatedAlarms','1','1',1,0,'B','Enable/disable automatic termination of related alarms when data collection item is deleted.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.ScriptErrorReportInterval','86400','86400',1,0,'I','Minimal interval between reporting errors in data collection related script.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.StartupDelay','0','0',1,1,'B','Enable/disable randomized data collection delays on server startup for evening server load distrubution.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.TemplateRemovalGracePeriod','0','0',1,0,'I','Setting up grace period for removing templates from target','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DataCollection.ThresholdRepeatInterval','0','0',1,1,'I','System-wide interval in seconds for resending threshold violation events. Value of 0 disables event resending.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DefaultNotificationChannel.SMTP.Html','SMTP-HTML','SMTP-HTML',1,0,'S','Default notification channel for SMTP HTML formatted messages','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DefaultNotificationChannel.SMTP.Text','SMTP-Text','SMTP-Text',1,0,'S','Default notification channel for SMTP Text formatted messages','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('DowntimeLog.RetentionTime','90','90',1,0,'I','Retention time in days for the records in downtime log. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('EnableISCListener','0','0',1,1,'B','Enable/disable Inter-Server Communications Listener.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Events.Correlation.TopologyBased','1','1',1,0,'B','Enable/disable topology based event correlation.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Events.DeleteEventsOfDeletedObject','1','1',1,0,'B','Enable/disable automatic event removal of an object when it is deleted.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Events.LogRetentionTime','90','90',1,0,'I','Retention time in days for the records in event log. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Events.Processor.PoolSize','1','1',1,1,'I','Number of threads for parallel event processing.','threads');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Events.Processor.QueueSelector','%z','%z',1,1,'S','Queue selector for parallel event processing.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Events.ReceiveForwardedEvents','0','0',1,0,'B','Enable/disable reception of events forwarded by another NetXMS server. Please note that for external event reception ISC listener should be enabled as well.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('EventStorm.Duration','15','15',1,1,'I','Time period for events per second to be above threshold that defines event storm condition.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('EventStorm.EnableDetection','0','0',1,1,'B','Enable/disable event storm detection.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('EventStorm.EventsPerSecond','1000','1000',1,1,'I','Threshold for number of events per second that defines event storm condition.','events/second');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('FirstFreeDCIId','1','1',0,1,'I','','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('FirstFreeObjectId','100','100',0,1,'I','','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Geolocation.History.RetentionTime','90','90',1,0,'I','Retention time in days for object''s geolocation history. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('HelpDeskLink','none','none',1,1,'S','Helpdesk driver name. If set to none, then no helpdesk driver is in use.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Housekeeper.DisableCollectedDataCleanup','0','0',1,0,'B','Disable automatic cleanup of collected DCI data during housekeeper run.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Housekeeper.StartTime','02:00','02:00',1,1,'S','Time when housekeeper starts. Housekeeper deletes expired log records and DCI data as well as cleans removed objects.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Housekeeper.Throttle.HighWatermark','250000','250000',1,0,'I','High watermark for housekeeper throttling','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Housekeeper.Throttle.LowWatermark','50000','50000',1,0,'I','Low watermark for housekeeper throttling','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ICMP.CollectPollStatistics','1','1',1,0,'B','Collect ICMP poll statistics for all nodes by default. When enabled ICMP ping is used on each status poll and response time and packet loss are collected.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ICMP.PingSize','46','46',1,0,'I','Size of ICMP packets (in bytes, including IP header size) used for polls.','bytes');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ICMP.PingTimeout','1500','1500',1,0,'I','Timeout for ICMP ping used for status polls (in milliseconds).','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ICMP.PollingInterval','60','60',1,0,'I','Interval between ICMP polls (in seconds).','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ICMP.StatisticPeriod','60','60',1,0,'I','Time period for collecting ICMP statistics (in number of polls).','polls');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.IssueType','Task','Task',1,0,'S','Jira issue type.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.Login','netxms','netxms',1,0,'S','Jira login name.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.Password','','',1,0,'S','Jira password.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.ProjectCode','NETXMS','NETXMS',1,0,'S','Jira project code.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.ProjectComponent','','',1,0,'S','Jira project component.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.ResolvedStatus','Done','Done',1,0,'S','Comma separated list of issue status codes indicating that issue is resolved.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.ServerURL','https://jira.atlassian.com','https://jira.atlassian.com',1,0,'S','The URL of the Jira server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.Webhook.Path','/jira-webhook','/jira-webhook',1,1,'S','Path part of Jira webhook URL (must start with /).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Jira.Webhook.Port','8008','8008',1,1,'I','Jira webhook listener port (0 to disable webhook).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.ConnectionString','ldap://localhost:389','ldap://localhost:389',1,0,'S','The LdapConnectionString configuration parameter may be a comma- or whitespace-separated list of URIs containing only the schema, the host, and the port fields. Format: schema://host:port.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.GroupClass','','',1,0,'S','Specifies which object class represents group objects. If the found entry is not of user or group class, it will be ignored.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.GroupUniqueId','','',1,0,'S','Unique identifier for LDAP group object. If not set, LDAP users are identified by DN.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.Mapping.Description','','',1,0,'S','The name of an attribute whose value will be used as a user''s description.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.Mapping.Email','','',1,0,'S','The name of an attribute whose value will be used as a user''s email.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.Mapping.FullName','displayName','displayName',1,0,'S','The name of an attribute whose value will be used as a user''s full name.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.Mapping.GroupName','','',1,0,'S','The name of an attribute whose value will be used as a group''s login name.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.Mapping.PhoneNumber','','',1,0,'S','The name of an attribute whose value will be used as a user''s phone number.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.Mapping.UserName','','',1,0,'S','The name of an attribute whose value will be used as a user''s login name.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.NewUserAuthMethod','5','5',1,0,'C','Authentication method to be set for user objects created by LDAP synchronization process.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.PageSize','1000','1000',1,0,'I','The maximum amount of records that can be returned in one search page.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.SearchBase','','',1,0,'S','The DN of the entry at which to start the search.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.SearchFilter','','',1,0,'S','A string representation of the filter to apply in the search.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.SyncInterval','0','0',1,0,'I','The synchronization interval (in minutes) between the NetXMS server and the LDAP server. If the parameter is set to 0, no synchronization will take place.','minutes');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.SyncUser','','',1,0,'S','User login for LDAP synchronization.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.SyncUserPassword','','',1,0,'S', 'User password for LDAP synchronization.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.UserClass','','',1,0,'S','The object class which represents user objects. If the found entry is not of user or group class, it will be ignored.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.UserDeleteAction','1','1',1,0,'C','This parameter specifies what should be done while synchronizing with a deleted user/group from LDAP.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LDAP.UserUniqueId','','',1,0,'S','Unique identifier for LDAP user object. If not set, LDAP users are identified by DN.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('LongRunningQueryThreshold','0','0',1,1,'I','Threshold in milliseconds to report long running SQL queries (0 to disable)','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('MaintenanceJournal.RetentionTime','1826','1826',1,0,'I','Retention time in days for maintenance journal entries. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('MobileDeviceListenerPort','4747','4747',1,1,'I','Listener port for connections from mobile agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDeviceDrivers.BlackList','','',1,1,'S','Comma separated list of blacklisted network device drivers.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.ActiveDiscovery.BlockSize','1024','1024',1,0,'I','Block size for active discovery.','addresses');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.ActiveDiscovery.EnableSNMPProbing','1','1',1,0,'B','Enable/disable SNMP probing during active network discovery. If enabled, server will send SNMP requests to detect devices that repond to SNMP but not to ICMP pings.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.ActiveDiscovery.EnableTCPProbing','0','0',1,0,'B','Enable/disable TCP probing during active network discovery. If enabled, server will try to establish TCP connection to list of well-known port to detect devices that are not responding to ICMP pings.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.ActiveDiscovery.InterBlockDelay','0','0',1,0,'I','Interval in milliseconds between scanning address blocks during active discovery.','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.ActiveDiscovery.Interval','7200','7200',1,0,'I','Interval in seconds between active network discovery polls.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.ActiveDiscovery.Schedule','','',1,0,'S','Schedule used to start active network discovery poll in cron format.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.DisableProtocolProbe.Agent','0','0',1,0,'B','Disable probing discovered addresses for NetXMS agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.DisableProtocolProbe.EtherNetIP','0','0',1,0,'B','Disable probing discovered addresses for EtherNet/IP support.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.DisableProtocolProbe.SNMP.V1','0','0',1,0,'B','Disable SNMP version 1 when probing discovered addresses for SNMP support.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.DisableProtocolProbe.SNMP.V2','0','0',1,0,'B','Disable SNMP version 2 when probing discovered addresses for SNMP support.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.DisableProtocolProbe.SNMP.V3','0','0',1,0,'B','Disable SNMP version 3 when probing discovered addresses for SNMP support.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.DisableProtocolProbe.SSH','0','0',1,0,'B','Disable probing discovered addresses for SSH support.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.Filter.Flags','0','0',1,0,'I','Discovery filter settings.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.Filter.Script','none','none',1,0,'S','Name of discovery filter script from script library.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.MergeDuplicateNodes','0','0',1,0,'B','Enable/disable merge of duplicate nodes. When enabled, configuration of duplicate node(s) will be merged into original node and duplicate(s) will be deleted.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.PassiveDiscovery.Interval','900','900',1,0,'I','Interval in seconds between passive network discovery polls.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.Type','0','0',1,1,'C','Type of the network discovery.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.UseDNSNameForDiscoveredNodes','0','0',1,0,'B','Enable/disable the use of DNS name instead of IP address as primary name for newly discovered nodes.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.UseFQDNForNodeNames','1','1',1,1,'B','Enable/disable the use of fully qualified domain names as primary names for newly discovered nodes.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.UseSNMPTraps','0','0',1,1,'B','Use SNMP trap information for new node discovery.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NetworkDiscovery.UseSyslog','0','0',1,1,'B','Use syslog messages for new node discovery.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NotificationChannels.MaxRetryCount','30','30',1,0,'I','Maximum count of retries to send a message for all notification channels.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NotificationLog.RetentionTime','90','90',1,0,'I','Retention time in days for the records in notification log. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NXSL.EnableContainerFunctions','1','1',1,0,'B','Enable/disable server-side NXSL functions for containers (such as CreateContainer, BindObject, etc.).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('NXSL.EnableFileIOFunctions','0','0',1,1,'B','Enable/disable server-side NXSL functions for file I/O (such as OpenFile, DeleteFile, etc.).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.AccessPoints.ContainerAutoBind','0','0',1,0,'B','Enable/disable container auto binding for access points.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.AccessPoints.RetentionTime','72','72',1,0,'I','Retention time for disappeared access points.','hours');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.AccessPoints.TemplateAutoApply','0','0',1,0,'B','Enable/disable template auto apply for access points.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Assets.AllowDeleteIfLinked','0','0',1,0,'B','Enable/disable deletion of linked assets.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.AutobindOnConfigurationPoll','1','1',1,0,'B','Enable/disable automatic object binding on configuration polls.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.AutobindPollingInterval','3600','3600',1,0,'I','Interval in seconds between automatic object binding polls.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Clusters.ContainerAutoBind','0','0',1,0,'B','Enable/disable container auto binding for clusters.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Clusters.TemplateAutoApply','0','0',1,0,'B','Enable/disable template auto apply for clusters.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Collectors.ContainerAutoBind','0','0',1,0,'B','Enable/disable container auto binding for collectors.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Collectors.TemplateAutoApply','0','0',1,0,'B','Enable/disable template auto apply for collectors.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Conditions.PollingInterval','60','60',1,1,'I','Interval in seconds between polling (re-evaluating) of condition objects.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.ConfigurationPollingInterval','3600','3600',1,0,'I','Interval in seconds between configuration polls.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.DeleteUnreachableNodesPeriod','0','0',1,0,'I','Delete nodes which were unreachable for a number of days specified by this parameter.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.EnableZoning','1','1',1,1,'B','Enable/disable zoning support','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Interfaces.ClearPeerOnUnmanage','0','0',1,0,'B','If set to true, interface peer will be cleared when interface is unmanaged.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Interfaces.DefaultExpectedState','1','1',1,0,'C','Default expected state for new interface objects.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Interfaces.Enable8021xStatusPoll','1','1',1,0,'B','Globally enable or disable checking of 802.1x port state during status poll.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Interfaces.IgnoreIfNotPresent','0','0',1,0,'B','If enabled, interfaces in "NOT PRESENT" state will be ignored when read from device.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Interfaces.NamePattern','','',1,0,'S','Custom name pattern for interface objects.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Interfaces.UseAliases','0','0',1,0,'C','Control usage of interface aliases (or descriptions).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Interfaces.UseIfXTable','1','1',1,0,'B','Enable/disable the use of SNMP ifXTable instead of ifTable for interface configuration polling.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Maintenance.PredefinedPeriods','1h,8h,1d','1h,8h,1d',1,0,'S','Predefined object maintenance periods. Use m for minutes, h for hours and d for days.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.MobileDevices.ContainerAutoBind','0','0',1,0,'B','Enable/disable container auto binding for mobile devices.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.MobileDevices.TemplateAutoApply','0','0',1,0,'B','Enable/disable template auto apply for mobile devices.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.NetworkMaps.DefaultBackgroundColor','0xffffff','0xffffff',1,0,'H','Default background color for new network map objects.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.NetworkMaps.DefaultHeight','850','850',1,0,'I','Default network map height.','pixels');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.NetworkMaps.DefaultWidth','1300','1300',1,0,'I','Default network map width.','pixels');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.NetworkMaps.UpdateInterval','60','60',1,0,'I','Interval in seconds between automatic map updates.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.CapabilityExpirationGracePeriod','3600','3600',1,0,'I','Grace period for capability expiration after node recovered from unreachable state.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.CapabilityExpirationTime','604800','604800',1,0,'I','Time before capability (NetXMS Agent, SNMP, EtherNet/IP) expires if node is not responding for requests via appropriate protocol.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.FallbackToLocalResolver','0','0',1,0,'B','Fallback to server''s local resolver if node address cannot be resolved via zone proxy.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.ReadWinPerfCountersOnDemand','1','1',1,0,'B','If set to true, list of supported Windows performance counters will be read only when requested by client, otherwise at each configuration poll.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.ResolveDNSToIPOnStatusPoll','0','0',1,0,'C','Resolve DNS to IP on status poll.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.ResolveDNSToIPOnStatusPoll.Interval','0','0',1,0,'I','Number of status polls between resolving primary host name to IP, if Objects.Nodes.ResolveDNSToIPOnStatusPoll set to "Always".','polls');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.ResolveNames','1','1',1,0,'B','Resolve node name using DNS, SNMP system name, or host name if current node name is it''s IP address.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.Resolver.AddressFamilyHint','0','0',1,0,'C','Address family hint for node DNS name resolver.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Nodes.SyncNamesWithDNS','0','0',1,0,'B','Enable/disable synchronization of node names with DNS on each configuration poll.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.PollCountForStatusChange','1','1',1,1,'I','The number of consecutive unsuccessful polls required to declare interface as down.','polls');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.ResponsibleUsers.AllowedTags','','',1,0,'S','Allowed tags for responsible users (comma separated list).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Security.CheckTrustedObjects','0','0',1,0,'B','Enable/disable trusted objects check for cross-object access.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Security.ReadAccessViaMap','0','0',1,0,'B','If enabled, user can get limited read only access to objects that are not normally accessible but referenced on network map that is accessible by the user.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Sensors.ContainerAutoBind','0','0',1,0,'B','Enable/disable container auto binding for sensors.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Sensors.TemplateAutoApply','0','0',1,0,'B','Enable/disable template auto apply for sensors.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.StatusCalculation.CalculationAlgorithm','1','1',1,1,'C','Default algorithm for calculation object status from it''s DCIs, alarms and child objects.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.StatusCalculation.FixedStatusValue','0','0',1,1,'I','Value for status propagation if StatusPropagationAlgorithm server configuration parameter is set to 2 (Fixed).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.StatusCalculation.PropagationAlgorithm','1','1',1,1,'C','Algorithm for status propagation (how object''s status affects its child object statuses).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.StatusCalculation.Shift','0','0',1,1,'I','Status shift value for Relative propagation algorithm.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.StatusCalculation.SingleThreshold','75','75',1,1,'I','Threshold value for Single threshold status calculation algorithm.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.StatusCalculation.Thresholds','503C2814','503C2814',1,1,'S','Threshold values for Multiple thresholds status calculation algorithm.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.StatusCalculation.Translation','01020304','01020304',1,1,'S','Values for Translated status propagation algorithm.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.StatusPollingInterval','60','60',1,0,'I','Interval in seconds between status polls.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Subnets.DefaultSubnetMaskIPv4','24','24',1,0,'I','Default mask for synthetic IPv4 subnets.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Subnets.DefaultSubnetMaskIPv6','64','64',1,0,'I','Default mask for synthetic IPv6 subnets.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.Subnets.DeleteEmpty','0','0',1,0,'B','Enable/disable automatic deletion of subnet objects without any nodes within.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Objects.SyncInterval','60','60',1,1,'I','Interval in seconds between writing object changes to the database.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.AuthMethod','PAP','PAP',1,0,'S','RADIUS authentication method to be used (PAP, CHAP, MS-CHAPv1, MS-CHAPv2).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.NumRetries','5','5',1,0,'I','The number of retries for RADIUS authentication.','retries');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.Port','1645','1645',1,0,'I','Port number used for connection to primary RADIUS server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.SecondaryPort','1645','1645',1,0,'I','Port number used for connection to secondary RADIUS server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.SecondarySecret','netxms','netxms',1,0,'S','Shared secret used for communication with secondary RADIUS server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.SecondaryServer','none','none',1,0,'S','Host name or IP address of secondary RADIUS server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.Secret','netxms','netxms',1,0,'S','Shared secret used for communication with primary RADIUS server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.Server','none','none',1,0,'S','Host name or IP address of primary RADIUS server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('RADIUS.Timeout','3','3',1,0,'I','Timeout in seconds for requests to RADIUS server.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ReportingServer.Enable','0','0',1,1,'B','Enable/disable reporting server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ReportingServer.JDBC.Properties','','',1,0,'S','Additional properties for JDBC connector on reporting server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ReportingServer.Hostname','127.0.0.1','127.0.0.1',1,1,'S','The hostname of the reporting server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ReportingServer.Port','4710','4710',1,1,'I','The port of the reporting server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Scheduler.TaskRetentionTime','86400','86400',1,0,'I','Retention time for completed non-recurrent scheduled tasks. Such tasks will be deleted automatically after given number of seconds since completion time.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.AllowedCiphers','63','63',1,1,'I','A bitmask for encryption algorithms allowed in the server (sum the values to allow multiple algorithms at once): 1 = AES256, 2 = Blowfish-256, 4 = IDEA, 8 = 3DES, 16 = AES128, 32 = Blowfish-128)','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Color','','',1,0,'H','Identification color for this server','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.CommandOutputTimeout','60','60',1,0,'I','Time (in seconds) to wait for output of a local command object tool.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.EscapeLocalCommands','0','0',1,0,'B','Enable/disable TAB and new line characters replacement by escape sequence in "execute command on management server" actions.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.ImportConfigurationOnStartup','1','1',1,1,'C','Import configuration from local files on server startup.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.MessageOfTheDay','','',1,0,'S','Message to be shown when a user logs into the console.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Name','','',1,0,'S','Name of this server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.RoamingMode','1','1',1,0,'B','Enable/disable roaming mode for server (when server can be disconnected from one network and connected to another or IP address of the server can change).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.2FA.TrustedDeviceTTL','0','0',1,0,'I','TTL in seconds for 2FA trusted device.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.CaseInsensitiveLoginNames','0','0',1,1,'B','Enable/disable case insensitive login names.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.ExtendedLogQueryAccessControl','0','0',1,0,'B','Enable/disable extended access control in log queries.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.GraceLoginCount','5','5',1,0,'I','User grace login count.','logins');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.IntruderLockoutThreshold','0','0',1,0,'I','Number of incorrect password attempts after which a user account is temporarily locked.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.IntruderLockoutTime','30','30',1,0,'I','Duration of user account temporarily lockout (in minutes) if allowed number of incorrect password attempts was exceeded.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.MinPasswordLength','0','0',1,0,'I','Default minimum password length for a NetXMS user. The default applied only if per-user setting is not defined.','characters');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.PasswordComplexity','0','0',1,0,'I','Set of flags to enforce password complexity.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.PasswordExpiration','0','0',1,0,'I','Password expiration time in days. If set to 0, password expiration is disabled.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.PasswordHistoryLength','0','0',1,0,'I','Number of previous passwords to keep. Users are not allowed to set password if it matches one from previous passwords list.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Server.Security.RestrictLocalConsoleAccess','1','1',1,0,'B','If enabled, restrict access to local server console only to authenticated users with server console access rights.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.AllowedVersions','7','7',1,0,'I','A bitmask for SNMP versions allowed by built-in SNMP agent (sum the values to allow multiple versions at once): 1 = version 1, 2 = version 2c, 4 = version 3).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.CommunityString','public','public',1,0,'S','Community string for SNMPv1/v2 requests to built-in SNMP agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.Enable','0','0',1,1,'B','Enable/disable built-in SNMP agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.ListenerPort','161','161',1,1,'I','Port used by built-in SNMP agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.V3.AuthenticationMethod','0','0',1,0,'C','Authentication method for SNMPv3 requests to built-in SNMP agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.V3.AuthenticationPassword','','',1,0,'S','Authentication password for SNMPv3 requests to built-in SNMP agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.V3.EncryptionMethod','0','0',1,0,'C','Encryption method for SNMPv3 requests to built-in SNMP agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.V3.EncryptionPassword','','',1,0,'S','Encryption password for SNMPv3 requests to built-in SNMP agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Agent.V3.UserName','netxms','netxms',1,0,'S','User name for SNMPv3 requests to built-in SNMP agent.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Codepage','','',1,0,'S','Default server SNMP codepage.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Discovery.SeparateProbeRequests','0','0',1,0,'B','Use separate SNMP request for each test OID.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.EngineId','80:00:DF:4B:05:20:10:08:04:02:01:00','80:00:DF:4B:05:20:10:08:04:02:01:00',1,1,'S','Server''s SNMP engine ID.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.RequestTimeout','1500','1500',1,1,'I','Timeout in milliseconds for SNMP requests sent by NetXMS server.','milliseconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.RetryCount','3','3',1,1,'I','Number of retries for SNMP requests sent by NetXMS server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.AllowVarbindsConversion','1','1',1,0,'B','Allows/disallows conversion of SNMP trap OCTET STRING varbinds into hex strings if they contain non-printable characters.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.Enable','1','1',1,1,'B','Enable/disable SNMP trap processing.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.ListenerPort','162','162',1,1,'I','Port used for SNMP traps.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.LogAll','0','0',1,0,'B','Log all SNMP traps (even those received from addresses not belonging to any known node).','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.LogRetentionTime','90','90',1,0,'I','The time how long SNMP trap logs are retained.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.ProcessUnmanagedNodes','0','0',1,0,'B','Enable/disable processing of SNMP traps received from unmanaged nodes.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.RateLimit.Threshold','0','0',1,0,'I','Threshold for number of SNMP traps per second that defines SNMP trap flood condition. Detection is disabled if 0 is set.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.RateLimit.Duration','15','15',1,0,'I','Time period for SNMP traps per second to be above threshold that defines SNMP trap flood condition.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.SourcesInAllZones','0','0',1,1,'B','Search all zones to match trap/syslog source address to node.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('SNMP.Traps.UnmatchedTrapEvent','1','1',1,0,'B','Enable/disable generation of default event for unmatched SNMP traps.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.AllowUnknownSources','0','0',1,0,'B','Enable or disable processing of syslog messages from unknown sources.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.Codepage','','',1,0,'S','Default server syslog codepage.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.EnableListener','0','0',1,1,'B','Enable/disable local syslog listener.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.EnableStorage','1','1',1,0,'B','Enable/disable local storage of received syslog messages in NetXMS database.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.IgnoreMessageTimestamp','0','0',1,0,'B','Ignore timestamp received in syslog messages and always use server time.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.ListenPort','514','514',1,1,'I','UDP port used by built-in syslog server.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.NodeMatchingPolicy','0','0',1,1,'C','Node matching policy for built-in syslog daemon.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.ParseUnknownSourceMessages','0','0',1,0,'B','Enable or disable parsing of syslog messages received from unknown sources.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Syslog.RetentionTime','90','90',1,0,'I','Retention time in days for stored syslog messages. All messages older than specified will be deleted by housekeeping process.','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Agent.BaseSize','32','32',1,1,'I','Base size for agent connector thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Agent.MaxSize','256','256',1,1,'I','Maximum size for agent connector thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.DataCollector.BaseSize','10','10',1,1,'I','Base size for data collector thread pool.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.DataCollector.MaxSize','250','250',1,1,'I','Maximum size for data collector thread pool.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Discovery.BaseSize','8','8',1,1,'I','Base size for network discovery thread pool.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Discovery.MaxSize','64','64',1,1,'I','Maximum size for network discovery thread pool.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.FileTransfer.BaseSize','2','2',1,1,'I','Base size for file transfer thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.FileTransfer.MaxSize','16','16',1,1,'I','Maximum size for file transfer thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Main.BaseSize','8','8',1,1,'I','Base size for main server thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Main.MaxSize','256','256',1,1,'I','Maximum size for main server thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Poller.BaseSize','10','10',1,1,'I','Base size for poller thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Poller.MaxSize','250','250',1,1,'I','Maximum size for poller thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Scheduler.BaseSize','1','1',1,1,'I','Base size for scheduler thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Scheduler.MaxSize','64','64',1,1,'I','Maximum size for scheduler thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Syncer.BaseSize','1','1',1,1,'I','Base size for syncer thread pool','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('ThreadPool.Syncer.MaxSize','1','1',1,1,'I','Maximum size for syncer thread pool (value of 1 will disable pool creation)','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Topology.AdHocRequest.ExpirationTime','900','900',1,0,'I','Ad-hoc network topology request expiration time. Server will use cached result of previous request if it is newer than given interval.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,is_public,data_type,description,units) VALUES ('Topology.AdHocRequest.IncludePhysicalLinks','0','0',1,0,'Y','B','If set to true, physical links will be added to ad-hoc L2 maps.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Topology.DefaultDiscoveryRadius','5','5',1,0,'I','Default number of hops from seed node to be added to topology map.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Topology.PollingInterval','1800','1800',1,1,'I','Interval in seconds between topology polls.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('Topology.RoutingTableUpdateInterval','300','300',1,1,'I','Interval in seconds between reading routing table from node.','seconds');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,is_public,data_type,description,units) VALUES ('UserAgent.DefaultMessageRetentionTime','10080','10080',1,0,'Y','I','Default user agent message retention time (in minutes).','minutes');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('UserAgent.RetentionTime','30','30',1,0,'I','User agent message historical data retention time (in days).','days');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('WindowsEvents.EnableStorage','1','1',1,0,'B','Enable/disable local storage of received Windows events in NetXMS database.','');
INSERT INTO config (var_name,var_value,default_value,is_visible,need_server_restart,data_type,description,units) VALUES ('WindowsEvents.LogRetentionTime','90','90',1,0,'I','Retention time in days for records in Windows event log. All records older than specified will be deleted by housekeeping process.','days');
INSERT INTO config_values (var_name,var_value) VALUES ('Client.ListenerPort','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('AuditLog.External.Port','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('MobileDeviceListenerPort','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('RADIUS.Port','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('RADIUS.SecondaryPort','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('ReportingServer.Port','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('SNMP.Agent.ListenerPort','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('SNMP.Traps.ListenerPort','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('Syslog.ListenPort','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('XMPP.Port','65535');
INSERT INTO config_values (var_name,var_value) VALUES ('Server.AllowedCiphers','63');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Agent.DefaultCacheMode','1','On');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Agent.DefaultCacheMode','2','Off');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Agent.DefaultEncryptionPolicy','0','Disabled');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Agent.DefaultEncryptionPolicy','1','Allowed');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Agent.DefaultEncryptionPolicy','2','Preferred');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Agent.DefaultEncryptionPolicy','3','Required');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Agent.DefaultProtocolCompressionMode','1','Enabled');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Agent.DefaultProtocolCompressionMode','2','Disabled');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('AgentTunnels.TLS.MinVersion','0','1.0');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('AgentTunnels.TLS.MinVersion','1','1.1');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('AgentTunnels.TLS.MinVersion','2','1.2');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('AgentTunnels.TLS.MinVersion','3','1.3');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('AgentTunnels.UnboundTunnelTimeoutAction','0','Reset tunnel');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('AgentTunnels.UnboundTunnelTimeoutAction','1','Generate event');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('AgentTunnels.UnboundTunnelTimeoutAction','2','Bind tunnel to existing node');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('AgentTunnels.UnboundTunnelTimeoutAction','3','Bind tunnel to existing node or create new node');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('BusinessServices.Check.Threshold.DataCollection','1','Warning');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('BusinessServices.Check.Threshold.DataCollection','2','Minor');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('BusinessServices.Check.Threshold.DataCollection','3','Major');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('BusinessServices.Check.Threshold.DataCollection','4','Critical');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('BusinessServices.Check.Threshold.Objects','1','Warning');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('BusinessServices.Check.Threshold.Objects','2','Minor');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('BusinessServices.Check.Threshold.Objects','3','Major');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('BusinessServices.Check.Threshold.Objects','4','Critical');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('DBWriter.HouseKeeperInterlock','0','Auto');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('DBWriter.HouseKeeperInterlock','1','Off');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('DBWriter.HouseKeeperInterlock','2','On');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('LDAP.NewUserAuthMethod','0','Local password');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('LDAP.NewUserAuthMethod','1','RADIUS password');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('LDAP.NewUserAuthMethod','2','Certificate');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('LDAP.NewUserAuthMethod','3','Certificate or local password');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('LDAP.NewUserAuthMethod','4','Certificate or RADIUS password');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('LDAP.NewUserAuthMethod','5','LDAP password');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('LDAP.UserDeleteAction','0','Delete user');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('LDAP.UserDeleteAction','1','Disable user');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('NetworkDiscovery.Type','0','Disabled');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('NetworkDiscovery.Type','1','Passive only');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('NetworkDiscovery.Type','2','Active only');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('NetworkDiscovery.Type','3','Passive and active');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Interfaces.DefaultExpectedState','0','UP');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Interfaces.DefaultExpectedState','1','AUTO');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Interfaces.DefaultExpectedState','2','IGNORE');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Interfaces.UseAliases','0','Don''t use aliases');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Interfaces.UseAliases','1','Use alias when available');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Interfaces.UseAliases','2','Concatenate alias with name');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Interfaces.UseAliases','3','Concatenate name with alias');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Nodes.ResolveDNSToIPOnStatusPoll','0','Never');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Nodes.ResolveDNSToIPOnStatusPoll','1','Always');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Nodes.ResolveDNSToIPOnStatusPoll','2','On failure');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Nodes.Resolver.AddressFamilyHint','0','None');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Nodes.Resolver.AddressFamilyHint','1','IPv4');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.Nodes.Resolver.AddressFamilyHint','2','IPv6');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.StatusCalculation.CalculationAlgorithm','1','Most critical');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.StatusCalculation.CalculationAlgorithm','2','Single threshold');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.StatusCalculation.CalculationAlgorithm','3','Multiple thresholds');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.StatusCalculation.PropagationAlgorithm','1','Unchanged');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.StatusCalculation.PropagationAlgorithm','2','Fixed');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.StatusCalculation.PropagationAlgorithm','3','Relative');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Objects.StatusCalculation.PropagationAlgorithm','4','Translated');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Server.ImportConfigurationOnStartup','0','Never');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Server.ImportConfigurationOnStartup','1','Only missing elements');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Server.ImportConfigurationOnStartup','2','Always');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.AuthenticationMethod','0','None');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.AuthenticationMethod','1','MD5');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.AuthenticationMethod','2','SHA-1');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.AuthenticationMethod','3','SHA-224');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.AuthenticationMethod','4','SHA-256');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.AuthenticationMethod','5','SHA-384');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.AuthenticationMethod','6','SHA-512');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.EncryptionMethod','0','None');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.EncryptionMethod','1','DES');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.EncryptionMethod','2','AES-128');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.EncryptionMethod','3','AES-192');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('SNMP.Agent.V3.EncryptionMethod','4','AES-256');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Syslog.NodeMatchingPolicy','0','IP, then hostname');
INSERT INTO config_values (var_name,var_value,var_description) VALUES ('Syslog.NodeMatchingPolicy','1','Hostname, then IP');
INSERT INTO users (id,name,password,system_access,flags,full_name,
                   description,grace_logins,auth_method,guid,
                   cert_mapping_method,cert_mapping_data,
                   auth_failures,last_passwd_change,min_passwd_length,
                   disabled_until,last_login,created)
   VALUES (0,'system',
           '3A445C0072CD69D9030CC6644020E5C4576051B1',
           35184372088831,12,'','Built-in system account',5,0,
           '00000000-0000-0000-0000-000000000000',0,'',0,0,0,0,0,0
          );
INSERT INTO users (id,name,password,system_access,flags,full_name,
                   description,grace_logins,auth_method,guid,
                   cert_mapping_method,cert_mapping_data,
                   auth_failures,last_passwd_change,min_passwd_length,
                   disabled_until,last_login,created)
   VALUES (1,'admin',
           '3A445C0072CD69D9030CC6644020E5C4576051B1',
           0,8,'','Default administrator account',5,0,
           '00000000-0000-0000-0000-000000000000',0,'',0,0,0,0,0,0
          );
INSERT INTO users (id,name,password,system_access,flags,full_name,
                   description,grace_logins,auth_method,guid,
                   cert_mapping_method,cert_mapping_data,
                   auth_failures,last_passwd_change,min_passwd_length,
                   disabled_until,last_login,created)
   VALUES (2,'anonymous',
           '$$',
           0,1104,'','Anonymous account',5,0,
           '00000000-0000-0000-0000-000000000000',0,'',0,0,0,0,0,0
          );
INSERT INTO user_groups (id,name,system_access,ui_access_rules,flags,description,guid,created)
   VALUES (1073741824, 'Everyone', 274877906960, '*', 0, 'Built-in everyone group',
           '00000000-0000-0000-0000-000000000000',0
          );
INSERT INTO user_groups (id,name,system_access,ui_access_rules,flags,description,guid,created)
   VALUES (1073741825, 'Admins', 9223372036854775807, '*', 0, 'Default administrative group',
           '00000000-0000-0000-0000-000000000000',0
          );
INSERT INTO user_group_members (group_id,user_id) VALUES (1073741825,1);
INSERT INTO acl (object_id,user_id,access_rights) VALUES (1,1073741825,2097151);
INSERT INTO acl (object_id,user_id,access_rights) VALUES (2,1073741825,2097151);
INSERT INTO acl (object_id,user_id,access_rights) VALUES (3,1073741825,2097151);
INSERT INTO acl (object_id,user_id,access_rights) VALUES (5,1073741825,2097151);
INSERT INTO acl (object_id,user_id,access_rights) VALUES (6,1073741825,2097151);
INSERT INTO acl (object_id,user_id,access_rights) VALUES (7,1073741825,2097151);
INSERT INTO acl (object_id,user_id,access_rights) VALUES (9,1073741825,2097151);
INSERT INTO snmp_communities (id,community,zone) VALUES(1,'public',-1);
INSERT INTO notification_channels (name,driver_name,description,configuration) VALUES
   (
      'SMTP-Text','SMTP','Default SMTP text channel',
      '#Server=localhost' || chr(13)||chr(10) ||
      '#Port=25 # if TLSMode=TLS, default value is 465 else 25' || chr(13)||chr(10) ||
      '#TLSMode=NONE # NONE, TLS, STARTTLS' || chr(13)||chr(10) ||
      '#AuthMethod=none # none,basic, digest, ntlm, negotiate' || chr(13)||chr(10) ||
      '#Login=' || chr(13)||chr(10) ||
      '#Password=' || chr(13)||chr(10) ||
      '#FromAddr=netxms@localhost' || chr(13)||chr(10) ||
      '#FromName=NetXMS Server' || chr(13)||chr(10) ||
      '#IsHTML=no' || chr(13)||chr(10)
   );
INSERT INTO notification_channels (name,driver_name,description,configuration) VALUES
   (
      'SMTP-HTML','SMTP','Default SMTP HTML channel',
      '#Server=localhost' || chr(13)||chr(10) ||
      '#Port=25 # if TLSMode=TLS, default value is 465 else 25' || chr(13)||chr(10) ||
      '#TLSMode=NONE # NONE, TLS, STARTTLS' || chr(13)||chr(10) ||
      '#AuthMethod=none # none,basic, digest, ntlm, negotiate' || chr(13)||chr(10) ||
      '#Login=' || chr(13)||chr(10) ||
      '#Password=' || chr(13)||chr(10) ||
      '#FromAddr=netxms@localhost' || chr(13)||chr(10) ||
      '#FromName=NetXMS Server' || chr(13)||chr(10) ||
      '#IsHTML=yes' || chr(13)||chr(10)
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  1, 'SYS_NODE_ADDED', '8d34acfd-dad6-4f6e-b6a8-1189683591ef',
  0, 1,
  'Node added',
  'Generated when new node object added to the database.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) nodeOrigin - Node origin (0 = created manually, 1 = created by network discovery, 2 = created by tunnel auto bind)',
      'NewObject'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  2, 'SYS_SUBNET_ADDED', '75fc3f8b-768f-46b4-bf44-72949436a679',
  0, 0,
  'Subnet %2 added',
  'Generated when new subnet object added to the database.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) subnetObjectId - Subnet object ID' || chr(13)||chr(10) ||
  '   2) subnetName - Subnet name' || chr(13)||chr(10) ||
  '   3) ipAddress - IP address' || chr(13)||chr(10) ||
  '   4) networkMask - Network mask',
      'NewObject'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  3, 'SYS_IF_ADDED', '33cb8f9c-9427-459c-8a71-45c73f5cc183',
  0, 1,
  'Interface "%2" added (IP Addr: %3/%4, IfIndex: %5)',
  'Generated when new interface object added to the database.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceNetmask - Interface netmask' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index',
      'NewObject'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  4, 'SYS_IF_UP', '09ee209a-0e75-434f-b8c8-399d93305d7b',
  0, 1,
  'Interface "%2" changed state to UP (IP Addr: %3/%4, IfIndex: %5)',
  'Generated when interface goes up.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceNetMask - Interface netmask' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  5, 'SYS_IF_DOWN', 'd9a6d46d-97f8-48eb-a86a-2c0f6b150d0d',
  2, 1,
  'Interface "%2" changed state to DOWN (IP Addr: %3/%4, IfIndex: %5)',
  'Generated when interface goes down.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceNetMask - Interface netmask' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  45, 'SYS_IF_UNKNOWN', 'ecb47be1-f911-4c1f-9b00-d0d21694071d',
  1, 1,
  'Interface "%2" changed state to UNKNOWN (IP Addr: %3/%4, IfIndex: %5)',
  'Generated when interface goes to unknown state.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceNetMask - Interface netmask' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  46, 'SYS_IF_DISABLED', '2f3123a2-425f-47db-9c6b-9bc05a7fba2d',
  0, 1,
  'Interface "%2" disabled (IP Addr: %3/%4, IfIndex: %5)',
  'Generated when interface administratively disabled.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceNetMask - Interface netmask' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  47, 'SYS_IF_TESTING', 'eb500e5c-3560-4394-8f5f-80aa67036f13',
  0, 1,
  'Interface "%2" is testing (IP Addr: %3/%4, IfIndex: %5)',
  'Generated when interface goes to testing state.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceNetMask - Interface netmask' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  62, 'SYS_IF_UNEXPECTED_UP', 'ff21a165-9253-4ecc-929a-ffd1e388d504',
  3, 1,
  'Interface "%2" unexpectedly changed state to UP (IP Addr: %3/%4, IfIndex: %5)',
  'Generated when interface goes up but it''s expected state set to DOWN.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceNetMask - Interface netmask' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  63, 'SYS_IF_EXPECTED_DOWN', '911358f4-d2a1-4465-94d7-ce4bc5c38860',
  0, 1,
  'Interface "%2" with expected state DOWN changed state to DOWN (IP Addr: %3/%4, IfIndex: %5)',
  'Generated when interface goes down and it''s expected state is DOWN.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceNetMask - Interface netmask' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  6, 'SYS_NODE_NORMAL', '03bc11c0-ec20-43be-be45-e60846f744dc',
  0, 1,
  'Node status changed to NORMAL',
  'Generated when node status changed to normal.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) previousNodeStatus - Previous node status',
      'NodeStatus'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  7, 'SYS_NODE_WARNING', '1c80deab-aafb-43a7-93a7-1330dd563b47',
  1, 1,
  'Node status changed to WARNING',
  'Generated when node status changed to "Warning".' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) previousNodeStatus - Previous node status',
      'NodeStatus'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  8, 'SYS_NODE_MINOR', '84eaea00-4ed7-41eb-9079-b783e5c60651',
  2, 1,
  'Node status changed to MINOR',
  'Generated when node status changed to "Minor Problem" (informational).' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) previousNodeStatus - Previous node status',
      'NodeStatus'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  9, 'SYS_NODE_MAJOR', '27035c88-c27a-4c16-97b3-4658d34a5f63',
  3, 1,
  'Node status changed to MAJOR',
  'Generated when node status changed to "Major Problem".' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) previousNodeStatus - Previous node status',
      'NodeStatus'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  10, 'SYS_NODE_CRITICAL', '8f2e98f8-1cd4-4e12-b41f-48b5c60ebe8e',
  4, 1,
  'Node status changed to CRITICAL',
  'Generated when node status changed to critical.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) previousNodeStatus - Previous node status',
      'NodeStatus'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  11, 'SYS_NODE_UNKNOWN', '6933cce0-fe1f-4123-817f-af1fb9f0eab4',
  0, 1,
  'Node status changed to UNKNOWN',
  'Generated when node status changed to unknown.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) previousNodeStatus - Previous node status',
      'NodeStatus'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description,tags) VALUES
 (
  12, 'SYS_NODE_UNMANAGED', 'a8356ba7-51b7-4487-b74e-d12132db233c',
  0, 1,
  'Node status changed to UNMANAGED',
  'Generated when node status changed to unmanaged.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) previousNodeStatus - Previous node status',
      'NodeStatus'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  13, 'SYS_NODE_CAP_CHANGED', 'b04e39f5-d3a7-4d9a-b594-37132f5eaf34',
  0, 0,
  'Node capabilities changed (Old: %1; New: %2)',
  'Generated when node capabilities changed.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) oldCapabilities - Old capabilities' || chr(13)||chr(10) ||
  '   2) newCapabilities - New capabilities'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  14, 'SYS_SNMP_UNREACHABLE', 'd2fc3b0c-1215-4a92-b8f3-47df5d753602',
  3, 1,
  'SNMP agent is not responding',
  'Generated when node''s SNMP agent is not responding.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  15, 'SYS_AGENT_UNREACHABLE', 'ba484457-3594-418e-a72a-65336055d025',
  3, 1,
  'Native agent is not responding',
  'Generated when node''s native agent is not responding.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  16, 'SYS_IF_DELETED', 'ad7e9856-e361-4095-9361-ccc462d93624',
  0, 1,
  'Interface "%2" deleted (IP Addr: %3/%4, IfIndex: %1)',
  'Generated when interface object deleted from the database.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) interfaceIpAddress -Interface IP address' || chr(13)||chr(10) ||
  '   4) interfaceMask - Interface netmask'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  17, 'SYS_THRESHOLD_REACHED', '05161c3d-7ceb-406f-af0a-af5c77f324a5',
  1, 1,
  'Threshold reached for data collection item "%<dciDescription>" (Metric: %<dciName>; Threshold value: %<{multipliers, units}thresholdValue>; Actual value: %<{multipliers, units}currentValue>)',
  'Generated when threshold value reached for specific data collection item.' || chr(13)||chr(10) ||
  'Parameters are accessible via %<...> and can have "m" or "multipliers" and "u" or "units" format modifiers for value formatting (for example %<{m,u}currentValue>).' || chr(13)||chr(10) || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) dciName - Metric name' || chr(13)||chr(10) ||
  '   2) dciDescription - Item description' || chr(13)||chr(10) ||
  '   3) thresholdValue - Threshold value' || chr(13)||chr(10) ||
  '   4) currentValue - Actual value which is compared to threshold value' || chr(13)||chr(10) ||
  '   5) dciId - Data collection item ID' || chr(13)||chr(10) ||
  '   6) instance - Instance' || chr(13)||chr(10) ||
  '   7) isRepeatedEvent - Repeat flag' || chr(13)||chr(10) ||
  '   8) dciValue - Last collected DCI value' || chr(13)||chr(10) ||
  '   9) operation - Threshold''s operation code' || chr(13)||chr(10) ||
  '   10) function - Threshold''s function code' || chr(13)||chr(10) ||
  '   11) pollCount - Threshold''s required poll count' || chr(13)||chr(10) ||
  '   12) thresholdDefinition - Threshold''s textual definition'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  18, 'SYS_THRESHOLD_REARMED', '25eef3a7-6158-4c5e-b4e3-8a7aa7ade73c',
  0, 1,
  'Threshold rearmed for data collection item %<dciDescription> (Metric: %<dciName>)',
  'Generated when threshold check is rearmed for specific data collection item.' || chr(13)||chr(10) ||
  'Parameters are accessible via %<...> and can have "m" or "multipliers" and "u" or "units" format modifiers for value formatting (for example %<{m,u}currentValue>).' || chr(13)||chr(10) || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) dciName - Metric name' || chr(13)||chr(10) ||
  '   2) dciDescription - Item description' || chr(13)||chr(10) ||
  '   3) dciId - Data collection item ID' || chr(13)||chr(10) ||
  '   4) instance - Instance' || chr(13)||chr(10) ||
  '   5) thresholdValue - Threshold value' || chr(13)||chr(10) ||
  '   6) currentValue - Actual value which is compared to threshold value' || chr(13)||chr(10) ||
  '   7) dciValue - Last collected DCI value' || chr(13)||chr(10) ||
  '   8) operation - Threshold''s operation code' || chr(13)||chr(10) ||
  '   9) function - Threshold''s function code' || chr(13)||chr(10) ||
  '   10) pollCount - Threshold''s required poll count' || chr(13)||chr(10) ||
  '   11) thresholdDefinition - Threshold''s textual definition'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
        (
                30, 'SYS_ALL_THRESHOLDS_REARMED', '12ecc8fa-e39e-497b-ad9f-a7786fcbcf46',
                0, 1,
                'All thresholds rearmed for data collection item %<dciDescription> (Metric: %<dciName>)',
                'Generated when all thresholds are rearmed for specific data collection item.' || chr(13)||chr(10) ||
                'Parameters are accessible via %<...> and can have "m" or "multipliers" and "u" or "units" format modifiers for value formatting (for example %<{m,u}currentValue>).' || chr(13)||chr(10) || chr(13)||chr(10) ||
                'Parameters:' || chr(13)||chr(10) ||
                '   1) dciName - Metric name' || chr(13)||chr(10) ||
                '   2) dciDescription - Data collection item description' || chr(13)||chr(10) ||
                '   3) dciId - Data collection item ID' || chr(13)||chr(10) ||
                '   4) instance - Instance' || chr(13)||chr(10) ||
                '   5) dciValue - Last collected DCI value'
        );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  19, 'SYS_SUBNET_DELETED', 'af188eb3-e84f-4fd9-aecf-f1ba934a9f1a',
  0, 0,
  'Subnet %2 deleted',
  'Generated when subnet object deleted from the database.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) subnetObjectId - Subnet object ID' || chr(13)||chr(10) ||
  '   2) subnetName - Subnet name' || chr(13)||chr(10) ||
  '   3) ipAddress - IP address' || chr(13)||chr(10) ||
  '   4) networkMask - Network mask'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  20, 'SYS_THREAD_HANG', 'df247d13-a63a-43fe-bb02-cb41718ee387',
  4, 1,
  'Thread "%1" is not responding',
  'Generated when one of the system threads hangs or stops unexpectedly.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) threadName - Thread name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  21, 'SYS_THREAD_RUNNING', '5589f6ce-7133-44db-8e7a-e1452d636a9a',
  0, 1,
  'Thread "%1" was returned to running state',
  'Generated when one of the system threads which previously hangs or stops unexpectedly was returned to running state.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) threadName - Thread name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  22, 'SYS_NOTIFICATION_FAILURE', '1e376009-0d26-4b86-87a2-f4715a02fb38',
  1, 1,
  'Unable to send notification using notification channel %1 to %2',
  'Generated when server is unable to send notification.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) notificationChannelName - Notification channel name' || chr(13)||chr(10) ||
  '   2) recipientAddress - Recipient address' || chr(13)||chr(10) ||
  '   3) notificationSubject - Notification subject' || chr(13)||chr(10) ||
  '   4) notificationMessage - Notification message'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  23, 'SYS_MAC_ADDR_CHANGED', '61916ef0-1eee-4df7-a95b-150928d47962',
  1, 1,
  'MAC address for interface %3 changed from %4 to %5',
  'Generated when server detects change of interface''s MAC address.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   3) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   4) oldMacAddress - Old MAC address' || chr(13)||chr(10) ||
  '   5) newMacAddress - New MAC address'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  24, 'SYS_INCORRECT_NETMASK', '86c08c55-416e-4ac4-bf2b-302b5fddbd68',
  2, 1,
  'Invalid network mask /%4 on interface "%3", should be /%5',
  'Generated when server detects invalid network mask on an interface.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
  '   2) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   3) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   4) actualNetworkMask - Actual network mask on interface' || chr(13)||chr(10) ||
  '   5) correctNetworkMask - Correct network mask'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  28, 'SYS_NODE_DOWN', 'ce34f0d0-5b21-48c2-8788-8ed5ee547023',
  4, 1,
  'Node down',
  'Generated when node is not responding to management server.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) Previous state (1 if node was marked as UNREACHABLE, 0 if it was marked as DOWN)'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  29, 'SYS_NODE_UP', '05f180b6-62e7-4bc4-8a8d-34540214254b',
  0, 1,
  'Node up',
  'Generated when communication with the node re-established.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) reason - Reason'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  25, 'SYS_SERVICE_DOWN', '89caacb5-d2cf-493b-862f-cddbfecac5b6',
  3, 1,
  'Network service "%1" is not responding',
  'Generated when network service is not responding to management server as expected.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) serviceName - Service name' || chr(13)||chr(10) ||
  '   2) serviceObjectId - Service object ID' || chr(13)||chr(10) ||
  '   3) serviceType - Service type'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  26, 'SYS_SERVICE_UP', 'ab35e7c7-2428-44db-ad43-57fe551bb8cc',
  0, 1,
  'Network service "%1" returned to operational state',
  'Generated when network service responds as expected after failure.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) serviceName - Service name' || chr(13)||chr(10) ||
  '   2) serviceObjectId - Service object ID' || chr(13)||chr(10) ||
  '   3) serviceType - Service type'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  27, 'SYS_SERVICE_UNKNOWN', 'd891adae-49fe-4442-a8f3-0ca37ca8820a',
  1, 1,
  'Status of network service "%1" is unknown',
  'Generated when management server is unable to determine state of the network service due to agent or server-to-agent communication failure.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) serviceName - Service name' || chr(13)||chr(10) ||
  '   2) serviceObjectId - Service object ID' || chr(13)||chr(10) ||
  '   3) serviceType - Service type'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  31, 'SYS_SNMP_OK', 'a821086b-1595-40db-9148-8d770d30a54b',
  0, 1,
  'Connectivity with SNMP agent restored',
  'Generated when connectivity with node''s SNMP agent restored.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  32, 'SYS_AGENT_OK', '9c15299a-f2e3-4440-84c5-b17dea87ae2a',
  0, 1,
  'Connectivity with native agent restored',
  'Generated when connectivity with node''s native agent restored.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  33, 'SYS_SCRIPT_ERROR', '2cc78efe-357a-4278-932f-91e36754c775',
  2, 1,
  'Script (%1) execution error: %2',
  'Generated when server encounters NXSL script execution error.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) Script name' || chr(13)||chr(10) ||
  '   2) Error text' || chr(13)||chr(10) ||
  '   3) DCI ID if script is DCI related script, or 0 otherwise' || chr(13)||chr(10) ||
  '   4) Related object ID if applicable, or 0 otherwise' || chr(13)||chr(10) ||
  '   5) Context'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  34, 'SYS_CONDITION_ACTIVATED', '16a86780-b73a-4601-929c-0c503bd06401',
  2, 1,
  'Condition "%2" activated',
  'Default event for condition activation.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) conditionObjectId - Condition object ID' || chr(13)||chr(10) ||
  '   2) conditionObjectName - Condition object name' || chr(13)||chr(10) ||
  '   3) previousConditionStatus - Previous condition status' || chr(13)||chr(10) ||
  '   4) currentConditionStatus - Current condition status'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  35, 'SYS_CONDITION_DEACTIVATED', '926d15d2-9761-4bb6-a1ce-64175303796f',
  0, 1,
  'Condition "%2" deactivated',
  'Default event for condition deactivation.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) conditionObjectId - Condition object ID' || chr(13)||chr(10) ||
  '   2) conditionObjectName - Condition object name' || chr(13)||chr(10) ||
  '   3) previousConditionStatus - Previous condition status' || chr(13)||chr(10) ||
  '   4) currentConditionStatus - Current condition status'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  36, 'SYS_DB_CONN_LOST', '0311e9c8-8dcf-4a5b-9036-8cff034409ff',
  4, 1,
  'Lost connection with backend database engine',
  'Generated if connection with backend database engine is lost.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  37, 'SYS_DB_CONN_RESTORED', 'd36259a7-5f6b-4e3c-bb6f-17d1f8ac950d',
  0, 1,
  'Connection with backend database engine restored',
  'Generated when connection with backend database engine restored.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  38, 'SYS_CLUSTER_RESOURCE_MOVED', '44abe5f3-a7c9-4fbd-8d10-53be172eae83',
  1, 1,
  'Cluster resource "%2" moved from node %4 to node %6',
  'Generated when cluster resource moved between nodes.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) resourceId - Resource ID' || chr(13)||chr(10) ||
  '   2) resourceName - Resource name' || chr(13)||chr(10) ||
  '   3) previousOwnerNodeId - Previous owner node ID' || chr(13)||chr(10) ||
  '   4) previousOwnerNodeName - Previous owner node name' || chr(13)||chr(10) ||
  '   5) newOwnerNodeId - New owner node ID' || chr(13)||chr(10) ||
  '   6) newOwnerNodeName - New owner node name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  39, 'SYS_CLUSTER_RESOURCE_DOWN', 'c3b1d4b5-2e41-4a2f-b379-9d74ebba3a25',
  3, 1,
  'Cluster resource "%2" is down (last owner was %4)',
  'Generated when cluster resource goes down.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) resourceId - Resource ID' || chr(13)||chr(10) ||
  '   2) resourceName - Resource name' || chr(13)||chr(10) ||
  '   3) lastOwnerNodeId - Last owner node ID' || chr(13)||chr(10) ||
  '   4) lastOwnerNodeName - Last owner node name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  40, 'SYS_CLUSTER_RESOURCE_UP', 'ef6fff96-0cbb-4030-aeba-2473a80c6568',
  0, 1,
  'Cluster resource "%2" is up (new owner is %4)',
  'Generated when cluster resource goes up.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) resourceId - Resource ID' || chr(13)||chr(10) ||
  '   2) resourceName - Resource name' || chr(13)||chr(10) ||
  '   3) ownerNodeId - New owner node ID' || chr(13)||chr(10) ||
  '   4) ownerNodeName - New owner node name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  41, 'SYS_CLUSTER_DOWN', '8f14d0f7-08d4-4422-92f4-469e5eef93ef',
  4, 1,
  'Cluster is down',
  'Generated when cluster goes down.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  42, 'SYS_CLUSTER_UP', '4a9cdb65-aa44-42f2-99b0-1e302aec10f6',
  0, 1,
  'Cluster is up',
  'Generated when cluster goes up.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  43, 'SYS_ALARM_TIMEOUT', '4ae4f601-327b-4ef8-9740-8600a1ba2acd',
  1, 1,
  'Alarm timeout expired (ID: %1; Text: %2)',
  'Generated when alarm timeout expires.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) alarmId - Alarm ID' || chr(13)||chr(10) ||
  '   2) alarmMessage - Alarm message' || chr(13)||chr(10) ||
  '   3) alarmKey - Alarm key' || chr(13)||chr(10) ||
  '   4) originalEventCode - Original event code' || chr(13)||chr(10) ||
  '   5) originalEventName - Original event name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  44, 'SYS_LOG_RECORD_MATCHED', 'd9326159-5c60-410f-990e-fae88df7fdd4',
  1, 1,
  'Log record matched (Policy: %1; File: %2; Record: %4)',
  'Default event for log record match.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) Policy name' || chr(13)||chr(10) ||
  '   2) Log file name' || chr(13)||chr(10) ||
  '   3) Matching regular expression' || chr(13)||chr(10) ||
  '   4) Matched record' || chr(13)||chr(10) ||
  '   5 .. 9) Reserved' || chr(13)||chr(10) ||
  '   10 .. 99) Substrings extracted by regular expression'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  48, 'SYS_EVENT_STORM_DETECTED', 'c98d8575-d134-4044-ba67-75c5f5d0f6e0',
  3, 1,
  'Event storm detected (Events per second: %1)',
  'Generated when system detects an event storm.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) eps - Events per second' || chr(13)||chr(10) ||
  '   2) duration - Duration' || chr(13)||chr(10) ||
  '   3) threshold - Threshold'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  49, 'SYS_EVENT_STORM_ENDED', 'dfd5e3ba-3182-4deb-bc32-9e6b8c1c6546',
  0, 1,
  'Event storm ended',
  'Generated when system clears event storm condition.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) eps - Events per second' || chr(13)||chr(10) ||
  '   2) duration - Duration' || chr(13)||chr(10) ||
  '   3) threshold - Threshold'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  50, 'SYS_NETWORK_CONN_LOST', '3cb0921a-87a1-46e4-8be1-82ad2dda0015',
  4, 1,
  'NetXMS server network connectivity lost',
  'Generated when system detects loss of network connectivity based on beacon probing.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) numberOfBeacons - Number of beacons'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  51, 'SYS_NETWORK_CONN_RESTORED', '1c61b3e0-389a-47ac-8469-932a907392bc',
  0, 1,
  'NetXMS server network connectivity restored',
  'Generated when system detects restoration of network connectivity based on beacon probing.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) numberOfBeacons - Number of beacons'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  52, 'SYS_DB_QUERY_FAILED', '5f35d646-63b6-4dcd-b94a-e2ccd060686a',
  4, 1,
  'Database query failed (Query: %1; Error: %2)',
  'Generated when SQL query to backend database failed.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) Query (query)' || chr(13)||chr(10) ||
  '   2) Error message (message)' || chr(13)||chr(10) ||
                '   3) Connection loss indicator (connectionLost)' || chr(13)||chr(10) ||
                '   4) Query hash (hash)'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  53, 'SYS_DCI_UNSUPPORTED', '28367b5b-1541-4526-8cbe-91a17ed31ba4',
  2, 1,
  'Status of DCI %1 (%5: %2) changed to UNSUPPORTED',
  'Generated when DCI status changed to UNSUPPORTED.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) DCI ID (dciId)' || chr(13)||chr(10) ||
  '   2) Metric (metric)' || chr(13)||chr(10) ||
  '   3) Description (description)' || chr(13)||chr(10) ||
  '   4) Origin code (originCode)' || chr(13)||chr(10) ||
  '   5) Origin name (origin)'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  54, 'SYS_DCI_DISABLED', '50196042-0619-4420-9471-16b7c25c0213',
  1, 1,
  'Status of DCI %1 (%5: %2) changed to DISABLED',
  'Generated when DCI status changed to DISABLED.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) DCI ID (dciId)' || chr(13)||chr(10) ||
  '   2) Metric (metric)' || chr(13)||chr(10) ||
  '   3) Description (description)' || chr(13)||chr(10) ||
  '   4) Origin code (originCode)' || chr(13)||chr(10) ||
  '   5) Origin name (origin)'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  55, 'SYS_DCI_ACTIVE', '740b6810-b355-46f4-a921-65118504af18',
  0, 1,
  'Status of DCI %1 (%5: %2) changed to ACTIVE',
  'Generated when DCI status changed to ACTIVE.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) DCI ID (dciId)' || chr(13)||chr(10) ||
  '   2) Metric (metric)' || chr(13)||chr(10) ||
  '   3) Description (description)' || chr(13)||chr(10) ||
  '   4) Origin code (originCode)' || chr(13)||chr(10) ||
  '   5) Origin name (origin)'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  56, 'SYS_IP_ADDRESS_CHANGED', '517b6d2a-f5c6-46aa-969d-48e62e05e3bf',
  1, 1,
  'Primary IP address changed from %2 to %1',
  'Generated when primary IP address changed (usually because of primary name change or DNS change).' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) newIpAddress - New IP address' || chr(13)||chr(10) ||
  '   2) oldIpAddress - Old IP address' || chr(13)||chr(10) ||
  '   3) primaryHostName - Primary host name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  57, 'SYS_8021X_PAE_STATE_CHANGED', '3c69667b-04dd-434a-a5b7-cf322abcb9c9',
  0, 1,
  'Port %6 PAE state changed from %4 to %2',
  'Generated when switch port PAE state changed.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) newPaeStateCode - New PAE state code' || chr(13)||chr(10) ||
  '   2) newPaeStateText - New PAE state as text' || chr(13)||chr(10) ||
  '   3) oldPaeStateCode - Old PAE state code' || chr(13)||chr(10) ||
  '   4) oldPaeStateText - Old PAE state as text' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   6) interfaceName - Interface name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  58, 'SYS_8021X_BACKEND_STATE_CHANGED', 'e7cddb93-e42d-479d-9c5b-d68d4be71319',
  0, 1,
  'Port %6 backend authentication state changed from %4 to %2',
  'Generated when switch port backend authentication state changed.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) newBackendStateCode - New backend state code' || chr(13)||chr(10) ||
  '   2) newBackendStateText - New backend state as text' || chr(13)||chr(10) ||
  '   3) oldBackendStateCode - Old backend state code' || chr(13)||chr(10) ||
  '   4) oldBackendStateText - Old backend state as text' || chr(13)||chr(10) ||
  '   5) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   6) interfaceName - Interface name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  59, 'SYS_8021X_PAE_FORCE_UNAUTH', '16a59549-2b06-4938-9e79-1c3d9445d65c',
  3, 1,
  'Port %2 switched to force unauthorize state',
  'Generated when switch port PAE state changed to FORCE UNAUTHORIZE.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  60, 'SYS_8021X_AUTH_FAILED', '8ac56c8e-150b-40d1-998a-c63e7d6596b8',
  3, 1,
  '802.1x authentication failed on port %2',
  'Generated when switch port backend authentication state changed to FAIL.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  61, 'SYS_8021X_AUTH_TIMEOUT', '609a2198-2ea4-4d07-8100-587d550a5670',
  3, 1,
  '802.1x authentication time out on port %2',
  'Generated when switch port backend authentication state changed to TIMEOUT.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  64, 'SYS_CONTAINER_AUTOBIND', '611133e2-1f76-446f-b278-9d500a823611',
  0, 1,
  'Node %2 automatically bound to container %4',
  'Generated when node bound to container object by autobind rule.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) nodeId - Node ID' || chr(13)||chr(10) ||
  '   2) nodeName - Node name' || chr(13)||chr(10) ||
  '   3) containerId - Container ID' || chr(13)||chr(10) ||
  '   4) containerName - Container name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  65, 'SYS_CONTAINER_AUTOUNBIND', 'e57603be-0d81-41aa-b07c-12d08640561c',
  0, 1,
  'Node %2 automatically unbound from container %4',
  'Generated when node unbound from container object by autobind rule.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) nodeId - Node ID' || chr(13)||chr(10) ||
  '   2) nodeName - Node name' || chr(13)||chr(10) ||
  '   3) containerId - Container ID' || chr(13)||chr(10) ||
  '   4) containerName - Container name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  143, 'SYS_CIRCUIT_AUTOBIND', '53372caa-f00b-40d9-961b-ca41109c91c7',
  0, 1,
  'Interface %2 on node %6 automatically bound to circuit %4',
  'Generated when interface bound to circuit by autobind rule.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceId - Interface ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) circuitId - Circuit ID' || chr(13)||chr(10) ||
  '   4) circuitName - Circuit name' || chr(13)||chr(10) ||
  '   5) nodeId - Interface owning node ID' || chr(13)||chr(10) ||
  '   6) nodeName - Interface owning node name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  144, 'SYS_CIRCUIT_AUTOUNBIND', 'bc04d7c0-f2f6-4558-9842-6f751c3657b1',
  0, 1,
  'Interface %2 on node %6 automatically unbound from circuit %4',
  'Generated when interface unbound from circuit by autobind rule.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceId - Interface ID' || chr(13)||chr(10) ||
  '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
  '   3) containerId - Circuit ID' || chr(13)||chr(10) ||
  '   4) containerName - Circuit name' || chr(13)||chr(10) ||
  '   5) nodeId - Interface owning node ID' || chr(13)||chr(10) ||
  '   6) nodeName - Interface owning node name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  66, 'SYS_TEMPLATE_AUTOAPPLY', 'bf084945-f928-4428-8c6c-d2965addc832',
  0, 1,
  'Template %4 automatically applied to node %2',
  'Generated when template applied to node by autoapply rule.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) nodeId - Node ID' || chr(13)||chr(10) ||
  '   2) nodeName - Node name' || chr(13)||chr(10) ||
  '   3) templateId - Template ID' || chr(13)||chr(10) ||
  '   4) templateName - Template name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  67, 'SYS_TEMPLATE_AUTOREMOVE', '8f7a4b4a-d0a2-4404-9b66-fdbc029f42cf',
  0, 1,
  'Template %4 automatically removed from node %2',
  'Generated when template removed from node by autoapply rule.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) nodeId - Node ID' || chr(13)||chr(10) ||
  '   2) nodeName - Node name' || chr(13)||chr(10) ||
  '   3) templateId - Template ID' || chr(13)||chr(10) ||
  '   4) templateName - Template name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  68, 'SYS_NODE_UNREACHABLE', '47bba2ce-c795-4e56-ad44-cbf05741e1ff',
  4, 1,
  'Node unreachable because of network failure',
  'Generated when node is unreachable by management server because of network failure.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) reasonCode - Reason Code' || chr(13)||chr(10) ||
  '   2) reason - Reason' || chr(13)||chr(10) ||
  '   3) rootCauseNodeId - Root Cause Node ID' || chr(13)||chr(10) ||
  '   4) rootCauseNodeName - Root Cause Node Name' || chr(13)||chr(10) ||
  '   5) rootCauseInterfaceId - Root Cause Interface ID' || chr(13)||chr(10) ||
  '   6) rootCauseInterfaceName - Root Cause Interface Name' || chr(13)||chr(10) ||
  '   7) description - Description'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  69, 'SYS_TABLE_THRESHOLD_ACTIVATED', 'c08a1cfe-3128-40c2-99cc-378e7ef91f79',
  2, 1,
  'Threshold activated on table "%2" row %4 (%5)',
  'Generated when table threshold is activated.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) Table DCI name' || chr(13)||chr(10) ||
  '   2) Table DCI description' || chr(13)||chr(10) ||
  '   3) Table DCI ID' || chr(13)||chr(10) ||
  '   4) Table row' || chr(13)||chr(10) ||
  '   5) Instance'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  70, 'SYS_TABLE_THRESHOLD_DEACTIVATED', '479085e7-e1d1-4f2a-9d96-1d522f51b26a',
  0, 1,
  'Threshold deactivated on table "%2" row %4 (%5)',
  'Generated when table threshold is deactivated.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) Table DCI name' || chr(13)||chr(10) ||
  '   2) Table DCI description' || chr(13)||chr(10) ||
  '   3) Table DCI ID' || chr(13)||chr(10) ||
  '   4) Table row' || chr(13)||chr(10) ||
  '   5) Instance'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  71, 'SYS_IF_PEER_CHANGED', 'a3a5c1df-9d96-4e98-9e06-b3157dbf39f0',
  0, 1,
  'New peer for interface %3 is %7 interface %10 (%12)',
  'Generated when peer information for interface changes.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '    1) localIfId - Local interface object ID' || chr(13)||chr(10) ||
  '    2) localIfIndex - Local interface index' || chr(13)||chr(10) ||
  '    3) localIfName - Local interface name' || chr(13)||chr(10) ||
  '    4) localIfIP - Local interface IP address' || chr(13)||chr(10) ||
  '    5) localIfMAC - Local interface MAC address' || chr(13)||chr(10) ||
  '    6) remoteNodeId - Peer node object ID' || chr(13)||chr(10) ||
  '    7) remoteNodeName - Peer node name' || chr(13)||chr(10) ||
  '    8) remoteIfId - interface object ID' || chr(13)||chr(10) ||
  '    9) remoteIfIndex - Peer interface index' || chr(13)||chr(10) ||
  '   10) remoteIfName - Peer interface name' || chr(13)||chr(10) ||
  '   11) remoteIfIP - Peer interface IP address' || chr(13)||chr(10) ||
  '   12) remoteIfMAC - Peer interface MAC address' || chr(13)||chr(10) ||
      '   13) protocol - Discovery protocol'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  72, 'SYS_AP_UP', '5aaee261-0c5d-44e0-b2f0-223bbba5297d',
  0, 1,
  'Access point state changed to UP',
  'Generated when access point state changes to UP.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '    1) domainId - Access point domain ID' || chr(13)||chr(10) ||
  '    2) controllerId - Access point controller ID' || chr(13)||chr(10) ||
  '    3) macAddr - Access point MAC address' || chr(13)||chr(10) ||
  '    4) ipAddr - Access point IP address' || chr(13)||chr(10) ||
  '    5) vendor - Access point vendor name' || chr(13)||chr(10) ||
  '    6) model - Access point model' || chr(13)||chr(10) ||
  '    7) serialNumber - Access point serial number' || chr(13)||chr(10) ||
  '    8) state - Access point state'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  73, 'SYS_AP_UNPROVISIONED', '846a3581-aad1-4e17-9c55-9bd2e6b1247b',
  3, 1,
  'Access point state changed to UNPROVISIONED',
  'Generated when access point state changes to UNPROVISIONED.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '    1) domainId - Access point domain ID' || chr(13)||chr(10) ||
  '    2) controllerId - Access point controller ID' || chr(13)||chr(10) ||
  '    3) macAddr - Access point MAC address' || chr(13)||chr(10) ||
  '    4) ipAddr - Access point IP address' || chr(13)||chr(10) ||
  '    5) vendor - Access point vendor name' || chr(13)||chr(10) ||
  '    6) model - Access point model' || chr(13)||chr(10) ||
  '    7) serialNumber - Access point serial number' || chr(13)||chr(10) ||
  '    8) state - Access point state'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  74, 'SYS_AP_DOWN', '2c8c6208-d3ab-4b8c-926a-872f4d8abcee',
  4, 1,
  'Access point state changed to DOWN',
  'Generated when access point state changes to DOWN.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '    1) domainId - Access point domain ID' || chr(13)||chr(10) ||
  '    2) controllerId - Access point controller ID' || chr(13)||chr(10) ||
  '    3) macAddr - Access point MAC address' || chr(13)||chr(10) ||
  '    4) ipAddr - Access point IP address' || chr(13)||chr(10) ||
  '    5) vendor - Access point vendor name' || chr(13)||chr(10) ||
  '    6) model - Access point model' || chr(13)||chr(10) ||
  '    7) serialNumber - Access point serial number' || chr(13)||chr(10) ||
  '    8) state - Access point state'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  142, 'SYS_AP_UNKNOWN', 'dcbdd08c-d5ff-48b8-90c2-4990eb974c95',
  0, 1,
  'Access point state changed to UNKNOWN',
  'Generated when access point state changes to UNKNOWN.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '    1) domainId - Access point domain ID' || chr(13)||chr(10) ||
  '    2) controllerId - Access point controller ID' || chr(13)||chr(10) ||
  '    3) macAddr - Access point MAC address' || chr(13)||chr(10) ||
  '    4) ipAddr - Access point IP address' || chr(13)||chr(10) ||
  '    5) vendor - Access point vendor name' || chr(13)||chr(10) ||
  '    6) model - Access point model' || chr(13)||chr(10) ||
  '    7) serialNumber - Access point serial number' || chr(13)||chr(10) ||
  '    8) state - Access point state'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      75, 'SYS_IF_MASK_CHANGED', 'f800e593-057e-4aec-9e47-be0f7718c5c4',
      0, 1,
      'Interface "%2" changed mask from /%6 to /%4 (IP Addr: %3/%4, IfIndex: %5)',
      'Generated when when network mask on interface is corrected.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) interfaceObjectId - Interface object ID' || chr(13)||chr(10) ||
      '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
      '   3) interfaceIpAddress - Interface IP address' || chr(13)||chr(10) ||
      '   4) interfaceNetmask - Interface netmask' || chr(13)||chr(10) ||
      '   5) interfaceIndex - Interface index' || chr(13)||chr(10) ||
      '   6) interfaceOldMask - Interface old mask'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      76, 'SYS_IF_IPADDR_ADDED', '475bdca6-543e-410b-9aff-c217599e0fe6',
      0, 1,
      'IP address %3/%4 added to interface "%2"',
      'Generated when IP address added to interface.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) interfaceObjectId - object ID' || chr(13)||chr(10) ||
      '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
      '   3) ipAddress - IP address' || chr(13)||chr(10) ||
      '   4) networkMask - Network mask' || chr(13)||chr(10) ||
      '   5) interfaceIndex - Interface index'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      77, 'SYS_IF_IPADDR_DELETED', 'ef477387-eb50-4a1a-bf90-717502b9873c',
      0, 1,
      'IP address %3/%4 deleted from interface "%2"',
      'Generated when IP address deleted from interface.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) interfaceObjectId - object ID' || chr(13)||chr(10) ||
      '   2) interfaceName - Interface name' || chr(13)||chr(10) ||
      '   3) ipAddress - IP address' || chr(13)||chr(10) ||
      '   4) networkMask - Network mask' || chr(13)||chr(10) ||
      '   5) interfaceIndex - Interface index'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      78, 'SYS_MAINTENANCE_MODE_ENTERED', '5f6c8b1c-f162-413e-8028-80e7ad2c362d',
      0, 1,
      'Entered maintenance mode',
      'Generated when node, cluster, or mobile device entered maintenance mode.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) comments - Comments' || chr(13)||chr(10) ||
      '   2) userId - Initiating user ID' || chr(13)||chr(10) ||
      '   3) userName - Initiating user name'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      79, 'SYS_MAINTENANCE_MODE_LEFT', 'cab06848-a622-430d-8b4c-addeea732657',
      0, 1,
      'Left maintenance mode',
      'Generated when node, cluster, or mobile device left maintenance mode.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) userId - Initiating user ID' || chr(13)||chr(10) ||
      '   2) userName - Initiating user name'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      80, 'SYS_LDAP_SYNC_ERROR', 'f7e8508d-1503-4736-854b-1e5b8b0ad1f2',
      3, 1,
      'LDAP sync error: %5',
      'Generated when LDAP synchronization error occurs.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) userId - User ID' || chr(13)||chr(10) ||
      '   2) userGuid - User GUID' || chr(13)||chr(10) ||
      '   3) userLdapDn - User LDAP DN' || chr(13)||chr(10) ||
      '   4) userName - User name' || chr(13)||chr(10) ||
      '   5) description - Problem description'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      81, 'SYS_AGENT_LOG_PROBLEM', '262057ca-357a-4a4d-9b78-42ae96e490a1',
      3, 1,
      'Problem with agent log: %2',
      'Generated on status poll if agent reports problem with log file.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) statusCode - Status code' || chr(13)||chr(10) ||
      '   2) description - Description'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      82, 'SYS_AGENT_LOCAL_DATABASE_PROBLEM', 'd02b63f1-1151-429e-adb9-1dfbb3a31b32',
      3, 1,
      'Problem with agent local database: %2',
      'Generated on status poll if agent reports local database problem.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) statusCode - Status code' || chr(13)||chr(10) ||
      '   2) description - Description'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  83, 'SYS_IF_EXPECTED_STATE_UP', '4997c3f5-b332-4077-8e99-983142f0e193',
  0, 1,
  'Expected state for interface "%2" set to UP',
  'Generated when interface expected state set to UP.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   2) intefaceName - Interface name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  84, 'SYS_IF_EXPECTED_STATE_DOWN', '75de536c-4861-4f19-ba56-c43d814431d7',
  0, 1,
  'Expected state for interface "%2" set to DOWN',
  'Generated when interface expected state set to DOWN.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   2) intefaceName - Interface name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  85, 'SYS_IF_EXPECTED_STATE_IGNORE', '0e488c0e-3340-4e02-ad96-b999b8392e55',
  0, 1,
  'Expected state for interface "%2" set to IGNORE',
  'Generated when interface expected state set to IGNORE.' || chr(13)||chr(10) ||
  'Please note that source of event is node, not an interface itself.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) interfaceIndex - Interface index' || chr(13)||chr(10) ||
  '   2) intefaceName - Interface name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  86, 'SYS_ROUTING_LOOP_DETECTED', '98276f42-dc85-41a5-b449-6ba83d1a71b7',
  3, 1,
  'Routing loop detected for destination %3 (selected route %6/%7 via %9)',
  'Generated when server detects routing loop during network path trace.' || chr(13)||chr(10) ||
  'Source of the event is node which routes packet back to already passed hop.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) protocol - Protovol (IPv4 or IPv6)' || chr(13)||chr(10) ||
  '   2) destinationNodeId - Path trace destination node ID' || chr(13)||chr(10) ||
  '   3) destinationAddress - Path trace destination address' || chr(13)||chr(10) ||
  '   4) sourceNodeId - Path trace source node ID' || chr(13)||chr(10) ||
  '   5) sourceNodeAddress - Path trace source node address' || chr(13)||chr(10) ||
  '   6) routingPrefix - Routing prefix (subnet address)' || chr(13)||chr(10) ||
  '   7) routingPrefixLength - Routing prefix length (subnet mask length)' || chr(13)||chr(10) ||
  '   8) nextHopNodeId - Next hop node ID' || chr(13)||chr(10) ||
  '   9) nextHopAddress - Next hop address'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  87, 'SYS_PACKAGE_INSTALLED', '92e5cf98-a415-4414-9ad8-d155dac77e96',
  0, 1,
  'Package %1 %2 installed',
  'Generated when new software package is found.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) name - Package name' || chr(13)||chr(10) ||
  '   2) version - Package version'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  88, 'SYS_PACKAGE_UPDATED', '9d5878c1-525e-4cab-8f02-2a6c46d7fc36',
  0, 1,
  'Package %1 updated from %3 to %2',
  'Generated when software package version change is detected.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) name - Package name' || chr(13)||chr(10) ||
  '   2) version - New package version' || chr(13)||chr(10) ||
  '   3) previousVersion - Old package version'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  89, 'SYS_PACKAGE_REMOVED', '6ada4ea4-43e4-4444-9d19-ef7366110bb9',
  0, 1,
  'Package %1 %2 removed',
  'Generated when software package removal is detected.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) name - Package name' || chr(13)||chr(10) ||
  '   2) version - Last known package version'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  90, 'SYS_POLICY_AUTODEPLOY', 'f26d70b3-d48d-472c-b2ec-bfa7c20958ea',
  0, 1,
  'Agent policy %4 automatically deployed to node %2',
  'Generated when agent policy deployed to node by autodeploy rule.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) Node ID' || chr(13)||chr(10) ||
  '   2) Node name' || chr(13)||chr(10) ||
  '   3) Policy ID' || chr(13)||chr(10) ||
  '   4) Policy name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  91, 'SYS_POLICY_AUTOUNINSTALL', '2fbac886-2cfa-489f-bef1-364a38fa7062',
  0, 1,
  'Agent policy %4 automatically uninstalled from node %2',
  'Generated when agent policy uninstalled from node by autodeploy rule.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) Node ID' || chr(13)||chr(10) ||
  '   2) Node name' || chr(13)||chr(10) ||
  '   3) Policy ID' || chr(13)||chr(10) ||
  '   4) Policy name'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  92, 'SYS_UNBOUND_TUNNEL', '7f781ec2-a8f5-4c02-ad7f-9e5b0a223b87',
  0, 1,
  'Unbound agent tunnel from %<systemName> (%<ipAddress>) is idle for more than %<idleTimeout> seconds',
  'Generated when unbound agent tunnel is not bound or closed for more than configured threshold.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) tunnelId - Tunnel ID' || chr(13)||chr(10) ||
  '   2) ipAddress - Remote system IP address' || chr(13)||chr(10) ||
  '   3) systemName - Remote system name' || chr(13)||chr(10) ||
  '   4) hostName - Remote system FQDN' || chr(13)||chr(10) ||
  '   5) platformName - Remote system platform' || chr(13)||chr(10) ||
  '   6) systemInfo - Remote system information' || chr(13)||chr(10) ||
  '   7) agentVersion - Agent version' || chr(13)||chr(10) ||
  '   8) agentId - Agent ID' || chr(13)||chr(10) ||
  '   9) idleTimeout - Configured idle timeout'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  94, 'SYS_TUNNEL_OPEN', '2569c729-1f8c-4a13-9e75-a1d0c1995bc2',
  0, 1,
  'Agent tunnel from %<systemName> (%<ipAddress>) is open',
  'Generated when agent tunnel is open and bound.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) tunnelId - Tunnel ID' || chr(13)||chr(10) ||
  '   2) ipAddress - Remote system IP address' || chr(13)||chr(10) ||
  '   3) systemName - Remote system name' || chr(13)||chr(10) ||
  '   4) hostName - Remote system FQDN' || chr(13)||chr(10) ||
  '   5) platformName - Remote system platform' || chr(13)||chr(10) ||
  '   6) systemInfo - Remote system information' || chr(13)||chr(10) ||
  '   7) agentVersion - Agent version' || chr(13)||chr(10) ||
  '   8) agentId - Agent ID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  95, 'SYS_TUNNEL_CLOSED', '50a61266-710d-48d7-b620-9eaa0f85a94f',
  1, 1,
  'Agent tunnel from %<systemName> (%<ipAddress>) is closed',
  'Generated when agent tunnel is closed.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) tunnelId - Tunnel ID' || chr(13)||chr(10) ||
  '   2) ipAddress - Remote system IP address' || chr(13)||chr(10) ||
  '   3) systemName - Remote system name' || chr(13)||chr(10) ||
  '   4) hostName - Remote system FQDN' || chr(13)||chr(10) ||
  '   5) platformName - Remote system platform' || chr(13)||chr(10) ||
  '   6) systemInfo - Remote system information' || chr(13)||chr(10) ||
  '   7) agentVersion - Agent version' || chr(13)||chr(10) ||
  '   8) agentId - Agent ID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  96, 'SYS_TUNNEL_AGENT_ID_MISMATCH', '30792e3d-f94a-4866-9616-457ba3ac276a',
  1, 1,
  'Agent ID %<nodeAgentId> on node do not match agent ID %<tunnelAgentId> on tunnel from %<systemName> (%<ipAddress>) at bind',
  'Generated when agent ID mismatch detected during tunnel bind.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) tunnelId - Tunnel ID' || chr(13)||chr(10) ||
  '   2) ipAddress - Remote system IP address' || chr(13)||chr(10) ||
  '   3) systemName - Remote system name' || chr(13)||chr(10) ||
  '   4) hostName - Remote system FQDN' || chr(13)||chr(10) ||
  '   5) platformName - Remote system platform' || chr(13)||chr(10) ||
  '   6) systemInfo - Remote system information' || chr(13)||chr(10) ||
  '   7) agentVersion - Agent version' || chr(13)||chr(10) ||
  '   8) tunnelAgentId - Tunnel agent ID' || chr(13)||chr(10) ||
  '   9) nodeAgentId - Node agent ID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  93, 'SYS_AGENT_ID_CHANGED', '741f0abc-1e69-46e4-adbc-bf1c4ed8549a',
  1, 1,
  'Agent ID changed from %1 to %2',
  'Generated when agent ID change detected.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) oldAgentId - Old agent ID' || chr(13)||chr(10) ||
  '   2) newAgentId - New agent ID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  97, 'SYS_SERVER_STARTED', '32f3305b-1c1b-4597-9eb5-b74eca54330d',
  0, 1,
  'Server started',
  'Generated when server initialization is completed.'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  98, 'SYS_HARDWARE_COMPONENT_ADDED', '3677d317-d5fc-4ba7-83a9-890db4aa7112',
  0, 1,
  '%1 %4 (%2) added',
  'Generated when new hardware component is found.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) category - Category' || chr(13)||chr(10) ||
  '   2) type - Type' || chr(13)||chr(10) ||
  '   3) vendor - Vendor' || chr(13)||chr(10) ||
  '   4) model - Model' || chr(13)||chr(10) ||
  '   5) location - Location' || chr(13)||chr(10) ||
  '   6) partNumber - Part number' || chr(13)||chr(10) ||
  '   7) serialnumber - Serial number' || chr(13)||chr(10) ||
  '   8) capacity - Capacity' || chr(13)||chr(10) ||
  '   9) description - Description'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  99, 'SYS_HARDWARE_COMPONENT_REMOVED', '72904936-1d42-40c4-810c-e226ae44d7f1',
  0, 1,
  '%1 %4 (%2) removed',
  'Generated when hardware component removal is detected.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) category - Category' || chr(13)||chr(10) ||
  '   2) type - Type' || chr(13)||chr(10) ||
  '   3) vendor - Vendor' || chr(13)||chr(10) ||
  '   4) model - Model' || chr(13)||chr(10) ||
  '   5) location - Location' || chr(13)||chr(10) ||
  '   6) partNumber - Part number' || chr(13)||chr(10) ||
  '   7) serialnumber - Serial number' || chr(13)||chr(10) ||
  '   8) capacity - Capacity' || chr(13)||chr(10) ||
  '   9) description - Description'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  100, 'SYS_DUPLICATE_NODE_DELETED', 'b587cd90-d98b-432f-acfd-ff51f25c27d1',
  1, 1,
  'Duplicate node %5 is deleted (%7)',
  'Generated when node is deleted by network discovery de-duplication process.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) originalNodeObjectId - Original node object ID' || chr(13)||chr(10) ||
  '   2) originalNodeName - Original node name' || chr(13)||chr(10) ||
  '   3) originalNodePrimaryHostName - Original node primary host name' || chr(13)||chr(10) ||
  '   4) duplicateNodeObjectId - Duplicate node object ID' || chr(13)||chr(10) ||
  '   5) duplicateNodeName - Duplicate node name' || chr(13)||chr(10) ||
  '   6) duplicateNodePrimaryHostName - Duplicate node primary host name' || chr(13)||chr(10) ||
  '   7) reason - Reason'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  101, 'SYS_DUPLICATE_IP_ADDRESS', 'f134169c-9f88-4390-9e0e-248b7f8a0013',
  1, 1,
  'IP address %1 already known on node %3 interface %4 with MAC %5 but found via %8 with MAC %6',
  'Generated when possibly duplicate IP address is detected by network discovery process.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) ipAddress - IP address' || chr(13)||chr(10) ||
  '   2) knownNodeId - Known node object ID' || chr(13)||chr(10) ||
  '   3) knownNodeName - Known node name' || chr(13)||chr(10) ||
  '   4) knownInterfaceName - Known interface name' || chr(13)||chr(10) ||
  '   5) knownMacAddress - Known MAC address' || chr(13)||chr(10) ||
  '   6) discoveredMacAddress - Discovered MAC address' || chr(13)||chr(10) ||
  '   7) discoverySourceNodeId - Discovery source node object ID' || chr(13)||chr(10) ||
  '   8) discoverySourceNodeName - Discovery source node name' || chr(13)||chr(10) ||
  '   9) discoveryDataSource - Discovery data source'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  102, 'SYS_ETHERNET_IP_UNREACHABLE', '3fbbe8da-70cf-449d-9c6c-64333c6ff60',
  3, 1,
  'EtherNet/IP connectivity failed',
  'Generated when node is not responding to EtherNet/IP requests.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  103, 'SYS_ETHERNET_IP_OK', '25c7104e-168b-4845-8c96-28edf715785f',
  0, 1,
  'EtherNet/IP connectivity restored',
  'Generated when EtherNet/IP connectivity with the node is restored.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  104, 'SYS_DBWRITER_QUEUE_OVERFLOW', 'fba287e7-a8ea-4503-a494-3d6e5a3d83df',
  3, 1,
  'Size of background database writer queue exceeds threshold (new performance data will be discarded)',
  'Generated when background database writer queue size exceeds threshold.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  105, 'SYS_DBWRITER_QUEUE_NORMAL', '73950d5f-37c0-4b87-9467-c83d7e662401',
  0, 1,
  'Size of background database writer queue is below threshold',
  'Generated when background database writer queue size drops below threshold.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  106, 'SYS_HOUSEKEEPER_STARTED', 'cbbf0da4-1784-49a5-af9b-e8c59451d3ce',
  0, 1,
  'Housekeeper task started',
  'Generated when internal housekeeper task starts.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  107, 'SYS_HOUSEKEEPER_COMPLETED', '69743397-6f2b-4777-8bde-879a6e3e47f9',
  0, 1,
  'Housekeeper task completed in %1 seconds',
  'Generated when internal housekeeper task completes.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) elapsedTime - Housekeeper execution time in seconds'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  108, 'SYS_LICENSE_PROBLEM', 'ea282f6f-c636-414f-91ce-0aa871648144',
  1, 1,
  'License problem - %1',
  'Generated when licensing problem is detected by extension module.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) description - Problem description'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      109, 'SYS_SNMP_TRAP_FLOOD_DETECTED', '6b2bb689-23b7-4e7c-9128-5102f658e450',
      3, 1,
      'SNMP trap flood detected (Traps per second: %1)',
      'Generated when system detects an SNMP trap flood.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) snmpTrapsPerSecond - SNMP traps per second' || chr(13)||chr(10) ||
      '   2) duration - Duration' || chr(13)||chr(10) ||
      '   3) threshold - Threshold'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      110, 'SYS_SNMP_TRAP_FLOOD_ENDED', 'f2c41199-9338-4c9a-9528-d65835c6c271',
      0, 1,
      'SNMP trap flood ended',
      '	' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) snmpTrapsPerSecond - SNMP traps per second' || chr(13)||chr(10) ||
      '   2) duration - Duration' || chr(13)||chr(10) ||
      '   3) threshold - Threshold'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      111, 'SYS_GEOLOCATION_CHANGED', '2c2f40d4-91d3-441e-92d4-62a32e98a341',
      0, 1,
      'Device geolocation changed to %3 %4 (was %7 %8)',
      'Generated when device geolocation change is detected.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) newLatitude - Latitude of new location in degrees' || chr(13)||chr(10) ||
      '   2) newLongitude - Longitude of new location in degrees' || chr(13)||chr(10) ||
      '   3) newLatitudeAsString- Latitude of new location in textual form' || chr(13)||chr(10) ||
      '   4) newLongitudeAsString - Longitude of new location in textual form' || chr(13)||chr(10) ||
      '   5) previousLatitude - Latitude of previous location in degrees' || chr(13)||chr(10) ||
      '   6) previousLongitude - Longitude of previous location in degrees' || chr(13)||chr(10) ||
      '   7) previousLatitudeAsString - Latitude of previous location in textual form' || chr(13)||chr(10) ||
      '   8) previoudLongitudeAsString - Longitude of previous location in textual form'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      112, 'SYS_GEOLOCATION_INSIDE_RESTRICTED_AREA', '94d7a94b-a289-4cbe-8a83-a9c52b36c650',
      1, 1,
      'Device geolocation %3 %4 is within restricted area %5',
      'Generated when new device geolocation is within restricted area.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) newLatitude - Latitude of new location in degrees' || chr(13)||chr(10) ||
      '   2) newLongitude - Longitude of new location in degrees' || chr(13)||chr(10) ||
      '   3) newLatitudeAsString - Latitude of new location in textual form' || chr(13)||chr(10) ||
      '   4) newLongitudeAsString - Longitude of new location in textual form' || chr(13)||chr(10) ||
      '   5) areaName - Area name' || chr(13)||chr(10) ||
      '   6) areaId - Area ID'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      113, 'SYS_GEOLOCATION_OUTSIDE_ALLOWED_AREA', '24dcb315-a5cc-41f5-a813-b0a5f8c31e7d',
      1, 1,
      'Device geolocation %3 %4 is outside allowed area',
      'Generated when new device geolocation is ouside allowed areas.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) newLatitude - Latitude of new location in degrees' || chr(13)||chr(10) ||
      '   2) newLongitude - Longitude of new location in degrees' || chr(13)||chr(10) ||
      '   3) newLatitudeAsString - Latitude of new location in textual form' || chr(13)||chr(10) ||
      '   4) newLongitudeAsString - Longitude of new location in textual form'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      114, 'SYS_CLUSTER_AUTOADD', '308fce5f-69ec-450a-a42b-d1e5178512a5',
      0, 1,
      'Node %2 automatically added to cluster %4',
      'Generated when node added to cluster object by autoadd rule.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) nodeId - Node ID' || chr(13)||chr(10) ||
      '   2) nodeName - Node name' || chr(13)||chr(10) ||
      '   3) clusterId - Cluster ID' || chr(13)||chr(10) ||
      '   4) clusterName - Cluster name'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      115, 'SYS_CLUSTER_AUTOREMOVE', 'f2cdb47a-ae37-43d7-851d-f8f85e1e9f0c',
      0, 1,
      'Node %2 automatically removed from cluster %4',
      'Generated when node removed from cluster object by autoadd rule.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) nodeId - Node ID' || chr(13)||chr(10) ||
      '   2) nodeName - Node name' || chr(13)||chr(10) ||
      '   3) clusterId - Cluster ID' || chr(13)||chr(10) ||
      '   4) clusterName - Cluster name'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  116, 'SYS_TUNNEL_HOST_DATA_MISMATCH', '874aa4f3-51b9-49ad-a8df-fb4bb89d0f81',
  1, 1,
  'Host data mismatch on tunnel reconnect',
  'Generated when new tunnel is replacing existing one and host data mismatch is detected.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) tunnelId - Tunnel ID' || chr(13)||chr(10) ||
  '   2) oldIPAddress - Old remote system IP address' || chr(13)||chr(10) ||
  '   3) newIPAddress - New remote system IP address' || chr(13)||chr(10) ||
  '   4) oldSystemName - Old remote system name' || chr(13)||chr(10) ||
  '   5) newSystemName- New remote system name' || chr(13)||chr(10) ||
  '   6) oldHostName - Old remote system FQDN' || chr(13)||chr(10) ||
  '   7) newHostName - New remote system FQDN' || chr(13)||chr(10) ||
  '   8) oldHardwareId - Old hardware ID' || chr(13)||chr(10) ||
  '   9) newHardwareId - New hardware ID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      117, 'SYS_POLICY_VALIDATION_ERROR', '7a0c3a71-8125-4692-985a-a7e94fbee570',
      1, 1,
      'Failed validation of %4 policy %3 in template %1 (%6)',
      'Generated when agent policy within template fails validation.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) templateName - Template name' || chr(13)||chr(10) ||
      '   2) templateId - Template ID' || chr(13)||chr(10) ||
      '   3) policyName - Policy name' || chr(13)||chr(10) ||
      '   4) policyType - Policy type' || chr(13)||chr(10) ||
      '   5) policyId - Policy ID' || chr(13)||chr(10) ||
      '   6) additionalInfo - Additional info'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      118, 'SYS_TUNNEL_SETUP_ERROR', '50792874-0b2e-4eca-8c54-274b7d5e3aa2',
      3, 1,
      'Error setting up agent tunnel from %<ipAddress> (%<error>)',
      'Generated on agent tunnel setup error.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) Source IP address (ipAddress)' || chr(13)||chr(10) ||
      '   2) Error message (error)'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      119, 'SYS_DUPLICATE_MAC_ADDRESS', 'c19fbb37-98c9-43a5-90f2-7a54ba9116fa',
      3, 1,
      'Duplicate MAC address found (%1 on %2)',
      'Generated when duplicate MAC address found.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) macAddress - MAC address ' || chr(13)||chr(10) ||
      '   2) listOfInterfaces - List of interfaces where MAC address was found'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      120, 'SYS_BUSINESS_SERVICE_OPERATIONAL', 'ffe557a4-f572-44a8-928e-020b3fbd07b0',
      0, 1,
      'Business service changed state to operational',
      'Generated when business service state changes to operational.' || chr(13)||chr(10) ||
      '   No event-specific parameters'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      124, 'SYS_BUSINESS_SERVICE_DEGRADED', '39bd18fc-bfd7-4c31-af9c-1e96ef3aef64',
      2, 1,
      'Business service changed state to degraded',
      'Generated when business service state changes to degraded.' || chr(13)||chr(10) ||
      '   No event-specific parameters'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      121, 'SYS_BUSINESS_SERVICE_FAILED', 'fc66c83f-c7e8-4635-ad2d-89589d8b0fc2',
      4, 1,
      'Business service changed state to failed',
      'Generated when business service state changes to failed.' || chr(13)||chr(10) ||
      '   No event-specific parameters'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      123, 'SYS_ICMP_OK', '6c6f3d24-4cf0-40a1-a4c9-1686ff37533d',
      0, 1,
      'Node started responding to ICMP',
      'Generated when node start responding to ICMP again' || chr(13)||chr(10) ||
      '   No event-specific parameters'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      122, 'SYS_ICMP_UNREACHABLE', '5eaf0007-2018-44c7-8f83-d244279aca4f',
      3, 1,
      'Node is unreachable by ICMP',
      'Generated when node is unreachable by ICMP.' || chr(13)||chr(10) ||
      '   No event-specific parameters'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      125, 'SYS_NOTIFICATION_CHANNEL_DOWN', '5696d263-0a1c-4c3b-b5bb-d6be8993ac0d',
      3, 1,
      'Notification channel %1 is down',
      'Generated when notification channel fails health check.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) channelName - Notification channel name' || chr(13)||chr(10) ||
      '   2) channelDriverName - Notification channel driver name'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      126, 'SYS_NOTIFICATION_CHANNEL_UP', '19536ccb-96ed-417a-8695-94dc6d504d73',
      0, 1,
      'Notification channel %1 is up',
      'Generated when notification channel passes health check.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) channelName - Notification channel name' || chr(13)||chr(10) ||
      '   2) channelDriverName - Notification channel driver name'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      127, 'SYS_AGENT_FILE_CHANGED', '04c3e538-a668-4c27-a238-d1891b34f3df',
      1, 1,
      'File %1 changed',
      'Generated when agent monitored file is changed.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) Path to changed file'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      128, 'SYS_AGENT_FILE_ADDED', '2f139a92-cb1c-4974-8a7c-0ad714a04394',
      1, 1,
      'File %1 added',
      'Generated when new file in agent monitored directory is created.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) Path to new file'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      129, 'SYS_AGENT_FILE_DELETED', '11c6a29d-94e8-4eb6-a177-deece3a83483',
      1, 1,
      'File %1 deleted',
      'Generated when agent monitored file is deleted.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) Path to deleted file'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
   (
      130, 'SYS_TOO_MANY_SCRIPT_ERRORS', 'c71f2aa6-9345-43d4-90da-c5c3ee55f30d',
      1, 1,
      'Too many script errors - script error reporting temporarily suspended',
      'Generated when there are too many script errors within short time period.' || chr(13)||chr(10) ||
      '   No event-specific parameters'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  131, 'SYS_SSH_OK', '7f6fb204-9334-4e67-9db6-1459af704bd2',
  0, 1,
  'Node responds to SSH',
      'Generated when node becomes reachable by SSH.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  132, 'SYS_SSH_UNREACHABLE', '55a6a26e-e1f0-4196-b325-833d8a1311fe',
  3, 1,
  'Node does not respond to SSH',
      'Generated when node becomes unreachable by SSH.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  133, 'SYS_ASSET_AUTO_UPDATE_FAILED', 'f4ae5e79-9d39-41d0-b74c-b6c591930d08',
  3, 1,
  'Automatic update of asset management attribute "%<name>" with value "%<newValue>" failed (%<reason>)',
      'Generated when automatic update of asset management attribute fails.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) name - attribute''s name' || chr(13)||chr(10) ||
      '   2) displayName - attribute''s display name' || chr(13)||chr(10) ||
      '   3) dataType - attribute''s data type' || chr(13)||chr(10) ||
      '   4) currValue - current attribute''s value' || chr(13)||chr(10) ||
      '   5) newValue - new attribute''s value' || chr(13)||chr(10) ||
      '   6) reason - failure reason'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
      134, 'SYS_ASSET_LINK', '8dae7b06-b854-4d88-9eb7-721b6110c200',
      0, 1,
      'Asset %<assetName> linked',
      'Generated when asset is linked with node.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) assetId - asset ID' || chr(13)||chr(10) ||
      '   2) assetName - asset name'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
      135, 'SYS_ASSET_UNLINK', 'f149433b-ea2f-4bfd-bf23-35e7778b1b55',
      0, 1,
      'Asset %<assetName> unlinked',
      'Generated when asset is unlinked from node.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) assetId - asset ID' || chr(13)||chr(10) ||
      '   2) assetName - asset name'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
      136, 'SYS_ASSET_LINK_CONFLICT', '2bfd6557-1b88-4cf0-801b-78cffb2afc3c',
      2, 1,
      'Automatic linking of asset %<assetName> failed because it is already linked with node %<currentNodeName>',
      'Generated when asset cannot be automatically linked with a node because of conflict.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) assetId - asset ID found by automatic linking process' || chr(13)||chr(10) ||
      '   2) assetName - asset name found by automatic linking process' || chr(13)||chr(10) ||
      '   3) currentNodeId - ID of currently linked node' || chr(13)||chr(10) ||
      '   4) currentNodeName - name of currently linked node'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
      137, 'SYS_CONFIGURATION_ERROR', '762c581c-e9bf-11ed-a05b-0242ac120003',
      2, 1,
      'System configuration error (%<description>)',
      'Generated on any system configuration error.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) subsystem - The subsystem which has the error' || chr(13)||chr(10) ||
      '   2) tag - Related tag for the error' || chr(13)||chr(10) ||
      '   3) descriptipon - Description of the error'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  138, 'SYS_MODBUS_UNREACHABLE', 'f8dc0d5f-0e46-4bbf-a91d-bb3c0412db2e',
  3, 1,
  'Modbus connectivity failed',
  'Generated when node is not responding to Modbus requests.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  139, 'SYS_MODBUS_OK', '47584648-fc4e-4757-b4e7-f6f16b146bac',
  0, 1,
  'Modbus connectivity restored',
  'Generated when Modbus connectivity with the node is restored.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   No event-specific parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
      140, 'SYS_IF_STP_STATE_CHANGED', '977a5634-d0ec-44a0-a7a5-6e193ca57c38',
      0, 1,
      'Interface %<ifName> STP state changed from %<oldStateText> to %<newStateText>',
      'Generated when system detects interface Spanning Tree state change.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) ifIndex - Interface index' || chr(13)||chr(10) ||
      '   2) ifName - Interface name' || chr(13)||chr(10) ||
      '   3) oldState - Old state' || chr(13)||chr(10) ||
      '   4) oldStateText - Old state as text' || chr(13)||chr(10) ||
      '   5) newState - New state' || chr(13)||chr(10) ||
      '   6) newStateText - New state as text'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
      141, 'SYS_IF_SPEED_CHANGED', '3967eab5-71c0-4ba7-aeb9-eb70bcf5caa9',
      0, 1,
      'Interface %<ifName> speed changed from %<oldSpeedText> to %<newSpeedText>',
      'Generated when system detects interface speed change.' || chr(13)||chr(10) ||
      'Parameters:' || chr(13)||chr(10) ||
      '   1) ifIndex - Interface index' || chr(13)||chr(10) ||
      '   2) ifName - Interface name' || chr(13)||chr(10) ||
      '   3) oldSpeed - Old speed in bps' || chr(13)||chr(10) ||
      '   4) oldSpeedText - Old speed in bps with optional multiplier (kbps, Mbps, etc.)' || chr(13)||chr(10) ||
      '   5) newSpeed - New speed in bps' || chr(13)||chr(10) ||
      '   6) newSpeedText - New speed in bps with optional multiplier (kbps, Mbps, etc.)'
   );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  500, 'SNMP_UNMATCHED_TRAP', 'fc3613f7-d151-4221-9acd-d28b6f804335',
  0, 1,
  'SNMP trap received: %1 (Parameters: %2)',
  'Generated when system receives an SNMP trap without match in trap configuration table' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) SNMP trap OID' || chr(13)||chr(10) ||
  '   2) Trap parameters'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  501, 'SNMP_COLD_START', '39920e99-97bd-4d61-a462-43f89ba6fbdf',
  0, 1,
  'System was cold-started',
  'Generated when system receives a coldStart SNMP trap' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) SNMP trap OID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  502, 'SNMP_WARM_START', '0aa888c1-eba6-4fe7-a37a-b85f2b373bdc',
  0, 1,
  'System was warm-started',
  'Generated when system receives a warmStart SNMP trap' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) SNMP trap OID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  503, 'SNMP_LINK_DOWN', 'b71338cc-137d-473c-a0f1-6b131086af56',
  3, 1,
  'Link is down (interface index %2)',
  'Generated when system receives a linkDown SNMP trap' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) SNMP trap OID' || chr(13)||chr(10) ||
  '   2) Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  504, 'SNMP_LINK_UP', '03da14a7-e39c-4a46-a7cb-4bf77ec7936c',
  0, 1,
  'Link is up (interface index %2)',
  'Generated when system receives a linkUp SNMP trap' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) SNMP trap OID' || chr(13)||chr(10) ||
  '   2) Interface index'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  505, 'SNMP_AUTH_FAILURE', '37020cb0-dde7-487b-9cfb-0d5ee771aa13',
  1, 1,
  'SNMP authentication failure',
  'Generated when system receives an authenticationFailure SNMP trap' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) SNMP trap OID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  506, 'SNMP_EGP_NEIGHBOR_LOSS', 'aecf5fa4-390c-4125-be10-df8b0e669fe1',
  1, 1,
  'EGP neighbor loss',
  'Generated when system receives an egpNeighborLoss SNMP trap' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) SNMP trap OID'
 );
INSERT INTO event_cfg (event_code,event_name,guid,severity,flags,message,description) VALUES
 (
  507, 'SNMP_DISCARD_TRAP', '48f1217b-2eeb-4cde-88ab-da3de662bb2d',
  0, 0,
  'SNMP trap received: %1',
  'Default event for discarded SNMP traps.' || chr(13)||chr(10) ||
  'Parameters:' || chr(13)||chr(10) ||
  '   1) SNMP trap OID'
 );
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (0,'2d2c3d32-49d4-4e76-b6aa-782b30d90f28',7944,'Show alarm when node is down',
  '%m',5,'NODE_DOWN_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (1,'4fa20604-b56f-4f12-bb5d-2c3243a126c9',7944,'Terminate node down alarms when node is up',
  '%m',6,'NODE_DOWN_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (2,'45999e66-c16c-400d-8b79-63a0f8eb8958',7944,'Show alarm when network service is down or in unknown state',
  '%m',5,'SERVICE_DOWN_%i_%2','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (3,'8537fa14-e824-435b-a1dd-be3e566b7f67',7944,'Terminate network service down/unknown alarms when service is up',
  '%m',6,'SERVICE_DOWN_%i_%2','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (4,'2daa869f-9921-4f3e-9cb9-004c2f31f70a',7944,'Show alarm when interface is down',
  '%m',5,'IF_DOWN_%i_%5','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (5,'95d42ff2-6fe0-4b1c-9c7b-c18520393f9f',7944,'Terminate interface down alarms when interface is up',
  '%m',6,'IF_DOWN_%i_%5','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (6,'6f46d451-ee66-4563-8747-d129877df24d',7944,'Terminate interface down alarms when interface is deleted or it''s expected state changed',
  '%m',6,'IF_DOWN_%i_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (7,'727a0dca-ecc4-4490-bf4b-3fc8b5ff8cb4',7944,'Show alarm when interface is unexpectedly up',
  '%m',5,'IF_UNEXP_UP_%i_%5','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (8,'11176d3e-0149-448b-a5fe-2be764762775',7944,'Terminate interface unexpectedly up alarms when interface goes down',
  '%m',6,'IF_UNEXP_UP_%i_%5','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (9,'ecc3fb57-672d-489d-a0ef-4214ea896e0f',7944,'Terminate interface unexpectedly up alarms when interface is deleted or it''s expected state changed',
  '%m',6,'IF_UNEXP_UP_%i_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (10,'5b8115f1-5c84-443a-9f88-18fc0b70f29e',7944,'Generate alarm when incorrect network mask detected on interface',
  '%m',2,'BAD_NETMASK_%i_%2','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (11,'062228ef-c155-4669-a90a-603cae13240e',7944,'Generate alarm when server enconters NXSL script execution error',
  '%m',2,'SCRIPT_ERR_%1_%2','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (12,'943f5474-5614-44e1-820c-b8fe17bc4d0b',7944,'Show alarm when connection with backend database is lost',
  '%m',4,'DB_CONN','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (13,'9ce6b59e-e274-4c94-b314-4b4652c10c74',7944,'Terminate DB connection loss alarm when connection restored',
  '%m',6,'DB_CONN','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (14,'e3120a33-216e-e048-aa3b-4f1a9f3f10fc',7944,'Show alarm when NetXMS server network connection is lost',
  '%m',4,'NET_CONN_LOST','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (15,'bdc76d2e-967e-bf44-95a1-a229ef8b3ff4',7944,'Terminate NetXMS server network connection loss alarm when connection restored',
  '%m',6,'NET_CONN_LOST','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (16,'226de02d-9eb2-4ea1-a92c-2bdb1718f2ec',7944,'Show alarm when DCI status changes to DISABLED or UNSUPPORTED',
  '%m',5,'DCI_STATUS_%i_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (17,'02a21afe-c942-4953-8b5d-f463c597cff8',7944,'Terminate DCI status alarms when DCI status returns to ACTIVE',
  '%m',6,'DCI_STATUS_%i_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (18,'47fd5c32-b6c9-48b8-99fb-c389dde63bee',7944,'Generate alarm on threshold violation',
  '%m',5,'DC_THRESHOLD_%i_%<dciId>','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (19,'dcdd6f93-2f9e-4c3e-97cb-95b6847f13ce',7944,'Terminate threshold violation alarms',
  '%m',6,'DC_THRESHOLD_%i_%<dciId>','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (20,'d3acabe8-717d-4ceb-bb7f-498d5af898f2',7944,'Generate alarm on table threshold violation',
  '%m',5,'DCTTHR_%i_%<dciId>_%<instance>','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (21,'8e26af4b-e478-44c9-9c12-0b049ccb6c3c',7944,'Terminate table threshold violation alarms',
  '%m',6,'DCTTHR_%i_%<dciId>_%<instance>','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (22,'ea1dee96-b42e-499c-a992-0b0f9e4874b9',7944,'Generate an alarm when one of the system threads hangs or stops unexpectedly',
        '%m',5,'SYS_THREAD_HANG_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (23,'f0c5a6b2-7427-45e5-8333-7d60d2b408e6',7944,'Terminate the alarm when one of the system threads which previously hanged or stoped unexpectedly returned to the running state',
        '%m',6,'SYS_THREAD_HANG_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (24,'b76f142a-6932-499e-aa6e-ac16cf8effb1',7976,'Terminate alarms for hanged or unexpectedly stopped system threads that could have been created prior to server restart',
        '%m',6,'SYS_THREAD_HANG_.*','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (25,'ed3397a8-a496-4534-839b-5a6fc77c167c',7944,'Generate an alarm when the object enters the maintanance mode',
        '%m',5,'MAINTENANCE_MODE_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
 VALUES (26,'20a0f4a5-d90e-4961-ba88-a65b9ee45d07',7944,'Terminate the alarm when the object leaves the maintanance mode',
        '%m',6,'MAINTENANCE_MODE_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (27,'c6f66840-4758-420f-a27d-7bbf7b66a511',7944,'Generate an alarm if the NetXMS agent on the node stops responding',
        '%m',5,'AGENT_UNREACHABLE_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (28,'9fa60260-c2ec-4371-b4e4-f5346b1d8400',7944,'Terminate the alarm if the NetXMS agent on the node start responding again',
        '%m',6,'AGENT_UNREACHABLE_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (29,'20ef861f-b8e4-4e04-898e-e57d13863661',7944,'Generate an alarm if the SNMP agent on the node stops responding',
        '%m',5,'SNMP_UNREACHABLE_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (30,'33f6193a-e103-4f5f-8bee-870bbcc08066',7944,'Terminate the alarm if the SNMP agent on the node start responding again',
        '%m',6,'SNMP_UNREACHABLE_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (31,'417648af-5361-49a5-9471-6ef31e857b2d',7944,'Generate an alarm when error occurred during LDAP synchronization',
        '%m',5,'SYS_LDAP_SYNC_ERROR_%2','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (32,'19bd89ba-8bb2-4915-8546-a1ecc650dedd',7944,'Generate an alarm when there is problem with agent log',
        '%m',5,'SYS_AGENT_LOG_PROBLEM_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (33,'cff7fe6b-2ad1-4c18-8a8f-4d397d44fe04',7944,'Generate an alarm when there is problem with agent local database',
        '%m',5,'SYS_AGENT_LOCAL_DATABASE_PROBLEM_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (34,'68e102a3-58d3-4112-901c-f683356ba662',7944,'Show alarm when interface with expected state UP is administratively disabled',
        '%m',2,'IF_DOWN_%i_%5',
        'interface = GetInterfaceObject($node, $event->parameters[5]);' || chr(13)||chr(10) || chr(13)||chr(10) ||
        '// if interface not found or interface expected state is not UP, do not match' || chr(13)||chr(10) ||
        '// otherwise (if interface expected status is UP), match' || chr(13)||chr(10) ||
        'return (interface != null && interface->expectedState == 0);',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (35,'68a629ef-c645-49e5-8a7b-c5e79308080e',7944,'Generate alarm when MAC address change detected on interface',
        '%m',1,'MAC_ADDRESS_CHANGED_%i_%2','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (36,'18507220-6a16-4e13-a6ba-141d907b924a',7944,'Terminate MAC address change alarms when the interface is deleted',
        '%m',6,'MAC_ADDRESS_CHANGED_%i_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (37,'8cca36cd-f821-43ae-8329-0eefe35df3b7',7944,'Terminate network mask alarms when an interface is deleted',
        '%m',6,'BAD_NETMASK_%i_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (38,'404642a0-deb0-400d-b9f9-c86f5a83f7f5',7944,'Terminate network mask alarms when the mask of interface changes or IP address of interface is deleted',
        '%m',6,'BAD_NETMASK_%i_%5','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (39,'b8abb037-ab4a-4e05-adc4-9425ce440e4a',7944,'Generate alarm when a routing loop is detected',
        '%m',5,'ROUTING_LOOP_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (40,'2bb3df47-482b-4e4b-9b49-8c72c6b33011',7944,'Generate alarm on software package changes',
        '%m',5,'SW_PKG_%i_%<name>','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (41,'b517ca11-cdf8-4813-87fa-9a2ace070564',7944,'Generate alarm on agent policy validation failure',
        '%m',5,'POLICY_ERROR_%2_%5','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (42,'bdd8f6b1-fe3a-4b20-bc0b-bb7507b264b2',7944,'Generate alarm on agent tunnel setup error',
        '%m',5,'TUNNEL_SETUP_ERROR_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (43,'c19fbb37-98c9-43a5-90f2-7a54ba9116fa',7944,'Generate alarm when duplicate MAC address detected',
        '%m',5,'DUPLICATE_MAC_ADDRESS_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (44,'aa188673-049f-4c4d-8767-c1cf443c9547',7944,'Generated alarm when business service changes state to failed or degraded',
        '%m',5,'BUSINESS_SERVICE_NOT_OK_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (45,'af00706c-b92a-4335-b441-190609c2494f',7944,'Terminate alarm when business service changes state to operational',
        '%m',6,'BUSINESS_SERVICE_NOT_OK_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (46,'9169a40b-cd9d-4328-b113-f690ef57773e',7944,'Generated alarm when node is unreachable by ICMP',
        '%m',5,'ICMP_UNREACHABLE_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (47,'81320995-d6db-4a3c-9670-12400eba4fe6',7944,'Terminate alarm when node started responding to ICMP again',
        '%m',6,'ICMP_UNREACHABLE_%i','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (48,'96061edf-a46f-407a-a049-a55fa1ffb7e8',7944,'Generated alarm when notification channel is down',
        '%m',5,'NOTIFICATION_CHANNEL_DOWN_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (49,'75640293-d630-4bfc-9b5e-9655cf59fd00',7944,'Terminate notification channel down alarm when notification channel is back up',
        '%m',6,'NOTIFICATION_CHANNEL_DOWN_%1','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (50,'1499d2d3-2304-4bb1-823b-0c530cbb6224',7944,'Generate alarm when automatic update of asset management attribute fails',
        '%m',5,'ASSET_UPDATE_FAILED_%i_%<name>','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event)
    VALUES (51,'acbf02d5-3ff1-4235-a8a8-f85755b9a06b',7944,'Generate alarm when asset linking conflict occurs',
        '%m',5,'ASSET_LINK_CONFLICT_%i_%<assetId>','',0,43);
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event,downtime_tag)
    VALUES (52,'202d5b85-48fc-4b6e-9da9-53a6eb9a341d',89856,'Start downtime',
        '%m',5,'','',0,43,'NODE_DOWN');
INSERT INTO event_policy (rule_id,rule_guid,flags,comments,alarm_message,alarm_severity,alarm_key,filter_script,alarm_timeout,alarm_timeout_event,downtime_tag)
    VALUES (53,'256c2abd-3e14-4e02-9606-7c78c77e1a78',139008,'End downtime',
        '%m',5,'','',0,43,'NODE_DOWN');
INSERT INTO policy_event_list (rule_id,event_code) VALUES (0,28);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (1,29);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (2,25);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (2,27);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (3,26);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (4,5);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (5,4);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (6,16);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (6,84);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (6,85);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (7,62);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (8,63);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (9,16);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (9,83);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (9,85);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (10,24);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (11,33);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (12,36);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (13,37);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (14,50);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (15,51);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (16,54);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (16,53);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (17,55);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (18,17);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (19,18);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (20,69);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (21,70);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (22,20);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (23,21);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (24,97);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (25,78);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (26,79);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (27,15);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (28,32);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (29,14);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (30,31);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (31,80);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (32,81);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (33,82);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (34,46);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (35,23);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (36,16);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (37,16);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (38,75);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (38,77);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (39,86);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (40,87);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (40,88);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (40,89);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (41,117);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (42,118);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (43,119);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (44,121);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (44,124);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (45,120);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (46,122);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (47,123);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (48,125);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (49,126);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (50,133);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (51,136);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (52,28);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (52,68);
INSERT INTO policy_event_list (rule_id,event_code) VALUES (53,29);
INSERT INTO snmp_trap_cfg (guid,trap_id,snmp_oid,event_code,user_tag,description)
   VALUES ('5d01e7e5-edbb-46ce-b53c-f7f64d1bf8ff',1,'.1.3.6.1.6.3.1.1.5.1',501,'','Generic coldStart trap');
INSERT INTO snmp_trap_cfg (guid,trap_id,snmp_oid,event_code,user_tag,description)
   VALUES ('c5464919-fd76-4624-9c21-b6ab73d9df80',2,'.1.3.6.1.6.3.1.1.5.2',502,'','Generic warmStart trap');
INSERT INTO snmp_trap_cfg (guid,trap_id,snmp_oid,event_code,user_tag,description)
   VALUES ('44d3b32e-33c5-4a39-b2ad-990a1120155d',3,'.1.3.6.1.6.3.1.1.5.3',503,'','Generic linkDown trap');
INSERT INTO snmp_trap_cfg (guid,trap_id,snmp_oid,event_code,user_tag,description)
   VALUES ('c9660f48-a4b3-41c8-b3f9-e9a6a8129db5',4,'.1.3.6.1.6.3.1.1.5.4',504,'','Generic linkUp trap');
INSERT INTO snmp_trap_cfg (guid,trap_id,snmp_oid,event_code,user_tag,description)
   VALUES ('4b422ba6-4b45-4881-931a-ed38dc798f9f',5,'.1.3.6.1.6.3.1.1.5.5',505,'','Generic authenticationFailure trap');
INSERT INTO snmp_trap_cfg (guid,trap_id,snmp_oid,event_code,user_tag,description)
   VALUES ('bd8b6971-a3e4-4cad-9c70-3a33e61e0913',6,'.1.3.6.1.6.3.1.1.5.6',506,'','Generic egpNeighborLoss trap');
INSERT INTO snmp_trap_pmap (trap_id,parameter,flags,snmp_oid,description)
   VALUES (3,1,0,'.1.3.6.1.2.1.2.2.1.1','Interface index');
INSERT INTO snmp_trap_pmap (trap_id,parameter,flags,snmp_oid,description)
   VALUES (4,1,0,'.1.3.6.1.2.1.2.2.1.1','Interface index');
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('7837580c-4054-40f2-981f-7185797fe7d7',11,'Hook::StatusPoll','/* Available global variables:' || chr(13)||chr(10) || ' *  $object - current object, one of ''NetObj'' subclasses' || chr(13)||chr(10) || ' *  $node - current object if it is ''Node'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('f7d1bc7e-4046-4ee4-adb2-718f7361984d',12,'Hook::ConfigurationPoll','/* Available global variables:' || chr(13)||chr(10) || ' *  $object - current object, one of ''NetObj'' subclasses' || chr(13)||chr(10) || ' *  $node - current object if it is ''Node'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('048fcf32-765b-4702-9c70-f012f62d5a90',13,'Hook::InstancePoll','/* Available global variables:' || chr(13)||chr(10) || ' *  $object - current object, one of ''NetObj'' subclasses' || chr(13)||chr(10) || ' *  $node - current object if it is ''Node'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('d515c10f-a5c9-4f41-afcd-9ddc8845f288',14,'Hook::TopologyPoll','/* Available global variables:' || chr(13)||chr(10) || ' *  $node - current node, object of ''Node'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('7cd1c471-2f14-4fae-8743-8899fed64d18',15,'Hook::CreateInterface','/* Available global variables:' || chr(13)||chr(10) || ' *  $node - current node, object of ''Node'' class' || chr(13)||chr(10) || ' *  $1 - current interface, object of ''Interface'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  true/false - boolean - whether interface should be created' || chr(13)||chr(10) || ' */' || chr(13)||chr(10) || 'return true;' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('befdb083-ac68-481d-a7b7-127e11c3fae0',16,'Hook::AcceptNewNode','/* Available global variables:' || chr(13)||chr(10) || ' *  $ipAddr - IP address of the node being processed' || chr(13)||chr(10) || ' *  $ipNetMask - netmask of the node being processed' || chr(13)||chr(10) || ' *  $macAddr - MAC address of the node being processed' || chr(13)||chr(10) || ' *  $zoneId - zone ID of the node being processed' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  true/false - boolean - whether node should be created' || chr(13)||chr(10) || ' */' || chr(13)||chr(10) || 'return true;' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('ee6dd107-982b-4ad1-980b-fc0cc7a03911',17,'Hook::DiscoveryPoll','/* Available global variables:' || chr(13)||chr(10) || ' *  $node - current node, object of ''Node'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('a02ea666-e1e9-4f98-a746-1c3ce19428e9',18,'Hook::PostObjectCreate','/* Available global variables:' || chr(13)||chr(10) || ' *  $object - current object, one of ''NetObj'' subclasses' || chr(13)||chr(10) || ' *  $node - current object if it is ''Node'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('4ec1a7bc-d46f-4df3-b846-e9dfd66571dc',19,'Hook::CreateSubnet','/* Available global variables:' || chr(13)||chr(10) || ' *  $node - current node, object of ''Node'' class' || chr(13)||chr(10) || ' *  $1 - current subnet, object of ''Subnet'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  true/false - boolean - whether subnet should be created' || chr(13)||chr(10) || ' */' || chr(13)||chr(10) || 'return true;' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('0517b64c-b1c3-43a1-8081-4b9dcc9433bb',20,'Hook::UpdateInterface','/* Available global variables:' || chr(13)||chr(10) || ' *  $node - current node, object of ''Node'' class' || chr(13)||chr(10) || ' *  $interface - current interface, object of ''Interface'' class' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('5648916c-ad47-45a5-8960-443a98dace46',21,'Hook::EventProcessor','/* Available global variables:' || chr(13)||chr(10) || ' *  $object - event source object, one of ''NetObj'' subclasses' || chr(13)||chr(10) || ' *  $node - event source object if it is ''Node'' class' || chr(13)||chr(10) || ' *  $event - event being processed (object of ''Event'' class)' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('818f0711-1b0e-42ec-8d28-1298d18be2e9',22,'Hook::AlarmStateChange','/* Available global variables:' || chr(13)||chr(10) || ' *  $alarm - alarm being processed (object of ''Alarm'' class)' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('9c2dba59-493b-4645-9159-2ad7a28ea611',23,'Hook::OpenUnboundTunnel','/* Available global variables:' || chr(13)||chr(10) || ' *  $tunnel - incoming tunnel information (object of ''Tunnel'' class)' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('64c90b92-27e9-4a96-98ea-d0e152d71262',24,'Hook::OpenBoundTunnel','/* Available global variables:' || chr(13)||chr(10) || ' *  $node - node this tunnel was bound to (object of ''Node'' class)' || chr(13)||chr(10) || ' *  $tunnel - incoming tunnel information (object of ''Tunnel'' class)' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  none - returned value is ignored' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('4fae91b5-8802-4f6c-aace-a03f9f7fa8ef',25,'Hook::LDAPSynchronization','/* Available global variables:' || chr(13)||chr(10) || ' *  $ldapObject - LDAP object being synchronized (object of ''LDAPObject'' class)' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  true/false - boolean - whether processing of this LDAP object should continue' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO script_library (guid,script_id,script_name,script_code)
 VALUES ('f8bfa009-d4e4-4443-8bad-3ded09bdeb92',26,'Hook::Login','/* Available global variables:' || chr(13)||chr(10) || ' *  $user - user object (object of ''User'' class)' || chr(13)||chr(10) || ' *  $session - session object (object of ''ClientSession'' class)' || chr(13)||chr(10) || ' *' || chr(13)||chr(10) || ' * Expected return value:' || chr(13)||chr(10) || ' *  true/false - boolean - whether login for this session should continue' || chr(13)||chr(10) || ' */' || chr(13)||chr(10));
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('092e4b35-4e7c-42df-b9b7-d5805bfac64e', 'Service', 'Network Objects', 'image/png', 1);
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('1ddb76a3-a05f-4a42-acda-22021768feaf', 'ATM', 'Network Objects', 'image/png', 1);
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('7cd999e9-fbe0-45c3-a695-f84523b3a50c', 'Unknown', 'Network Objects', 'image/png', 1);
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('904e7291-ee3f-41b7-8132-2bd29288ecc8', 'Node', 'Network Objects', 'image/png', 1);
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('b314cf44-b2aa-478e-b23a-73bc5bb9a624', 'HSM', 'Network Objects', 'image/png', 1);
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('ba6ab507-f62d-4b8f-824c-ca9d46f22375', 'Server', 'Network Objects', 'image/png', 1);
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('bacde727-b183-4e6c-8dca-ab024c88b999', 'Router', 'Network Objects', 'image/png', 1);
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('f5214d16-1ab1-4577-bb21-063cfd45d7af', 'Printer', 'Network Objects', 'image/png', 1);
INSERT INTO images (guid, name, category, mimetype, protected) VALUES
  ('f9105c54-8dcf-483a-b387-b4587dfd3cba', 'Switch', 'Network Objects', 'image/png', 1);
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AD','AND','020','Andorra');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AE','ARE','784','United Arab Emirates');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AF','AFG','004','Afghanistan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AG','ATG','028','Antigua and Barbuda');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AI','AIA','660','Anguilla');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AL','ALB','008','Albania');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AM','ARM','051','Armenia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AN','ANT','530','Netherlands Antilles');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AO','AGO','024','Angola');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AQ','ATA','010','Antarctica');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AR','ARG','032','Argentina');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AS','ASM','016','American Samoa');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AT','AUT','040','Austria');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AU','AUS','036','Australia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AW','ABW','533','Aruba');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AX','ALA','248','Aland Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('AZ','AZE','031','Azerbaijan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BA','BIH','070','Bosnia and Herzegovina');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BB','BRB','052','Barbados');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BD','BGD','050','Bangladesh');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BE','BEL','056','Belgium');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BF','BFA','854','Burkina Faso');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BG','BGR','100','Bulgaria');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BH','BHR','048','Bahrain');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BI','BDI','108','Burundi');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BJ','BEN','204','Benin');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BL','BLM','652','Saint-Barthelemy');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BM','BMU','060','Bermuda');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BN','BRN','096','Brunei Darussalam');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BO','BOL','068','Bolivia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BQ','BES','535','Bonaire, Sint Eustatius and Saba');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BR','BRA','076','Brazil');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BS','BHS','044','Bahamas');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BT','BTN','064','Bhutan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BV','BVT','074','Bouvet Island');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BW','BWA','072','Botswana');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BY','BLR','112','Belarus');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('BZ','BLZ','084','Belize');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CA','CAN','124','Canada');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CC','CCK','166','Cocos (Keeling) Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CD','COD','180','Congo, Democratic Republic of the');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CF','CAF','140','Central African Republic');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CG','COG','178','Congo (Brazzaville)');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CH','CHE','756','Switzerland');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CI','CIV','384','Cote d''Ivoire');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CK','COK','184','Cook Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CL','CHL','152','Chile');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CM','CMR','120','Cameroon');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CN','CHN','156','China');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CO','COL','170','Colombia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CR','CRI','188','Costa Rica');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CU','CUB','192','Cuba');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CV','CPV','132','Cape Verde');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CW','CUW','531','Curacao');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CX','CXR','162','Christmas Island');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CY','CYP','196','Cyprus');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('CZ','CZE','203','Czech Republic');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('DE','DEU','276','Germany');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('DJ','DJI','262','Djibouti');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('DK','DNK','208','Denmark');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('DM','DMA','212','Dominica');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('DO','DOM','214','Dominican Republic');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('DZ','DZA','012','Algeria');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('EC','ECU','218','Ecuador');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('EE','EST','233','Estonia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('EG','EGY','818','Egypt');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('EH','ESH','732','Western Sahara');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ER','ERI','232','Eritrea');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ES','ESP','724','Spain');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ET','ETH','231','Ethiopia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('FI','FIN','246','Finland');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('FJ','FJI','242','Fiji');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('FK','FLK','238','Falkland Islands (Malvinas)');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('FM','FSM','583','Micronesia, Federated States of');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('FO','FRO','234','Faroe Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('FR','FRA','250','France');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GA','GAB','266','Gabon');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GB','GBR','826','United Kingdom');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GD','GRD','308','Grenada');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GE','GEO','268','Georgia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GF','GUF','254','French Guiana');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GG','GGY','831','Guernsey');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GH','GHA','288','Ghana');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GI','GIB','292','Gibraltar');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GL','GRL','304','Greenland');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GM','GMB','270','Gambia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GN','GIN','324','Guinea');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GP','GLP','312','Guadeloupe');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GQ','GNQ','226','Equatorial Guinea');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GR','GRC','300','Greece');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GS','SGS','239','South Georgia and the South Sandwich Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GT','GTM','320','Guatemala');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GU','GUM','316','Guam');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GW','GNB','624','Guinea-Bissau');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('GY','GUY','328','Guyana');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('HK','HKG','344','Hong Kong, Special Administrative Region of China');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('HM','HMD','334','Heard Island and Mcdonald Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('HN','HND','340','Honduras');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('HR','HRV','191','Croatia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('HT','HTI','332','Haiti');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('HU','HUN','348','Hungary');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ID','IDN','360','Indonesia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IE','IRL','372','Ireland');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IL','ISR','376','Israel');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IM','IMN','833','Isle of Man');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IN','IND','356','India');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IO','IOT','086','British Indian Ocean Territory');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IQ','IRQ','368','Iraq');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IR','IRN','364','Iran, Islamic Republic of');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IS','ISL','352','Iceland');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('IT','ITA','380','Italy');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('JE','JEY','832','Jersey');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('JM','JAM','388','Jamaica');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('JO','JOR','400','Jordan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('JP','JPN','392','Japan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KE','KEN','404','Kenya');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KG','KGZ','417','Kyrgyzstan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KH','KHM','116','Cambodia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KI','KIR','296','Kiribati');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KM','COM','174','Comoros');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KN','KNA','659','Saint Kitts and Nevis');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KP','PRK','408','Korea, Democratic People''s Republic of');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KR','KOR','410','Korea, Republic of');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KW','KWT','414','Kuwait');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KY','CYM','136','Cayman Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('KZ','KAZ','398','Kazakhstan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LA','LAO','418','Lao PDR');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LB','LBN','422','Lebanon');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LC','LCA','662','Saint Lucia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LI','LIE','438','Liechtenstein');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LK','LKA','144','Sri Lanka');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LR','LBR','430','Liberia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LS','LSO','426','Lesotho');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LT','LTU','440','Lithuania');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LU','LUX','442','Luxembourg');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LV','LVA','428','Latvia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('LY','LBY','434','Libya');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MA','MAR','504','Morocco');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MC','MCO','492','Monaco');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MD','MDA','498','Moldova');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ME','MNE','499','Montenegro');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MF','MAF','663','Saint-Martin (French part)');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MG','MDG','450','Madagascar');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MH','MHL','584','Marshall Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MK','MKD','807','Macedonia, Republic of');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ML','MLI','466','Mali');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MM','MMR','104','Myanmar');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MN','MNG','496','Mongolia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MO','MAC','446','Macao, Special Administrative Region of China');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MP','MNP','580','Northern Mariana Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MQ','MTQ','474','Martinique');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MR','MRT','478','Mauritania');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MS','MSR','500','Montserrat');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MT','MLT','470','Malta');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MU','MUS','480','Mauritius');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MV','MDV','462','Maldives');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MW','MWI','454','Malawi');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MX','MEX','484','Mexico');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MY','MYS','458','Malaysia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('MZ','MOZ','508','Mozambique');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NA','NAM','516','Namibia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NC','NCL','540','New Caledonia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NE','NER','562','Niger');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NF','NFK','574','Norfolk Island');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NG','NGA','566','Nigeria');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NI','NIC','558','Nicaragua');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NL','NLD','528','Netherlands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NO','NOR','578','Norway');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NP','NPL','524','Nepal');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NR','NRU','520','Nauru');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NU','NIU','570','Niue');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('NZ','NZL','554','New Zealand');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('OM','OMN','512','Oman');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PA','PAN','591','Panama');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PE','PER','604','Peru');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PF','PYF','258','French Polynesia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PG','PNG','598','Papua New Guinea');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PH','PHL','608','Philippines');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PK','PAK','586','Pakistan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PL','POL','616','Poland');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PM','SPM','666','Saint Pierre and Miquelon');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PN','PCN','612','Pitcairn');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PR','PRI','630','Puerto Rico');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PS','PSE','275','Palestinian Territory, Occupied');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PT','PRT','620','Portugal');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PW','PLW','585','Palau');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('PY','PRY','600','Paraguay');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('QA','QAT','634','Qatar');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('RE','REU','638','Reunion');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('RO','ROU','642','Romania');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('RS','SRB','688','Serbia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('RU','RUS','643','Russian Federation');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('RW','RWA','646','Rwanda');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SA','SAU','682','Saudi Arabia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SB','SLB','090','Solomon Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SC','SYC','690','Seychelles');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SD','SDN','729','Sudan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SE','SWE','752','Sweden');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SG','SGP','702','Singapore');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SH','SHN','654','Saint Helena');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SI','SVN','705','Slovenia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SJ','SJM','744','Svalbard and Jan Mayen Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SK','SVK','703','Slovakia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SL','SLE','694','Sierra Leone');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SM','SMR','674','San Marino');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SN','SEN','686','Senegal');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SO','SOM','706','Somalia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SR','SUR','740','Suriname');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SS','SSD','728','South Sudan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ST','STP','678','Sao Tome and Principe');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SV','SLV','222','El Salvador');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SX','SXM','534','Sint Maarten (Dutch part)');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SY','SYR','760','Syrian Arab Republic (Syria)');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('SZ','SWZ','748','Swaziland');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TC','TCA','796','Turks and Caicos Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TD','TCD','148','Chad');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TF','ATF','260','French Southern Territories');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TG','TGO','768','Togo');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TH','THA','764','Thailand');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TJ','TJK','762','Tajikistan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TK','TKL','772','Tokelau');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TL','TLS','626','Timor-Leste');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TM','TKM','795','Turkmenistan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TN','TUN','788','Tunisia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TO','TON','776','Tonga');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TR','TUR','792','Turkey');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TT','TTO','780','Trinidad and Tobago');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TV','TUV','798','Tuvalu');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TW','TWN','158','Taiwan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('TZ','TZA','834','Tanzania');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('UA','UKR','804','Ukraine');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('UG','UGA','800','Uganda');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('UM','UMI','581','United States Minor Outlying Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('US','USA','840','United States of America');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('UY','URY','858','Uruguay');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('UZ','UZB','860','Uzbekistan');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('VA','VAT','336','Holy See (Vatican City State)');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('VC','VCT','670','Saint Vincent and Grenadines');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('VE','VEN','862','Venezuela');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('VG','VGB','092','British Virgin Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('VI','VIR','850','Virgin Islands, US');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('VN','VNM','704','Viet Nam');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('VU','VUT','548','Vanuatu');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('WF','WLF','876','Wallis and Futuna Islands');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('WS','WSM','882','Samoa');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('YE','YEM','887','Yemen');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('YT','MYT','175','Mayotte');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ZA','ZAF','710','South Africa');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ZM','ZMB','894','Zambia');
INSERT INTO country_codes (alpha_code,alpha3_code,numeric_code,name) VALUES ('ZW','ZWE','716','Zimbabwe');
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('008', 'ALL', 'Lek', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('012', 'DZD', 'Algerian Dinar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('031', 'AZM', 'Azerbaijanian Manat', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('032', 'ARS', 'Argentine Peso', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('036', 'AUD', 'Australian Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('044', 'BSD', 'Bahamian Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('048', 'BHD', 'Bahraini Dinar', 3);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('050', 'BDT', 'Taka', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('051', 'AMD', 'Armenian Dram', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('052', 'BBD', 'Barbados Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('060', 'BMD', 'Bermudian Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('064', 'BTN', 'Ngultrum', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('068', 'BOB', 'Boliviano', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('072', 'BWP', 'Pula', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('084', 'BZD', 'Belize Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('090', 'SBD', 'Solomon Islands Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('096', 'BND', 'Brunei Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('100', 'BGL', 'Lev', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('104', 'MMK', 'Kyat', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('108', 'BIF', 'Burundi Franc', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('116', 'KHR', 'Riel', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('124', 'CAD', 'Canadian Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('132', 'CVE', 'Cape Verde Escudo', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('136', 'KYD', 'Cayman Islands Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('144', 'LKR', 'Sri Lanka Rupee', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('152', 'CLP', 'Chilean Peso', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('156', 'CNY', 'Yuan Renminbi', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('170', 'COP', 'Colombian Peso', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('174', 'KMF', 'Comoro Franc', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('188', 'CRC', 'Costa Rican Colon', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('191', 'HRK', 'Croatian Kuna', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('192', 'CUP', 'Cuban Peso', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('196', 'CYP', 'Cyprus Pound', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('203', 'CZK', 'Czech Koruna', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('208', 'DKK', 'Danish Krone', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('214', 'DOP', 'Dominican Peso', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('222', 'SVC', 'El Salvador Colon', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('230', 'ETB', 'Ethiopian Birr', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('232', 'ERN', 'Nakfa', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('233', 'EEK', 'Estonian Kroon', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('238', 'FKP', 'Falkland Islands Pound', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('242', 'FJD', 'Fiji Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('262', 'DJF', 'Djibouti Franc', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('270', 'GMD', 'Dalasi', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('288', 'GHC', 'Cedi', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('292', 'GIP', 'Gibraltar Pound', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('320', 'GTQ', 'Quetzal', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('324', 'GNF', 'Guinea Franc', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('328', 'GYD', 'Guyana Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('332', 'HTG', 'Gourde', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('340', 'HNL', 'Lempira', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('344', 'HKD', 'Hong Kong Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('348', 'HUF', 'Forint', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('352', 'ISK', 'Iceland Krona', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('356', 'INR', 'Indian Rupee', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('360', 'IDR', 'Rupiah', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('364', 'IRR', 'Iranian Rial', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('368', 'IQD', 'Iraqi Dinar', 3);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('376', 'ILS', 'New Israeli Sheqel', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('388', 'JMD', 'Jamaican Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('392', 'JPY', 'Yen', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('398', 'KZT', 'Tenge', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('400', 'JOD', 'Jordanian Dinar', 3);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('404', 'KES', 'Kenyan Shilling', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('408', 'KPW', 'North Korean Won', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('410', 'KRW', 'Won', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('414', 'KWD', 'Kuwaiti Dinar', 3);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('417', 'KGS', 'Som', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('418', 'LAK', 'Kip', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('422', 'LBP', 'Lebanese Pound', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('426', 'LSL', 'Lesotho Loti', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('428', 'LVL', 'Latvian Lats', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('430', 'LRD', 'Liberian Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('434', 'LYD', 'Lybian Dinar', 3);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('440', 'LTL', 'Lithuanian Litas', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('446', 'MOP', 'Pataca', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('450', 'MGF', 'Malagasy Franc', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('454', 'MWK', 'Kwacha', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('458', 'MYR', 'Malaysian Ringgit', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('462', 'MVR', 'Rufiyaa', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('470', 'MTL', 'Maltese Lira', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('478', 'MRO', 'Ouguiya', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('480', 'MUR', 'Mauritius Rupee', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('484', 'MXN', 'Mexican Peso', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('496', 'MNT', 'Tugrik', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('498', 'MDL', 'Moldovan Leu', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('504', 'MAD', 'Moroccan Dirham', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('508', 'MZM', 'Metical', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('512', 'OMR', 'Rial Omani', 3);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('516', 'NAD', 'Namibia Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('524', 'NPR', 'Nepalese Rupee', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('532', 'ANG', 'Netherlands Antillan Guilder', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('533', 'AWG', 'Aruban Guilder', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('548', 'VUV', 'Vatu', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('554', 'NZD', 'New Zealand Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('558', 'NIO', 'Cordoba Oro', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('566', 'NGN', 'Naira', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('578', 'NOK', 'Norvegian Krone', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('586', 'PKR', 'Pakistan Rupee', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('590', 'PAB', 'Balboa', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('598', 'PGK', 'Kina', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('600', 'PYG', 'Guarani', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('604', 'PEN', 'Nuevo Sol', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('608', 'PHP', 'Philippine Peso', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('624', 'GWP', 'Guinea-Bissau Peso', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('634', 'QAR', 'Qatari Rial', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('642', 'ROL', 'Leu', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('643', 'RUB', 'Russian Ruble', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('646', 'RWF', 'Rwanda Franc', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('654', 'SHP', 'Saint Helena Pound', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('678', 'STD', 'Dobra', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('682', 'SAR', 'Saudi Riyal', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('690', 'SCR', 'Seychelles Rupee', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('694', 'SLL', 'Leone', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('702', 'SGD', 'Singapore Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('703', 'SKK', 'Slovak Koruna', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('704', 'VND', 'Dong', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('706', 'SOS', 'Somali Shilling', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('710', 'ZAR', 'Rand', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('716', 'ZWD', 'Zimbabwe Dollar', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('728', 'SSP', 'South Sudanese pound', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('740', 'SRG', 'Suriname Guilder', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('748', 'SZL', 'Lilangeni', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('752', 'SEK', 'Swedish Krona', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('756', 'CHF', 'Swiss Franc', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('760', 'SYP', 'Syrian Pound', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('764', 'THB', 'Baht', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('776', 'TOP', 'Paanga', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('780', 'TTD', 'Trinidad and Tobago Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('784', 'AED', 'UAE Dirham', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('788', 'TND', 'Tunisian Dinar', 3);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('795', 'TMM', 'Manat', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('800', 'UGX', 'Uganda Shilling', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('807', 'MKD', 'Denar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('810', 'RUR', 'Russian Ruble', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('818', 'EGP', 'Egyptian Pound', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('826', 'GBP', 'Pound Sterling', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('834', 'TZS', 'Tanzanian Shilling', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('840', 'USD', 'US Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('858', 'UYU', 'Peso Uruguayo', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('860', 'UZS', 'Uzbekistan Sum', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('862', 'VEB', 'Bolivar', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('882', 'WST', 'Tala', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('886', 'YER', 'Yemeni Rial', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('891', 'CSD', 'Serbian Dinar', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('894', 'ZMK', 'Kwacha', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('901', 'TWD', 'New Taiwan Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('933', 'BYN', 'Belarussian New Ruble', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('934', 'TMT', 'Turkmenistani Manat', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('937', 'VEF', 'Venezuelan Bolivar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('938', 'SDG', 'Sudanese Pound', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('941', 'RSD', 'Serbian Dinar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('943', 'MZN', 'Mozambican Metical', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('944', 'AZN', 'Azerbaijani Manat', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('946', 'RON', 'New Romanian Leu', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('949', 'TRY', 'New Turkish Lira', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('950', 'XAF', 'CFA Franc BEAC', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('951', 'XCD', 'East Carribbean Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('952', 'XOF', 'CFA Franc BCEAO', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('953', 'XPF', 'CFP Franc', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('967', 'ZMW', 'Zambian Kwacha', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('968', 'SRD', 'Surinamese Dollar', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('969', 'MGA', 'Malagasy Ariary', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('971', 'AFN', 'Afghani', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('972', 'TJS', 'Somoni', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('973', 'AOA', 'Kwanza', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('974', 'BYR', 'Belarussian Ruble', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('975', 'BGN', 'Bulgarian Lev', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('976', 'CDF', 'Franc Congolais', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('977', 'BAM', 'Convertible Marks', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('978', 'EUR', 'Euro', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('979', 'MXV', 'Mexican Unidad de Inversion (UDI)', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('980', 'UAH', 'Hryvnia', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('981', 'GEL', 'Lari', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('984', 'BOV', 'Mvdol', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('985', 'PLN', 'Zloty', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('986', 'BRL', 'Brazilian Real', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('990', 'CLF', 'Unidades de Fomento', 0);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('997', 'USN', 'US dollar (next day funds code)', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('998', 'USS', 'US dollar (same day funds code)', 2);
INSERT INTO currency_codes (numeric_code, alpha_code, description, exponent) VALUES ('999', 'XXX', 'No currency', 0);
INSERT INTO port_layouts (device_oid,numbering_scheme,row_count) VALUES ('.1.3.6.1','4','2');
COMMIT TRANSACTION;
