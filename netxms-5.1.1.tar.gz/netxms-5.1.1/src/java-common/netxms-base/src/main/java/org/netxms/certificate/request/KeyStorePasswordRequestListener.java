package org.netxms.certificate.request;

public interface KeyStorePasswordRequestListener
{
   String keyStorePasswordRequested();
}
