package org.netxms.certificate.request;

public interface KeyStoreLocationRequestListener
{
   String keyStoreLocationRequested();
}
