package org.netxms.client.datacollection;

public interface LocalChangeListener
{
   public void onObjectChange();
}
