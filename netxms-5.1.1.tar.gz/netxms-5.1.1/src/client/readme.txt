Source tree layout for client components:

nxalarm		Command line tool for managing alarms
nxevent		Command line tool for sending events to server
nxpush		Command line tool for pushing DCI data
nxshell		Python-based scripting client
nxnotify		Command line tool for sending notifications via server
