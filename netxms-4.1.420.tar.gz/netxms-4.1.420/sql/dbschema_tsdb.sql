CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;
BEGIN TRANSACTION;
CREATE TABLE metadata
(
  var_name varchar(63) not null,
  var_value varchar(255) not null,
  PRIMARY KEY(var_name)
) ;
CREATE TABLE config
(
  var_name varchar(63) not null,
  var_value varchar(2000) null,
  default_value varchar(2000) null,
  is_visible integer not null default 1,
  need_server_restart integer not null default 0,
  data_type char(1) not null default 'S',
  is_public char(1) not null default 'N',
  description varchar(450) null,
  possible_values text null,
  units varchar(36),
  PRIMARY KEY(var_name)
) ;
CREATE TABLE config_clob
(
  var_name varchar(63) not null,
  var_value text null,
  PRIMARY KEY(var_name)
) ;
CREATE TABLE config_values
(
 var_name varchar(63) not null,
 var_value varchar(15) not null,
 var_description varchar(255) null,
 PRIMARY KEY(var_name,var_value)
) ;
CREATE TABLE users
(
  id integer not null,
  guid varchar(36) not null,
  name varchar(63) not null,
  password varchar(127) not null,
  system_access bigint not null,
  flags integer not null,
  full_name varchar(127) null,
  description varchar(255) null,
  grace_logins integer not null,
  auth_method integer not null,
  cert_mapping_method integer not null,
  cert_mapping_data text null,
  auth_failures integer not null,
  last_passwd_change integer not null,
  min_passwd_length integer not null,
  disabled_until integer not null,
  last_login integer not null,
  password_history text null,
  email varchar(127) null,
  phone_number varchar(63) null,
  ldap_dn text null,
  ldap_unique_id varchar(64) null,
  created integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE user_groups
(
  id integer not null,
  guid varchar(36) not null,
  name varchar(63) not null,
  system_access bigint not null,
  flags integer not null,
  description varchar(255),
  ldap_dn text null,
  ldap_unique_id varchar(64) null,
  created integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE user_group_members
(
  group_id integer not null,
  user_id integer not null,
  PRIMARY KEY(group_id,user_id)
) ;
CREATE TABLE user_profiles
(
  user_id integer not null,
  var_name varchar(63) not null,
  var_value text not null,
  PRIMARY KEY(user_id,var_name)
) ;
CREATE TABLE userdb_custom_attributes
(
  object_id integer not null,
  attr_name varchar(127) not null,
  attr_value text not null,
  PRIMARY KEY(object_id,attr_name)
) ;
CREATE TABLE object_properties
(
  object_id integer not null,
  guid varchar(36) not null,
  name varchar(63) not null,
  alias varchar(255) null,
  flags integer not null,
  state integer not null,
  status integer not null,
  is_deleted integer not null,
  is_system integer not null,
  last_modified integer not null,
  inherit_access_rights integer not null,
  status_calc_alg integer not null,
  status_prop_alg integer not null,
  status_fixed_val integer not null,
  status_shift integer not null,
  status_translation varchar(8) not null,
  status_single_threshold integer not null,
  status_thresholds varchar(8) not null,
  comments text null,
  comments_source text null,
  location_type integer not null,
  latitude varchar(20),
  longitude varchar(20),
  location_accuracy integer not null,
  location_timestamp integer not null,
  map_image varchar(36) not null,
  submap_id integer not null,
  name_on_map varchar(63) null,
  country varchar(63) null,
  region varchar(63) null,
  city varchar(63) null,
  district varchar(63) null,
  street_address varchar(255) null,
  postcode varchar(31) null,
  state_before_maint integer not null,
  maint_event_id bigint not null,
  maint_initiator integer not null,
  creation_time integer not null,
  category integer not null,
  PRIMARY KEY(object_id)
) ;
CREATE TABLE object_categories
(
  id integer not null,
  name varchar(63) not null,
  icon varchar(36) null,
  map_image varchar(36) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE object_urls
(
  object_id integer not null,
  url_id integer not null,
  url varchar(2000) null,
  description varchar(2000) null,
  PRIMARY KEY(object_id,url_id)
) ;
CREATE TABLE object_custom_attributes
(
  object_id integer not null,
  attr_name varchar(127) not null,
  attr_value text null,
  flags integer not null,
  PRIMARY KEY(object_id,attr_name)
) ;
CREATE INDEX idx_ocattr_oid ON object_custom_attributes(object_id);
CREATE TABLE zones
(
  id integer not null,
  zone_guid integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE zone_proxies
(
  object_id integer not null,
  proxy_node integer not null,
  PRIMARY KEY(object_id,proxy_node)
) ;
CREATE TABLE mobile_devices
(
  id integer not null,
  device_id varchar(64) not null,
  vendor varchar(64) null,
  model varchar(128) null,
  serial_number varchar(64) null,
  os_name varchar(32) null,
  os_version varchar(64) null,
  user_id varchar(64) null,
  battery_level integer not null,
  comm_protocol varchar(31) null,
  speed varchar(20) not null,
  direction integer not null,
  altitude integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE access_points
(
  id integer not null,
  node_id integer not null,
  mac_address varchar(12) null,
  vendor varchar(64) null,
  model varchar(128) null,
  serial_number varchar(64) null,
  ap_state integer not null,
  ap_index integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE racks
(
  id integer not null,
  height integer not null,
  top_bottom_num char(1) not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE rack_passive_elements
(
  id integer not null,
  rack_id integer not null,
  name varchar(255) null,
  type integer not null,
  position integer not null,
  orientation integer not null,
  port_count integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE physical_links
(
  id integer not null,
  description varchar(255) null,
  left_object_id integer not null,
  left_patch_pannel_id integer not null,
  left_port_number integer not null,
  left_front char(1) not null,
  right_object_id integer not null,
  right_patch_pannel_id integer not null,
  right_port_number integer not null,
  right_front char(1) not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE chassis
(
  id integer not null,
  controller_id integer not null,
  rack_id integer not null,
  rack_image_front varchar(36) null,
  rack_image_rear varchar(36) null,
  rack_position integer not null,
  rack_height integer not null,
  rack_orientation integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE nodes
(
  id integer not null,
  primary_name varchar(255) null,
  primary_ip varchar(48) not null,
  tunnel_id varchar(36) null,
  agent_cert_subject varchar(500) null,
  agent_cert_mapping_method char(1) null,
  agent_cert_mapping_data varchar(500) null,
  snmp_version integer not null,
  snmp_port integer not null,
  community varchar(127) null,
  usm_auth_password varchar(127) null,
  usm_priv_password varchar(127) null,
  usm_methods integer not null,
  snmp_oid varchar(255) null,
  snmp_engine_id varchar(255) null,
  secret varchar(88) null,
  agent_port integer not null,
  agent_version varchar(63) null,
  agent_id varchar(36) null,
  hardware_id varchar(40) null,
  platform_name varchar(63) null,
  poller_node_id integer not null,
  zone_guid integer not null,
  proxy_node integer not null,
  snmp_proxy integer not null,
  eip_proxy integer not null,
  icmp_proxy integer not null,
  required_polls integer not null,
  uname varchar(255) null,
  use_ifxtable integer not null,
  snmp_sys_name varchar(127) null,
  snmp_sys_contact varchar(127) null,
  snmp_sys_location varchar(255) null,
  bridge_base_addr varchar(15) null,
  lldp_id varchar(255) null,
  down_since integer not null,
  boot_time integer not null,
  driver_name varchar(32) null,
  physical_container_id integer not null,
  rack_image_front varchar(36) null,
  rack_image_rear varchar(36) null,
  rack_position integer not null,
  rack_height integer not null,
  rack_orientation integer not null,
  agent_cache_mode char(1) not null,
  last_agent_comm_time integer not null,
  syslog_msg_count bigint not null,
  snmp_trap_count bigint not null,
  node_type integer not null,
  node_subtype varchar(127) null,
  hypervisor_type varchar(31) null,
  hypervisor_info varchar(255) null,
  ssh_login varchar(63) null,
  ssh_password varchar(63) null,
  ssh_port integer not null,
  ssh_key_id integer not null,
  ssh_proxy integer not null,
  port_rows integer not null,
  port_numbering_scheme integer not null,
  agent_comp_mode char(1) not null,
  capabilities integer null,
  fail_time_snmp integer not null,
  fail_time_agent integer not null,
  fail_time_ssh integer not null,
  icmp_poll_mode char(1) not null,
  chassis_placement_config varchar(2000) null,
  vendor varchar(127) null,
  product_name varchar(127) null,
  product_version varchar(15) null,
  product_code varchar(31) null,
  serial_number varchar(31) null,
  eip_port integer not null,
  cip_device_type integer not null,
  cip_status integer not null,
  cip_state integer not null,
  cip_vendor_code integer not null,
  syslog_codepage varchar(15) null,
  snmp_codepage varchar(15) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE icmp_target_address_list
(
  node_id integer not null,
  ip_addr varchar(48) not null,
  PRIMARY KEY(node_id,ip_addr)
) ;
CREATE TABLE software_inventory
(
  node_id integer not null,
  name varchar(127) not null,
  version varchar(63) not null,
  vendor varchar(63) null,
  install_date integer not null,
  url varchar(255) null,
  description varchar(255) null,
  PRIMARY KEY(node_id,name,version)
) ;
CREATE TABLE hardware_inventory
(
  node_id integer not null,
  category integer not null,
  component_index integer not null,
  hw_type varchar(47) null,
  vendor varchar(127) null,
  model varchar(127) null,
  location varchar(63) null,
  capacity bigint null,
  part_number varchar(63) null,
  serial_number varchar(63) null,
  description varchar(255) null,
  PRIMARY KEY(node_id,category,component_index)
) ;
CREATE TABLE node_components
(
  node_id integer not null,
  component_index integer not null,
  parent_index integer not null,
  position integer not null,
  component_class integer not null,
  if_index integer not null,
  name varchar(255) null,
  description varchar(255) null,
  model varchar(255) null,
  serial_number varchar(63) null,
  vendor varchar(63) null,
  firmware varchar(127) null,
  PRIMARY KEY(node_id,component_index)
) ;
CREATE TABLE clusters
(
  id integer not null,
  cluster_type integer not null,
  zone_guid integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE cluster_members
(
  cluster_id integer not null,
  node_id integer not null,
  PRIMARY KEY(cluster_id,node_id)
) ;
CREATE TABLE cluster_sync_subnets
(
  cluster_id integer not null,
  subnet_addr varchar(48) not null,
  subnet_mask integer not null,
  PRIMARY KEY(cluster_id,subnet_addr)
) ;
CREATE TABLE cluster_resources
(
  cluster_id integer not null,
  resource_id integer not null,
  resource_name varchar(255),
  ip_addr varchar(48) not null,
  current_owner integer not null,
  PRIMARY KEY(cluster_id,resource_id)
) ;
CREATE TABLE subnets
(
  id integer not null,
  ip_addr varchar(48) not null,
  ip_netmask integer not null,
  zone_guid integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE interfaces
(
  id integer not null,
  node_id integer not null,
  parent_iface integer not null,
  if_type integer not null,
  if_index integer not null,
  mtu integer not null,
  speed bigint not null,
  bridge_port integer not null,
  phy_chassis integer not null,
  phy_module integer not null,
  phy_pic integer not null,
  phy_port integer not null,
  peer_node_id integer not null,
  peer_if_id integer not null,
  peer_proto integer not null,
  mac_addr varchar(12) not null,
  required_polls integer not null,
  admin_state integer not null,
  oper_state integer not null,
  dot1x_pae_state integer not null,
  dot1x_backend_state integer not null,
  description varchar(255) null,
  if_alias varchar(255) null,
  iftable_suffix varchar(127) null,
  last_known_oper_state integer not null,
  last_known_admin_state integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE interface_vlan_list
(
  iface_id integer not null,
  vlan_id integer not null,
  PRIMARY KEY(iface_id,vlan_id)
) ;
CREATE TABLE interface_address_list
(
  iface_id integer not null,
  ip_addr varchar(48) not null,
  ip_netmask integer not null,
  PRIMARY KEY(iface_id,ip_addr)
) ;
CREATE TABLE network_services
(
  id integer not null,
  node_id integer not null,
  service_type integer not null,
  ip_bind_addr varchar(48) not null,
  ip_proto integer not null,
  ip_port integer not null,
  check_request text null,
  check_response text null,
  poller_node_id integer not null,
  required_polls integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE vpn_connectors
(
  id integer not null,
  node_id integer not null,
  peer_gateway integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE vpn_connector_networks
(
  vpn_id integer not null,
  network_type integer not null,
  ip_addr varchar(48) not null,
  ip_netmask integer not null,
  PRIMARY KEY(vpn_id,ip_addr)
) ;
CREATE TABLE object_containers
(
  id integer not null,
  object_class integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE conditions
(
  id integer not null,
  activation_event integer not null,
  deactivation_event integer not null,
  source_object integer not null,
  active_status integer not null,
  inactive_status integer not null,
  script text not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE cond_dci_map
(
  condition_id integer not null,
  sequence_number integer not null,
  dci_id integer not null,
  node_id integer not null,
  dci_func integer not null,
  num_polls integer not null,
  PRIMARY KEY(condition_id,sequence_number)
) ;
CREATE TABLE templates
(
  id integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE dct_node_map
(
  template_id integer not null,
  node_id integer not null,
  PRIMARY KEY(template_id,node_id)
) ;
CREATE TABLE nsmap
(
  subnet_id integer not null,
  node_id integer not null,
  PRIMARY KEY(subnet_id,node_id)
) ;
CREATE TABLE container_members
(
  container_id integer not null,
  object_id integer not null,
  PRIMARY KEY(container_id,object_id)
) ;
CREATE TABLE icmp_statistics
(
   object_id integer not null,
   poll_target varchar(63) not null,
   min_response_time integer not null,
   max_response_time integer not null,
   avg_response_time integer not null,
   last_response_time integer not null,
   sample_count integer not null,
   raw_response_times text null,
   PRIMARY KEY(object_id,poll_target)
) ;
CREATE TABLE acl
(
  object_id integer not null,
  user_id integer not null,
  access_rights integer not null,
  PRIMARY KEY(object_id,user_id)
) ;
CREATE TABLE trusted_nodes
(
  source_object_id integer not null,
  target_node_id integer not null,
  PRIMARY KEY(source_object_id,target_node_id)
) ;
CREATE TABLE items
(
  item_id integer not null,
  node_id integer not null,
  template_id integer not null,
  template_item_id integer not null,
  guid varchar(36) not null,
  name varchar(1023) null,
  description varchar(255) null,
  flags integer not null,
  state_flags integer not null,
  source integer not null,
  snmp_port integer not null,
  snmp_version integer not null,
  datatype integer not null,
  polling_schedule_type char(1) not null,
  polling_interval integer not null,
  polling_interval_src varchar(255) null,
  retention_type char(1) not null,
  retention_time integer not null,
  retention_time_src varchar(255) null,
  status integer not null,
  snmp_raw_value_type integer not null,
  delta_calculation integer not null,
  transformation text,
  instance varchar(1023) null,
  system_tag varchar(255) null,
  resource_id integer not null,
  proxy_node integer not null,
  base_units integer not null,
  unit_multiplier integer not null,
  custom_units_name varchar(63) null,
  perftab_settings text null,
  instd_method integer not null,
  instd_data varchar(1023) null,
  instd_filter text null,
  samples integer not null,
  npe_name varchar(15) null,
  comments text null,
  instance_retention_time integer not null,
  grace_period_start integer not null,
  related_object integer not null,
  PRIMARY KEY(item_id)
) ;
CREATE INDEX idx_items_node_id ON items(node_id);
CREATE TABLE thresholds
(
  threshold_id integer not null,
  item_id integer not null,
  sequence_number integer not null,
  fire_value varchar(255) null,
  rearm_value varchar(255) null,
  last_checked_value varchar(255) null,
  check_function integer not null,
  check_operation integer not null,
  sample_count integer not null,
  script text null,
  event_code integer not null,
  rearm_event_code integer not null,
  repeat_interval integer not null,
  current_state integer not null,
  current_severity integer not null,
  match_count integer not null,
  last_event_timestamp integer not null,
  state_before_maint char(1) not null,
  PRIMARY KEY(threshold_id)
) ;
CREATE INDEX idx_thresholds_item_id ON thresholds(item_id);
CREATE INDEX idx_thresholds_sequence ON thresholds(sequence_number);
CREATE TABLE dc_tables
(
  item_id integer not null,
  node_id integer not null,
  template_id integer not null,
  template_item_id integer not null,
  guid varchar(36) not null,
  name varchar(1023) null,
  description varchar(255) null,
  flags integer not null,
  state_flags integer not null,
  source integer not null,
  snmp_port integer not null,
  snmp_version integer not null,
  polling_schedule_type char(1) not null,
  polling_interval integer not null,
  polling_interval_src varchar(255) null,
  retention_type char(1) not null,
  retention_time integer not null,
  retention_time_src varchar(255) null,
  status integer not null,
  system_tag varchar(255) null,
  resource_id integer not null,
  proxy_node integer not null,
  perftab_settings text null,
  transformation_script text null,
  comments text null,
  instance varchar(1023) null,
  instd_method integer not null,
  instd_data varchar(1023) null,
  instd_filter text null,
  instance_retention_time integer not null,
  grace_period_start integer not null,
  related_object integer not null,
  PRIMARY KEY(item_id)
) ;
CREATE INDEX idx_dc_tables_node_id ON dc_tables(node_id);
CREATE TABLE dc_table_columns
(
  table_id integer not null,
  sequence_number integer not null,
  column_name varchar(63) not null,
  snmp_oid varchar(1023) null,
  flags integer not null,
  display_name varchar(255) null,
  PRIMARY KEY(table_id,column_name)
) ;
CREATE TABLE dct_column_names
(
  column_id integer not null,
  column_name varchar(63) not null,
  PRIMARY KEY(column_id)
) ;
CREATE TABLE dct_thresholds
(
  id integer not null,
  table_id integer not null,
  sequence_number integer not null,
  activation_event integer not null,
  deactivation_event integer not null,
  sample_count integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE dct_threshold_conditions
(
  threshold_id integer not null,
  group_id integer not null,
  sequence_number integer not null,
  column_name varchar(63) null,
  check_operation integer not null,
  check_value varchar(255) null,
  PRIMARY KEY(threshold_id,group_id,sequence_number)
) ;
CREATE TABLE dct_threshold_instances
(
  threshold_id integer not null,
  instance_id integer not null,
  instance varchar(255) not null,
  match_count integer not null,
  is_active char(1) not null,
  tt_row_number integer not null,
  maint_copy char(1) not null,
  PRIMARY KEY(threshold_id,instance_id)
) ;
CREATE TABLE dci_schedules
(
  item_id integer not null,
  schedule_id integer not null,
  schedule varchar(255) null,
  PRIMARY KEY(item_id,schedule_id)
) ;
CREATE TABLE raw_dci_values
(
  item_id integer not null,
  raw_value varchar(255) null,
  transformed_value varchar(255) null,
  last_poll_time integer not null,
  cache_timestamp integer not null,
  PRIMARY KEY(item_id)
) ;
CREATE TABLE dci_access
(
   dci_id integer not null,
   user_id integer not null,
   PRIMARY KEY(dci_id,user_id)
) ;
CREATE TABLE idata_sc_default
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_7
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_30
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_90
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_180
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
CREATE TABLE idata_sc_other
(
   item_id integer not null,
   idata_timestamp timestamptz not null,
   idata_value varchar(255) null,
   raw_value varchar(255) null,
   PRIMARY KEY(item_id,idata_timestamp)
) ;
SELECT create_hypertable('idata_sc_default', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_7', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_30', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_90', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_180', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('idata_sc_other', 'idata_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE VIEW idata AS
   SELECT * FROM idata_sc_default
   UNION ALL
   SELECT * FROM idata_sc_7
   UNION ALL
   SELECT * FROM idata_sc_30
   UNION ALL
   SELECT * FROM idata_sc_90
   UNION ALL
   SELECT * FROM idata_sc_180
   UNION ALL
   SELECT * FROM idata_sc_other;
CREATE TABLE tdata_sc_default
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_7
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_30
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_90
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_180
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
CREATE TABLE tdata_sc_other
(
   item_id integer not null,
   tdata_timestamp timestamptz not null,
   tdata_value text null,
   PRIMARY KEY(item_id,tdata_timestamp)
) ;
SELECT create_hypertable('tdata_sc_default', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_7', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_30', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_90', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_180', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
SELECT create_hypertable('tdata_sc_other', 'tdata_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE VIEW tdata AS
   SELECT * FROM tdata_sc_default
   UNION ALL
   SELECT * FROM tdata_sc_7
   UNION ALL
   SELECT * FROM tdata_sc_30
   UNION ALL
   SELECT * FROM tdata_sc_90
   UNION ALL
   SELECT * FROM tdata_sc_180
   UNION ALL
   SELECT * FROM tdata_sc_other;
CREATE TABLE event_cfg
(
  event_code integer not null,
  event_name varchar(63) not null,
  guid varchar(36) not null,
  severity integer not null,
  flags integer not null,
  message varchar(2000) null,
  description text null,
  tags varchar(2000) null,
  PRIMARY KEY(event_code)
) ;
CREATE TABLE event_log
(
  event_id bigint not null,
  event_code integer not null,
  event_timestamp timestamptz not null,
  origin integer not null,
  origin_timestamp integer not null,
  event_source integer not null,
  zone_uin integer not null,
  dci_id integer not null,
  event_severity integer not null,
  event_message varchar(2000) null,
  event_tags varchar(2000) null,
  root_event_id bigint not null,
  raw_data text null,
  PRIMARY KEY(event_id,event_timestamp)
) ;
CREATE INDEX idx_event_log_event_timestamp ON event_log(event_timestamp);
CREATE INDEX idx_event_log_source ON event_log(event_source);
CREATE INDEX idx_event_log_root_id ON event_log(root_event_id) WHERE root_event_id > 0;
SELECT create_hypertable('event_log', 'event_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE notification_log
(
  id bigint not null,
  notification_timestamp timestamptz not null,
  notification_channel varchar(63) not null,
  recipient varchar(2000) null,
  subject varchar(2000) null,
  message varchar(2000) null,
  success char(1) not null,
  PRIMARY KEY(id,notification_timestamp)
) ;
CREATE INDEX idx_notification_log_timestamp ON notification_log(notification_timestamp);
SELECT create_hypertable('notification_log', 'notification_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE server_action_execution_log
(
  id bigint not null,
  action_timestamp timestamptz not null,
  action_id integer not null,
  action_name varchar(63) null,
  channel_name varchar(63) null,
  recipient varchar(2000) null,
  subject varchar(2000) null,
  action_data varchar(2000) null,
  event_id bigint not null,
  event_code integer not null,
  success char(1) not null,
  PRIMARY KEY(id,action_timestamp)
) ;
CREATE INDEX idx_srv_action_log_timestamp ON server_action_execution_log(action_timestamp);
SELECT create_hypertable('server_action_execution_log', 'action_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE actions
(
  action_id integer not null,
  guid varchar(36) not null,
  action_name varchar(63) not null,
  action_type integer not null,
  is_disabled integer not null,
  rcpt_addr varchar(255) null,
  email_subject varchar(255) null,
  action_data text null,
  channel_name varchar(63) null,
  PRIMARY KEY(action_id)
) ;
CREATE TABLE event_policy
(
  rule_id integer not null,
  rule_guid varchar(36) not null,
  flags integer not null,
  comments text null,
  script text null,
  alarm_message varchar(2000) null,
  alarm_impact varchar(1000) null,
  alarm_severity integer not null,
  alarm_key varchar(255) null,
  alarm_timeout integer not null,
  alarm_timeout_event integer not null,
  rca_script_name varchar(255) null,
  PRIMARY KEY(rule_id)
) ;
CREATE TABLE policy_source_list
(
  rule_id integer not null,
  object_id integer not null,
  PRIMARY KEY(rule_id,object_id)
) ;
CREATE TABLE policy_event_list
(
  rule_id integer not null,
  event_code integer not null,
  PRIMARY KEY(rule_id,event_code)
) ;
CREATE TABLE policy_action_list
(
  rule_id integer not null,
  action_id integer not null,
  timer_delay varchar(127) null,
  timer_key varchar(127) null,
  blocking_timer_key varchar(127) null,
  snooze_time varchar(127) null,
  PRIMARY KEY(rule_id,action_id)
) ;
CREATE TABLE policy_timer_cancellation_list
(
  rule_id integer not null,
  timer_key varchar(127) not null,
  PRIMARY KEY(rule_id,timer_key)
) ;
CREATE TABLE policy_pstorage_actions
(
  rule_id integer not null,
  ps_key varchar(127) not null,
  action integer not null,
  value varchar(2000) null,
  PRIMARY KEY(rule_id,ps_key,action)
) ;
CREATE TABLE alarms
(
  alarm_id integer not null,
  parent_alarm_id integer not null,
  alarm_state integer not null,
  hd_state integer not null,
  hd_ref varchar(63) null,
  creation_time integer not null,
  last_change_time integer not null,
  last_state_change_time integer not null,
  rule_guid varchar(36) null,
  rule_description varchar(255) null,
  source_object_id integer not null,
  zone_uin integer not null,
  source_event_code integer not null,
  source_event_id bigint not null,
  dci_id integer not null,
  message varchar(2000) null,
  original_severity integer not null,
  current_severity integer not null,
  repeat_count integer not null,
  alarm_key varchar(255) null,
  ack_by integer not null,
  resolved_by integer not null,
  term_by integer not null,
  timeout integer not null,
  timeout_event integer not null,
  ack_timeout integer not null,
  alarm_category_ids varchar(255) null,
  event_tags varchar(2000) null,
  rca_script_name varchar(255) null,
  impact varchar(1000) null,
  PRIMARY KEY(alarm_id)
) ;
CREATE INDEX idx_alarms_source_object_id ON alarms(source_object_id);
CREATE INDEX idx_alarms_last_change_time ON alarms(last_change_time);
CREATE TABLE alarm_notes
(
  note_id integer not null,
  alarm_id integer not null,
  change_time integer not null,
  user_id integer not null,
  note_text text null,
  PRIMARY KEY(note_id)
) ;
CREATE INDEX idx_alarm_notes_alarm_id ON alarm_notes(alarm_id);
CREATE TABLE alarm_events
(
  alarm_id integer not null,
  event_id bigint not null,
  event_code integer not null,
  event_name varchar(63) null,
  severity integer not null,
  source_object_id integer not null,
  event_timestamp integer not null,
  message varchar(2000) null,
  PRIMARY KEY(alarm_id,event_id)
) ;
CREATE INDEX idx_alarm_events_alarm_id ON alarm_events(alarm_id);
CREATE TABLE alarm_categories
(
  id integer not null,
  name varchar(63) null,
  descr varchar(255) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE alarm_category_acl
(
  category_id integer not null,
  user_id integer not null,
  PRIMARY KEY(category_id,user_id)
) ;
CREATE TABLE alarm_category_map
(
  alarm_id integer not null,
  category_id integer not null,
  PRIMARY KEY(alarm_id,category_id)
) ;
CREATE TABLE alarm_state_changes
(
   record_id bigint not null,
   alarm_id integer not null,
   prev_state integer not null,
   new_state integer not null,
   change_time integer not null,
   prev_state_duration integer not null,
   change_by integer not null,
   PRIMARY KEY(record_id)
) ;
CREATE INDEX idx_alarm_state_changes_by_id ON alarm_state_changes(alarm_id);
CREATE TABLE snmp_trap_cfg
(
  guid varchar(36) not null,
  trap_id integer not null,
  snmp_oid varchar(255),
  event_code integer not null,
  user_tag varchar(63),
  description varchar(255),
  transformation_script text null,
  PRIMARY KEY(trap_id)
) ;
CREATE TABLE snmp_trap_pmap
(
  trap_id integer not null,
  parameter integer not null,
  flags integer not null,
  snmp_oid varchar(255) null,
  description varchar(255) null,
  PRIMARY KEY(trap_id,parameter)
) ;
CREATE TABLE agent_pkg
(
  pkg_id integer not null,
  pkg_type varchar(15) null,
  pkg_name varchar(63) not null,
  version varchar(31) null,
  platform varchar(63) null,
  pkg_file varchar(255) null,
  description varchar(255) null,
  command varchar(255) null,
  PRIMARY KEY(pkg_id)
) ;
CREATE TABLE object_tools
(
  tool_id integer not null,
  guid varchar(36) not null,
  tool_name varchar(255) null,
  tool_type integer not null,
  tool_data text null,
  description varchar(255) null,
  flags integer not null,
  tool_filter text null,
  confirmation_text varchar(255) null,
  command_name varchar(255) null,
  command_short_name varchar(31) null,
  icon text null,
  PRIMARY KEY(tool_id)
) ;
CREATE TABLE object_tools_acl
(
  tool_id integer not null,
  user_id integer not null,
  PRIMARY KEY(tool_id,user_id)
) ;
CREATE TABLE object_tools_table_columns
(
  tool_id integer not null,
  col_number integer not null,
  col_name varchar(255) null,
  col_oid varchar(255) null,
  col_format integer,
  col_substr integer,
  PRIMARY KEY(tool_id,col_number)
) ;
CREATE TABLE input_fields
(
  category char(1) not null,
  owner_id integer not null,
  name varchar(31) not null,
  input_type char(1) not null,
  display_name varchar(127) null,
  sequence_num integer not null,
  flags integer not null,
  PRIMARY KEY(category,owner_id,name)
) ;
CREATE TABLE syslog
(
  msg_id bigint not null,
  msg_timestamp timestamptz not null,
  facility integer not null,
  severity integer not null,
  source_object_id integer not null,
  zone_uin integer not null,
  hostname varchar(127) null,
  msg_tag varchar(32) null,
  msg_text text null,
  PRIMARY KEY(msg_id,msg_timestamp)
) ;
CREATE INDEX idx_syslog_msg_timestamp ON syslog(msg_timestamp);
CREATE INDEX idx_syslog_source ON syslog(source_object_id);
SELECT create_hypertable('syslog', 'msg_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE script_library
(
  guid varchar(36) not null,
  script_id integer not null,
  script_name varchar(255) not null,
  script_code text null,
  PRIMARY KEY(script_id)
) ;
CREATE TABLE snmp_trap_log
(
  trap_id bigint not null,
  trap_timestamp timestamptz not null,
  ip_addr varchar(48) not null,
  object_id integer not null,
  zone_uin integer not null,
  trap_oid varchar(255) not null,
  trap_varlist text null,
  PRIMARY KEY(trap_id,trap_timestamp)
) ;
CREATE INDEX idx_snmp_trap_log_tt ON snmp_trap_log(trap_timestamp);
CREATE INDEX idx_snmp_trap_log_oid ON snmp_trap_log(object_id);
SELECT create_hypertable('snmp_trap_log', 'trap_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE agent_configs
(
  config_id integer not null,
  config_name varchar(255) not null,
  config_file text not null,
  config_filter text not null,
  sequence_number integer not null,
  PRIMARY KEY(config_id)
) ;
CREATE TABLE address_lists
(
  list_type integer not null,
  community_id integer not null,
  zone_uin integer not null,
  proxy_id integer not null,
  addr_type integer not null,
  addr1 varchar(48) not null,
  addr2 varchar(48) not null,
  comments varchar(255) null,
  PRIMARY KEY(list_type,community_id,zone_uin,addr_type,addr1,addr2)
) ;
CREATE INDEX idx_address_lists_list_type ON address_lists(list_type);
CREATE TABLE graphs
(
  graph_id integer not null,
  owner_id integer not null,
  flags integer not null,
  name varchar(255) not null,
  config text null,
  filters text null,
  PRIMARY KEY(graph_id)
) ;
CREATE TABLE graph_acl
(
  graph_id integer not null,
  user_id integer not null,
  user_rights integer not null,
  PRIMARY KEY(graph_id,user_id)
) ;
CREATE TABLE certificate_action_log
(
  record_id integer not null,
  timestamp integer not null,
  operation integer not null,
  user_id integer not null,
  node_id integer not null,
  node_guid varchar(36) null,
  cert_type integer not null,
  subject varchar(255) null,
  serial integer null,
  PRIMARY KEY(record_id)
) ;
CREATE TABLE audit_log
(
  record_id integer not null,
  timestamp integer not null,
  subsystem varchar(32) not null,
  success integer not null,
  user_id integer not null,
  workstation varchar(63) not null,
  session_id integer not null,
  object_id integer not null,
  message text null,
  old_value text null,
  new_value text null,
  value_type char(1) null,
  hmac varchar(64) null,
  PRIMARY KEY(record_id)
) ;
CREATE TABLE persistent_storage
(
  entry_key varchar(127) not null,
  value varchar(2000) null,
  PRIMARY KEY(entry_key)
) ;
CREATE TABLE snmp_communities
(
  id integer not null,
  community varchar(255) null,
  zone integer not null,
  PRIMARY KEY(id,zone)
) ;
CREATE TABLE ap_common
(
  guid varchar(36) not null,
  owner_id integer not null,
  policy_name varchar(63) not null,
  policy_type varchar(31) not null,
  version integer not null,
  flags integer not null,
  file_content text null,
  PRIMARY KEY(guid)
) ;
CREATE TABLE usm_credentials
(
  id integer not null,
  user_name varchar(255) not null,
  auth_method integer not null,
  priv_method integer not null,
  auth_password varchar(255) null,
  priv_password varchar(255) null,
  zone integer not null,
  comments varchar(255) null,
  PRIMARY KEY(id,zone)
) ;
CREATE TABLE well_known_ports
(
   tag varchar(15) not null,
   zone integer not null,
   id integer not null,
   port integer not null,
   PRIMARY KEY(tag,zone,id)
) ;
CREATE TABLE network_maps
(
  id integer not null,
  map_type integer not null,
  layout integer not null,
  radius integer not null,
  background varchar(36) null,
  bg_latitude varchar(20) null,
  bg_longitude varchar(20) null,
  bg_zoom integer null,
  bg_color integer not null,
  link_color integer not null,
  link_routing integer not null,
  object_display_mode integer not null,
  filter text null,
  PRIMARY KEY(id)
) ;
CREATE TABLE network_map_elements
(
  map_id integer not null,
  element_id integer not null,
  element_type integer not null,
  element_data text not null,
  flags integer not null,
  PRIMARY KEY(map_id,element_id)
) ;
CREATE TABLE network_map_links
(
  map_id integer not null,
  link_id integer not null,
  element1 integer not null,
  element2 integer not null,
  link_type integer not null,
  link_name varchar(255) null,
  connector_name1 varchar(255) null,
  connector_name2 varchar(255) null,
  element_data text null,
  flags integer not null,
  color_source integer not null,
  color integer not null,
  color_provider varchar(255) null,
  PRIMARY KEY(map_id,link_id)
) ;
CREATE INDEX idx_network_map_links_map_id ON network_map_links(map_id);
CREATE TABLE network_map_seed_nodes
(
  map_id integer not null,
  seed_node_id integer not null,
  PRIMARY KEY(map_id,seed_node_id)
) ;
CREATE TABLE network_map_deleted_nodes
(
  map_id integer not null,
  object_id integer not null,
  element_index integer not null,
  position_x integer not null,
  position_y integer not null,
  PRIMARY KEY(map_id, object_id)
) ;
CREATE TABLE images
(
  guid varchar(36) not null,
  name varchar(63) not null,
  category varchar(63) not null,
  mimetype varchar(32) not null,
  protected integer default 0,
  PRIMARY KEY(guid),
  UNIQUE(name, category)
) ;
CREATE TABLE dashboards
(
  id integer not null,
  num_columns integer not null,
  options integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE dashboard_elements
(
  dashboard_id integer not null,
  element_id integer not null,
  element_type integer not null,
  element_data text null,
  layout_data text null,
  PRIMARY KEY(dashboard_id,element_id)
) ;
CREATE TABLE dashboard_associations
(
  object_id integer not null,
  dashboard_id integer not null,
  PRIMARY KEY(object_id,dashboard_id)
) ;
CREATE TABLE business_services
(
  id integer not null,
  prototype_id integer not null,
  instance varchar(1023),
  object_status_threshold integer not null,
  dci_status_threshold integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE business_service_prototypes
(
  id integer not null,
  instance_method integer not null,
  instance_source integer not null,
  instance_data varchar(1023),
  instance_filter text,
  object_status_threshold integer not null,
  dci_status_threshold integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE business_service_checks
(
  id integer not null,
  service_id integer not null,
  prototype_service_id integer not null,
  prototype_check_id integer not null,
  type integer not null,
  description varchar(1023),
  related_object integer not null,
  related_dci integer not null,
  status_threshold integer not null,
  content text null,
  status integer not null,
  current_ticket integer not null,
  failure_reason varchar(255) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE slm_agreements
(
  agreement_id integer not null,
  service_id integer not null,
  org_id integer not null,
  uptime varchar(63) not null,
  period integer not null,
  start_date integer not null,
  notes varchar(255),
  PRIMARY KEY(agreement_id)
) ;
CREATE TABLE business_service_tickets
(
  ticket_id integer not null,
  service_id integer not null,
  original_ticket_id integer not null,
  original_service_id integer not null,
  check_id integer not null,
  check_description varchar(1023),
  create_timestamp integer not null,
  close_timestamp integer not null,
  reason varchar(255) null,
  PRIMARY KEY(ticket_id)
) ;
CREATE TABLE business_service_downtime
(
  record_id integer not null,
  service_id integer not null,
  from_timestamp integer not null,
  to_timestamp integer not null,
  PRIMARY KEY(record_id)
) ;
CREATE TABLE organizations
(
  id integer not null,
  parent_id integer not null,
  org_type integer not null,
  name varchar(63) not null,
  description varchar(255),
  manager integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE persons
(
  id integer not null,
  org_id integer not null,
  first_name varchar(63),
  last_name varchar(63),
  title varchar(255),
  status integer not null,
  PRIMARY KEY(id)
) ;
CREATE TABLE licenses
(
  id integer not null,
  content text null,
  PRIMARY KEY(id)
) ;
CREATE TABLE mapping_tables
(
  id integer not null,
  name varchar(63) not null,
  flags integer not null,
  description varchar(4000) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE mapping_data
(
  table_id integer not null,
  md_key varchar(63) not null,
  md_value varchar(4000) null,
  description varchar(4000) null,
  PRIMARY KEY(table_id,md_key)
) ;
CREATE TABLE dci_summary_tables
(
  id integer not null,
  guid varchar(36) not null,
  menu_path varchar(255) null,
  title varchar(127) null,
  node_filter text null,
  flags integer not null,
  columns text null,
  table_dci_name varchar(255) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE scheduled_tasks
(
  id integer not null,
  taskId varchar(255) null,
  schedule varchar(127) null,
  params varchar(1023) null,
  execution_time integer not null,
  last_execution_time integer not null,
  flags integer not null,
  owner integer not null,
  object_id integer not null,
  comments varchar(255) null,
  task_key varchar(255) null,
  PRIMARY KEY(id)
) ;
CREATE TABLE currency_codes
(
 numeric_code char(3) not null,
 alpha_code char(3) not null,
 description varchar(127) not null,
 exponent integer not null,
 PRIMARY KEY(numeric_code)
) ;
CREATE TABLE country_codes
(
 numeric_code char(3) not null,
 alpha_code char(2) not null,
 alpha3_code char(3) not null,
 name varchar(127) not null,
 PRIMARY KEY(numeric_code)
) ;
CREATE TABLE config_repositories
(
 id integer not null,
 url varchar(1023) not null,
 auth_token varchar(63) null,
 description varchar(1023) null,
 PRIMARY KEY(id)
) ;
CREATE TABLE port_layouts
(
   device_oid varchar(127) not null,
   numbering_scheme char(1) not null,
   row_count char(1) not null,
   layout_data varchar(4000) null,
   PRIMARY KEY(device_oid)
) ;
CREATE TABLE object_access_snapshot
(
   user_id integer not null,
   object_id integer not null,
   access_rights integer not null,
   PRIMARY KEY(user_id,object_id)
) ;
CREATE TABLE sensors
(
   id integer not null,
   proxy_node integer not null,
   mac_address varchar(16) null,
   device_class integer not null,
   vendor varchar(128) null,
   communication_protocol integer not null,
   xml_reg_config varchar(4000) null,
   xml_config varchar(4000) null,
   serial_number varchar(256) null,
   device_address varchar(256) null,
   meta_type varchar(256) null,
   description varchar(512) null,
   last_connection_time integer not null,
   frame_count integer not null,
   signal_strenght integer not null,
   signal_noise integer not null,
   frequency integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE responsible_users
(
   object_id integer not null,
   user_id integer not null,
   tag varchar(31) null,
   PRIMARY KEY(object_id,user_id)
) ;
CREATE TABLE auto_bind_target
(
   object_id integer not null,
   bind_filter_1 text null,
   bind_filter_2 text null,
   flags integer not null,
   PRIMARY KEY(object_id)
) ;
CREATE TABLE versionable_object
(
   object_id integer not null,
   version integer not null,
   PRIMARY KEY(object_id)
) ;
CREATE TABLE user_agent_notifications
(
   id integer not null,
   message varchar(1023) null,
   objects varchar(1023) not null,
   start_time integer not null,
   end_time integer not null,
   recall char(1) not null,
   on_startup char(1) not null,
   creation_time integer not null,
   created_by integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE notification_channels
(
   name varchar(63) not null,
   driver_name varchar(63) not null,
   description varchar(255) null,
   configuration text null,
   PRIMARY KEY(name)
) ;
CREATE TABLE nc_persistent_storage
(
   channel_name varchar(63) not null,
   entry_name varchar(127) not null,
   entry_value varchar(2000) null,
   PRIMARY KEY(channel_name, entry_name)
) ;
CREATE TABLE two_factor_auth_methods
(
   name varchar(63) not null,
   driver varchar(63) null,
   description varchar(255) null,
   configuration text null,
   PRIMARY KEY(name)
) ;
CREATE TABLE two_factor_auth_bindings
(
   user_id integer not null,
   name varchar(63) not null,
   configuration text null,
   PRIMARY KEY(user_id,name)
) ;
CREATE TABLE websvc_definitions
(
   id integer not null,
   guid varchar(36) not null,
   name varchar(63) not null,
   description varchar(2000) null,
   url varchar(4000) null,
   http_request_method integer not null,
   request_data varchar(4000) null,
   flags integer not null,
   auth_type integer not null,
   login varchar(255) null,
   password varchar(255) null,
   cache_retention_time integer not null,
   request_timeout integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE websvc_headers
(
   websvc_id integer not null,
   name varchar(63) not null,
   value varchar(2000) null,
   PRIMARY KEY(websvc_id,name)
) ;
CREATE TABLE shared_secrets
(
   id integer not null,
   secret varchar(88) null,
   zone integer not null,
   PRIMARY KEY(id,zone)
) ;
CREATE TABLE dci_delete_list
(
   node_id integer not null,
   dci_id integer not null,
   type char(1) not null,
   PRIMARY KEY (node_id,dci_id)
) ;
CREATE TABLE win_event_log (
   id bigint not null,
   event_timestamp timestamptz not null,
   node_id integer not null,
   zone_uin integer not null,
   origin_timestamp integer not null,
   log_name varchar(63) null,
   event_source varchar(127) null,
   event_severity integer not null,
   event_code integer not null,
   message varchar(2000) null,
   raw_data text null,
   PRIMARY KEY(id,event_timestamp)
) ;
CREATE INDEX idx_win_event_log_timestamp ON win_event_log(event_timestamp);
CREATE INDEX idx_win_event_log_node ON win_event_log(node_id);
SELECT create_hypertable('win_event_log', 'event_timestamp', chunk_time_interval => interval '86400 seconds');
CREATE TABLE geo_areas
(
   id integer not null,
   name varchar(127) not null,
   comments text null,
   configuration text null,
   PRIMARY KEY(id)
) ;
CREATE TABLE dc_targets
(
   id integer not null,
   geolocation_ctrl_mode integer not null,
   geo_areas varchar(2000) null,
   web_service_proxy integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE pollable_objects
(
   id integer not null,
   config_poll_timestamp integer not null,
   instance_poll_timestamp integer not null,
   PRIMARY KEY(id)
) ;
CREATE TABLE ssh_keys
(
   id integer not null,
   name varchar(255) not null,
   public_key varchar(700) null,
   private_key varchar(1710) null,
   PRIMARY KEY(id)
) ;
CREATE TABLE ssh_credentials
(
   zone_uin integer not null,
   id integer not null,
   login varchar(63) null,
   password varchar(63) null,
   key_id integer not null,
   PRIMARY KEY(zone_uin,id)
) ;
CREATE TABLE object_queries
(
   id integer not null,
   guid varchar(36) not null,
   name varchar(63) not null,
   description varchar(255) null,
   script text null,
   PRIMARY KEY(id)
) ;
CREATE TABLE maintenance_journal
(
   record_id integer not null,
   object_id integer not null,
   author integer not null,
   last_edited_by integer not null,
   description text null,
   creation_time integer not null,
   modification_time integer not null,
   PRIMARY KEY(record_id)
) ;
INSERT INTO metadata (var_name,var_value) VALUES ('SchemaVersion',700);
INSERT INTO metadata (var_name,var_value) VALUES ('SchemaVersionMajor',41);
INSERT INTO metadata (var_name,var_value) VALUES ('SchemaVersionMinor',18);
INSERT INTO metadata (var_name,var_value) VALUES ('Syntax','TSDB');
INSERT INTO metadata (var_name,var_value) VALUES ('SingeTablePerfData','1');
INSERT INTO metadata (var_name,var_value)
 VALUES ('IDataTableCreationCommand','CREATE TABLE idata_%d (item_id integer not null,idata_timestamp integer not null,idata_value varchar(255) null,raw_value varchar(255) null)');
INSERT INTO metadata (var_name,var_value)
 VALUES ('IDataIndexCreationCommand_0','CREATE INDEX idx_idata_%d_id_timestamp ON idata_%d(item_id,idata_timestamp DESC)');
INSERT INTO metadata (var_name,var_value)
 VALUES ('TDataTableCreationCommand_0','CREATE TABLE tdata_%d (item_id integer not null,tdata_timestamp integer not null,tdata_value ' || 'text' || ' null)');
INSERT INTO metadata (var_name,var_value)
 VALUES ('TDataIndexCreationCommand_0','CREATE INDEX idx_tdata_%d ON tdata_%d(item_id,tdata_timestamp)');
INSERT INTO metadata (var_name,var_value)
 VALUES ('LocationHistory','CREATE TABLE gps_history_%d (latitude varchar(20), longitude varchar(20), accuracy integer not null, start_timestamp integer not null, end_timestamp integer not null, PRIMARY KEY(start_timestamp))');
COMMIT TRANSACTION;
