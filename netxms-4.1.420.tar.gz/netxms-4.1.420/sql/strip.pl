#!/usr/bin/perl
   if (! /^[\s\t\n]*$/ && ! /^\#.*$/) { print; }

